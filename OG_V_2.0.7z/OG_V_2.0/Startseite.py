from tkinter import *
# importing the csv module
import Charakterseite as CS

class mainwin:
    global gplatz
    global platz
    global Wort
    global Zahl
    global Wert_AP
    global Wert_gesamt
    global Wert_Intelligenz
    global Wert_Kraft
    global Wert_Ausdauer
    global Wert_Charisma
    global Wert_Intuition
    global Wert_Fingerfertigkeit
    global Wert_Lebensmittelbearbeitung
    global Wert_Koerperbeherrschung
    global Wert_SagenundLegenden
    global Wert_Selbstbeherrschung
    global Wert_Schloesserknacken
    global Wert_Menschenkenntnis
    global Wert_Taschendiebstahl
    global Wert_Pflanzenkunde
    global Wert_Einschuechtern
    global Wert_Wildniskunde
    global Wert_Geistesblitz
    global Wert_Gassenwissen
    global Wert_Orientierung
    global Wert_Kriegskunst
    global Wert_Wahrnehmung
    global Wert_Ueberreden
    global Wert_Magiekunde
    global Wert_Ablenkung
    global Wert_Verbergen
    global Wert_Schwimmen
    global Wert_Heilkunde
    global Wert_Tierkunde
    global Wert_Betoeren
    global Wert_Klettern
    global Wert_Handwerk
    global Wert_Alchemie
    global Wert_Kraftakt
    global Wert_Sammeln
    global Wert_Handeln
    global Wert_Fesseln
    global Wert_Zechen
    global Wert_Jagen
    global convert_Wert
    global Wert_Rechne
    global plus_minus
    global but_Rechne1
    global but_Rechne10
    global Wert_Wurfwaffen_AT
    global Wert_Hiebwaffen_AT
    global Wert_Hiebwaffen_PA
    global Wert_Stabwaffen_AT
    global Wert_Stabwaffen_PA
    global Wert_Schleudern_AT
    global Wert_Peitschen_AT
    global Wert_Armbrust_AT
    global Wert_Schwerter_AT
    global Wert_Schwerter_PA
    global Wert_Schilde_AT
    global Wert_Schilde_PA
    global Wert_Raufen_AT
    global Wert_Raufen_PA
    global Wert_Dolche_AT
    global Wert_Dolche_PA
    global Wert_Boegen_AT
    global Wert_Faehigkeiten
    global Wert_Zauber
    global Wert_LP
    global Schwer
    global Proffessionsauswahl
    global Proffessionsauswahlexist
    global Name
    global Proffessionszahl
    global Geschlechtzahl
    global Spzahl
    global entryProffession
    global STclose
    global ST

    Wert_Wurfwaffen_AT = 0
    Wert_Hiebwaffen_AT = 0
    Wert_Hiebwaffen_PA = 0
    Wert_Stabwaffen_AT = 0
    Wert_Stabwaffen_PA = 0
    Wert_Schleudern_AT = 0
    Wert_Peitschen_AT = 0
    Wert_Armbrust_AT = 0
    Wert_Schwerter_AT = 0
    Wert_Schwerter_PA = 0
    Wert_Schilde_AT = 0
    Wert_Schilde_PA = 0
    Wert_Raufen_AT = 0
    Wert_Raufen_PA = 0
    Wert_Dolche_AT = 0
    Wert_Dolche_PA = 0
    Wert_Boegen_AT = 0
    Wert_Faehigkeiten = 0
    Wert_Zauber = 0
    Name = ""


    f = ("Times bold", 14)


    gplatz = "          "
    platz = "    "
    Wort = ""
    Zahl = 0
    Wert_AP = 0
    Wert_gesamt = 0
    Wert_Intelligenz = 0
    Wert_Kraft = 0
    Wert_Ausdauer = 0
    Wert_Charisma = 0
    Wert_Intuition = 0
    Wert_Fingerfertigkeit = 0
    Wert_Lebensmittelbearbeitung = 0
    Wert_Koerperbeherrschung = 0
    Wert_SagenundLegenden = 0
    Wert_Selbstbeherrschung = 0
    Wert_Schloesserknacken = 0
    Wert_Menschenkenntnis = 0
    Wert_Taschendiebstahl = 0
    Wert_Pflanzenkunde = 0
    Wert_Einschuechtern = 0
    Wert_Wildniskunde = 0
    Wert_Geistesblitz = 0
    Wert_Gassenwissen = 0
    Wert_Orientierung = 0
    Wert_Kriegskunst = 0
    Wert_Wahrnehmung = 0
    Wert_Ueberreden = 0
    Wert_Magiekunde = 0 
    Wert_Ablenkung = 0
    Wert_Verbergen = 0
    Wert_Schwimmen = 0
    Wert_Heilkunde = 0
    Wert_Tierkunde = 0
    Wert_Betoeren = 0
    Wert_Klettern = 0
    Wert_Handwerk = 0
    Wert_Alchemie = 0
    Wert_Kraftakt = 0
    Wert_Sammeln = 0
    Wert_Handeln = 0
    Wert_Fesseln = 0
    Wert_Zechen = 0
    Wert_Jagen = 0
    convert_Wert = ""
    Wert_Rechne = 0
    plus_minus = 0
    Wert_LP = 0
    Schwer = 0
    Proffessionsauswahlexist = FALSE
    Proffessionsauswahl = ""
    Proffessionszahl = 0
    Geschlechtzahl = 0
    Spzahl = 0


    ST=Tk()
    ST.title("Start")
    ST.geometry("1920x1080")
    ST.configure (bg="black")
    ST.lift()

    #Button(
    #    ST,
    #    text="Talentseite",
    #    fg="purple",
    #    bg="black",
    #    font = "Arial 20",
    #    command=lambda: [STclose(),Talentseite()]
    #    ).place(x =1600 ,y= 450)

    #Button (
    #    ST,
    #    text="Charakter",
    #    fg="purple",
    #    bg="black",
    #    font = "Arial 20",
    #    command=lambda: [STclose(),Charakterseite()]
    #    ).place(x =1200 ,y= 450)

    #Button (
    #    ST,
    #    text="Kampfbogen",
    #    fg="purple",
    #    bg="black",
    #    font = "Arial 20",
    #    command=lambda: [STclose(),Kampfbogenseite()]
    #    ).place(x =1400 ,y= 450)

    lab_Begruessung = Label (ST, 
                    text = "Herzlich wilkommen bei dem Charaktergenerator fuer OurGame. \n Bitte waehlen Sie, ob Sie einen neuen Charakter anfangen wollen oder einen bestehenden bearbeiten wollen.",
                    fg= "purple",
                    bg = "black",
                    font = "Roman 20",
                    ).place(x =380 ,y= 450)       

    Button(
        ST,
        text="Neuen Charakter erstellen",
        fg="purple",
        bg="black",
        font = "Arial 20",
        command=lambda: [STclose(),CS.Charakterseite()]
        ).place(x =450 ,y= 550)

    Button(
        ST,
        text="Bestehenden Charakter bearbeiten",
        fg="purple",
        bg="black",
        font = "Arial 20",
        command=lambda: [STclose(),CS.Charakterseite()]
        ).place(x =1100 ,y= 550)

    def STclose():
        ST.destroy()

    ST.mainloop()
from tkinter import *
import char_csv_write as ccw
import Talentseite as TS
def Charakterseite():
    global Proffessionsauswahlexist
    global Proffessionszahl
    global Geschlechtzahl
    global Spzahl
    
    Proffessionsauswahlexist = FALSE
    Proffessionszahl = 0
    Geschlechtzahl = 0
    Spzahl = 0
    
    CH=Tk()
    CH.title("Charakter")
    CH.geometry("1920x1080")
    CH.configure (bg="black")
    CH.lift()
    
    Button(
    CH,
    text="Talentseite",
    fg="purple",
    bg="black",
    font = "Arial 20",
    command=lambda: [ccw.char_csv_write(),Charakterclose(),TS.Talentseite()]
    ).place(x =1600 ,y= 450)


    Button (
        CH,
        text="Kampfbogen",
        fg="purple",
        bg="black",
        font = "Arial 20",
        command=lambda: [ccw.char_csv_write(),Charakterclose(),TS.Talentseite()]
        ).place(x =1600 ,y= 550)

    def getName():
        Name=entryName.get()
        
        print(Name)
        

    def Charakterclose():

        CH.destroy()
    #############################################################
    f = ("Times bold", 14)

    global Name
    #eingabefenster
    #dropdown
    Spezies = ""
    #eingabefenster
    Koerpergroesse = 0
    Gewicht = 0
    Alter = 0
    #dropdown
    Proffesion = ""
    Geschlecht = ""
    Proffessionsauswahl = ""
    global entryProffession
    Wert_Rechne = 0
    plus_minus = 0
    

       
    Proffesionoption = [
    "Proffesion",                           #0
    "Weissmagier",                          #1
    "Graumagier",                           #2
    "Schwarzmagier",                        #3
    "Handwerker",                           #4
    "Heiler",                               #5
    "Alchemist",                            #6
    "Mechanikus",                           #7
    "Hexe",                                 #8
    "Ritter",                               #9
    "Krieger",                              #10
    "Amazone",                              #11
    "Seefahrer",                            #12
    "Darsteller",                           #13
    "Lebensmittelhersteller",               #14
    "Jaeger",                               #15
    "Priester",                             #16
    "Tiertrainer",                          #17
    "Tierzuechter",                         #18
    "Assesine",                             #19
    "Haendler",                             #20
    "Dieb",                                 #21
    "Prostetuierte",                        #22
    "Ressurcensucher",                      #23
    "Gelehrter",                            #24
    "Herscher",                             #25
    "Schmuggler",                           #26
    "Taugenichts",                          #27
    "Wirt",                                 #28
    "Schriftsteller",                       #29
    "Gesetzeshueter",                       #30
    "Wildniskundiger",                      #31
    "Kampftrainer",                         #32
    "Giftmischer",                          #33
    "Eigene Proffesion ="                   #34
    
    ]

    def Proffession_selected(choice,):
        choice = variable.get()
        print(choice)
        global Proffessionszahl
        global Proffessionsauswahlexist
        global entryProffession
        if (choice == "Proffesion"):
            Proffessionszahl = 0
        if (choice == "Weissmagier"):
            Proffessionszahl = 1
        if (choice == "Graumagier"):
            Proffessionszahl = 2
        if (choice == "Schwarzmagier"):
            Proffessionszahl = 3
        if (choice == "Handwerker"):
            Proffessionszahl = 4
        if (choice == "Heiler"):
            Proffessionszahl = 5
        if (choice == "Alchemist"):
            Proffessionszahl = 6
        if (choice == "Mechanikus"):
            Proffessionszahl = 7
        if (choice == "Hexe"):
            Proffessionszahl = 8
        if (choice == "Ritter"):
            Proffessionszahl = 9
        if (choice == "Krieger"):
            Proffessionszahl = 10
        if (choice == "Amazone"):
            Proffessionszahl = 11
        if (choice == "Seefahrer"):
            Proffessionszahl = 12
        if (choice == "Darsteller"):
            Proffessionszahl = 13
        if (choice == "Lebensmittelhersteller"):
            Proffessionszahl = 14
        if (choice == "Jaeger"):
            Proffessionszahl = 15
        if (choice == "Priester"):
            Proffessionszahl = 16
        if (choice == "Tiertrainer"):
            Proffessionszahl = 17
        if (choice == "Tierzuechter"):
            Proffessionszahl = 18
        if (choice == "Assesine"):
            Proffessionszahl = 19
        if (choice == "Haendler"):
            Proffessionszahl = 20
        if (choice == "Dieb"):
            Proffessionszahl = 21
        if (choice == "Prostetuierte"):
            Proffessionszahl = 22
        if (choice == "Ressurcensucher"):
            Proffessionszahl = 23
        if (choice == "Gelehrter"):
            Proffessionszahl = 24
        if (choice == "Herscher"):
            Proffessionszahl = 25
        if (choice == "Schmuggler"):
            Proffessionszahl = 26
        if (choice == "Taugenichts"):
            Proffessionszahl = 27
        if (choice == "Wirt"):
            Proffessionszahl = 28
        if (choice == "Schriftsteller"):
            Proffessionszahl = 29
        if (choice == "Gesetzeshueter"):
            Proffessionszahl = 30
        if (choice == "Wildniskundiger"):
            Proffessionszahl = 31
        if (choice == "Kampftrainer"):
            Proffessionszahl = 32
        if (choice == "Giftmischer"):
            Proffessionszahl = 33
        if (choice == "Eigene Proffesion ="):
            Proffessionszahl = 34
            entryProffession = Entry(master=CH, bg='grey')
            entryProffession.place(x=1300, y=110, width=100, height=27)
            Proffessionsauswahlexist = True
        if (choice != "Eigene Proffesion =") and ( Proffessionsauswahlexist == True):
            entryProffession.destroy()
            Proffessionsauswahlexist = False


            

    if (Proffessionsauswahlexist == True):
        
        entryProffession = Entry(master=CH, bg='grey')
        entryProffession.place(x=1300, y=110, width=100, height=27)


    variable = StringVar( CH)
    variable.set(Proffesionoption[Proffessionszahl]) # default value
                                    
    dropdown = OptionMenu(CH, variable, *Proffesionoption,command=Proffession_selected)
    dropdown.config(bg="black", fg="purple")
    dropdown["menu"].config(bg="black", fg="purple")
    dropdown.place(x=1010, y=110, width=200, height=40)

    
    #print ("mit display"+display_selected);
    print ("mit variable.get"+variable.get())
    print ("choice"+Proffessionsauswahl)



    lab_Proffession = Label (CH, 
             text = "Proffesion:",
             fg= "purple",
             bg = "black",
             font = "Roman 20",
             )
    lab_Proffession.place(x=850, y=110)



    lab_Name = Label (CH, 
                 text = "Name:",
                 fg= "purple",
                 bg = "black",
                 font = "Roman 20",
                 )
    lab_Name.place(x=10, y=110)
    global entryName
    entryName = Entry(master=CH, bg='grey',)
    entryName.place(x=210, y=110, width=100, height=27)


    lab_Alter = Label (CH, 
                 text = "Alter:",
                 fg= "purple",
                 bg = "black",
                 font = "Roman 20",
                 )
    lab_Alter.place(x=10, y=210)
    global entryAlter
    entryAlter = Entry(master=CH, bg='grey')
    entryAlter.place(x=210, y=210, width=100, height=27)

    lab_Koerpergroesse = Label (CH, 
                 text = "Koerpergroesse:",
                 fg= "purple",
                 bg = "black",
                 font = "Roman 20",
                 )
    lab_Koerpergroesse.place(x=10, y=310)
    global entryKoerpergroesse
    entryKoerpergroesse = Entry(master=CH, bg='grey')
    entryKoerpergroesse.place(x=210, y=310, width=100, height=27)
    lab_Gewicht = Label (CH, 
                 text = "Gewicht:",
                 fg= "purple",
                 bg = "black",
                 font = "Roman 20",
                 )
    lab_Gewicht.place(x=10, y=410)
    global entryGewicht
    entryGewicht = Entry(master=CH, bg='grey')
    entryGewicht.place(x=210, y=410, width=100, height=27)

    lab_CM = Label (CH, 
                 text = "CM",
                 fg= "purple",
                 bg = "black",
                 font = "Roman 20",
                 )
    lab_CM.place(x=320, y=310)
    lab_KG = Label (CH, 
                 text = "KG",
                 fg= "purple",
                 bg = "black",
                 font = "Roman 20",
                 )
    lab_KG.place(x=320, y=410)

    #############################################################
    lab_Geschlecht = Label (CH, 
             text = "Geschlecht:",
             fg= "purple",
             bg = "black",
             font = "Roman 20",
             )
    lab_Geschlecht.place(x=850, y=210)

    def Geschlecht_selected(Gechoice,):

        Gechoice = GeschlechtVar.get()
        print(Gechoice)
        global Geschlechtzahl
        if (Gechoice == "Maenlich"):
            Geschlechtzahl = 0
        if (Gechoice == "Weiblich"):
            Geschlechtzahl = 1
        if (Gechoice == "Divers"):
            Geschlechtzahl = 2

    OptionList = [
    "Maenlich",
    "Weiblich",
    "Divers"
    ] 


    GeschlechtVar = StringVar(CH)
    GeschlechtVar.set(OptionList[Geschlechtzahl])

    optGeschlecht = OptionMenu(CH, GeschlechtVar, *OptionList,command=Geschlecht_selected)
    optGeschlecht.config(bg="black", fg="purple")
    optGeschlecht.place(x=1010, y=210, width=200, height=40)
    optGeschlecht["menu"].config(bg="black", fg="purple")

    def Geschlecht_selected(Gechoice,):

        Gechoice = GeschlechtVar.get()
        print(Gechoice)
        global Geschlechtzahl
        if (Gechoice == "Maenlich"):
            Geschlechtzahl = 0
        if (Gechoice == "Weiblich"):
            Geschlechtzahl = 1
        if (Gechoice == "Divers"):
            Geschlechtzahl = 2

    #############################################################
    #############################################################
    lab_Spezies = Label (CH, 
             text = "Spezies:",
             fg= "purple",
             bg = "black",
             font = "Roman 20",
             )
    lab_Spezies.place(x=850, y=310)

    def Spezies_selected(Spchoice,):

        Spchoice = SpeziesVar.get()
        print(Spchoice)
        global Spzahl
        if (Spchoice == "Mensch"):
            Spzahl = 0
        if (Spchoice == "Zarokaner"):
            Spzahl = 1
        if (Spchoice == "Ork"):
            Spzahl = 2
        if (Spchoice == "Goblin"):
            Spzahl = 3
        if (Spchoice == "Elf"):
            Spzahl = 4
        if (Spchoice == "Halbelf"):
            Spzahl = 5
        if (Spchoice == "Zwerg"):
            Spzahl = 6

    SpeziesList = [
    "Mensch",
    "Zarokaner",
    "Ork",
    "Goblin",
    "Elf",
    "Halbelf",
    "Zwerg"
    ] 


    SpeziesVar = StringVar(CH)
    SpeziesVar.set(SpeziesList[Spzahl])

    optSpezies = OptionMenu(CH, SpeziesVar, *SpeziesList,command=Spezies_selected)
    optSpezies.config(bg="black", fg="purple")
    optSpezies.place(x=1010, y=310, width=200, height=40)
    optSpezies["menu"].config(bg="black", fg="purple")

    CH.mainloop()

from tkinter import *
import Charakterseite as CS
import Talentseite as TS
def Kampfbogenseite():

    #############################################################################################################
    global gplatz
    global platz
    global Wort
    global Zahl
    global Wert_AP
    global Wert_gesamt
    global Wert_Intelligenz
    global Wert_Kraft
    global Wert_Ausdauer
    global Wert_Charisma
    global Wert_Intuition
    global Wert_Fingerfertigkeit
    global Wert_Lebensmittelbearbeitung
    global Wert_Koerperbeherrschung
    global Wert_SagenundLegenden
    global Wert_Selbstbeherrschung
    global Wert_Schloesserknacken
    global Wert_Menschenkenntnis
    global Wert_Taschendiebstahl
    global Wert_Pflanzenkunde
    global Wert_Einschuechtern
    global Wert_Wildniskunde
    global Wert_Geistesblitz
    global Wert_Gassenwissen
    global Wert_Orientierung
    global Wert_Kriegskunst
    global Wert_Wahrnehmung
    global Wert_Ueberreden
    global Wert_Magiekunde
    global Wert_Ablenkung
    global Wert_Verbergen
    global Wert_Schwimmen
    global Wert_Heilkunde
    global Wert_Tierkunde
    global Wert_Betoeren
    global Wert_Klettern
    global Wert_Handwerk
    global Wert_Alchemie
    global Wert_Kraftakt
    global Wert_Sammeln
    global Wert_Handeln
    global Wert_Fesseln
    global Wert_Zechen
    global Wert_Jagen
    global convert_Wert
    global Wert_Rechne
    global plus_minus
    global but_Rechne1
    global but_Rechne10
    global Wert_LP


    global Wert_Wurfwaffen_AT
    global Wert_Hiebwaffen_AT
    global Wert_Hiebwaffen_PA
    global Wert_Stabwaffen_AT
    global Wert_Stabwaffen_PA
    global Wert_Schleudern_AT
    global Wert_Peitschen_AT
    global Wert_Armbrust_AT
    global Wert_Schwerter_AT
    global Wert_Schwerter_PA
    global Wert_Schilde_AT
    global Wert_Schilde_PA
    global Wert_Raufen_AT
    global Wert_Raufen_PA
    global Wert_Dolche_AT
    global Wert_Dolche_PA
    global Wert_Boegen_AT
    global Wert_Faehigkeiten
    global Wert_Zauber
    
    
    Wert_Intelligenz = 0
    Wert_Kraft = 0
    Wert_Ausdauer = 0
    Wert_Charisma = 0
    Wert_Intuition = 0
    Wert_Fingerfertigkeit = 0

    Wert_Wurfwaffen_AT = 0
    Wert_Hiebwaffen_AT = 0
    Wert_Hiebwaffen_PA = 0
    Wert_Stabwaffen_AT = 0
    Wert_Stabwaffen_PA = 0
    Wert_Schleudern_AT = 0
    Wert_Peitschen_AT = 0
    Wert_Armbrust_AT = 0
    Wert_Schwerter_AT = 0
    Wert_Schwerter_PA = 0
    Wert_Schilde_AT = 0
    Wert_Schilde_PA = 0
    Wert_Raufen_AT = 0
    Wert_Raufen_PA = 0
    Wert_Dolche_AT = 0
    Wert_Dolche_PA = 0
    Wert_Boegen_AT = 0
    gplatz = "          "
    platz = "    "
    Wort = ""
    Zahl = 0
    Wert_AP = 0
    convert_Wert = ""
    Wert_Rechne = 0
    plus_minus = 0
    Wert_Faehigkeiten = 0
    Wert_Zauber = 0

    root=Tk()
    root.title("Kampfbogen")
    root.geometry("1920x1080")
    root.configure (bg="black")
    root.lift()
    
    Button(
    root,
    text="Talentseite",
    fg="purple",
    bg="black",
    font = "Arial 20",
    command=lambda: [Kampfclose(),TS.Talentseite()]
    ).place(x =1600 ,y= 450)

    Button (
        root,
        text="Charakter",
        fg="purple",
        bg="black",
        font = "Arial 20",
        command=lambda: [Kampfclose(),CS.Charakterseite()]
        
        ).place(x =1600 ,y= 550)

           

    def Kampfclose():
        root.destroy()

    global seite3
    seite3 = True




    #############################################################################################################
    ###############Es folgen Klassen in welchen festgelegt wird was bei einem Button druck passiert##############
    #############################################################################################################

    #############################################################################################################
    def Rechne10():
        global Wert_Rechne
        global plus_minus
        global but_Rechne1
        Wert_Rechne = 9
        plus_minus = 10
        but_Rechne10.configure(bg="grey")
        but_Rechne1.configure(bg="black")

    def Rechne1():
        global Wert_Rechne
        global plus_minus
        global but_Rechne10
        Wert_Rechne = 0
        plus_minus = 1
        but_Rechne1.configure(bg="grey")
        but_Rechne10.configure(bg="black")

    #############################################################################################################
    def RechneplusIntelligenz():
        global Wert_AP
        global Wert_Intelligenz
        global lab_gplatz
        global gplatz
        global Wert_gesamt
        global platz
        global lab_platz
        if (Wert_AP>24):
            Wert_Intelligenz += 1
            Wert_AP -= 25
            Wert_gesamt += 1
            lab_gplatz =Label (root, 
            text = gplatz,
            fg= "green",
            bg = "black",
            font = "Roman 20",
                    )
            lab_gplatz.place(x=850, y=105)
            lab_platz =Label (root, 
            text = platz,
            fg= "green",
            bg = "black",
            font = "Roman 20",
                    )
            lab_platz.place(x=160, y=10)
            lab_AP_Wert =Label (root, 
            text = Wert_AP,
            fg= "green",
            bg= "black",
            font = "Roman 20",
                    )
            lab_AP_Wert.place(x=850, y=105)
            lab_Intelligenz_Wert = Label (root, 
            text = Wert_Intelligenz,
            fg= "green",
            bg = "black",
            font = "Roman 20",
            )
            lab_Intelligenz.place(x=10, y=10)
            lab_Intelligenz_Wert.place(x=160, y=10)

    def RechneminusIntelligenz():
        global Wert_AP
        global Wert_Intelligenz
        global lab_gplatz
        global gplatz
        global Wert_gesamt
        global platz
        global lab_platz
        if (Wert_Intelligenz>0):
            Wert_AP += 25
            Wert_Intelligenz -= 1
            Wert_gesamt -= 1
            lab_gplatz =Label (root, 
            text = gplatz,
            fg= "green",
            bg = "black",
            font = "Roman 20",
                    )
            lab_gplatz.place(x=850, y=105)
            lab_platz =Label (root, 
            text = platz,
            fg= "green",
            bg = "black",
            font = "Roman 20",
                    )
            lab_platz.place(x=160, y=10)
            lab_AP_Wert =Label (root, 
            text = Wert_AP,
            fg= "green",
            bg = "black",
            font = "Roman 20",
                    )
            lab_AP_Wert.place(x=850, y=105)
            lab_Intelligenz_Wert = Label (root, 
            text = Wert_Intelligenz,
            fg= "green",
            bg= "black",
            font = "Roman 20",
            )
            lab_Intelligenz.place(x=10, y=10)
            lab_Intelligenz_Wert.place(x=160, y=10)
        #############################################################################################################
   
    def RechneplusKraft():
        global Wert_AP
        global Wert_LP
        global Wert_Ausdauer
        global lab_AP_Wert
        global Wert_Kraft
        global lab_gplatz
        global gplatz
        global platz
        global lab_platz
        if (Wert_AP>16):
            Wert_Kraft +=1
            Wert_AP -= 17
            Wert_LP = (Wert_Kraft+Wert_Ausdauer)
            lab_gplatz =Label (root, 
            text = gplatz,
            fg= "green",
            bg = "black",
            font = "Roman 20",
                    )
            lab_gplatz.place(x=850, y=105)
            lab_platz =Label (root, 
            text = platz,
            fg= "green",
            bg = "black",
            font = "Roman 20",
                    )
            lab_platz.place(x=410, y=10)
            lab_AP_Wert =Label (root, 
            text = Wert_AP,
            fg= "green",
            bg = "black",
            font = "Roman 20",
                    )
            lab_AP_Wert.place(x=850, y=105)
            lab_Kraft = Label (root, 
                 text = "Kraft",
                 fg= "green",
            bg = "black",
                 font = "Roman 20",
                 )
            lab_Kraft_Wert = Label (root, 
                 text = Wert_Kraft,
                 fg= "green",
                 bg = "black",
                 font = "Roman 20",
                 )
            lab_Kraft.place(x=310, y=10)
            lab_Kraft_Wert.place(x=410, y=10)
            but_Kraft_plus.place(x= 390, y=10)
            but_Kraft_minus.place(x= 460, y=10)

    def RechneminusKraft():
        global Wert_AP
        global Wert_LP
        global Wert_Ausdauer
        global lab_AP_Wert
        global lab_gplatz
        global gplatz
        global Wert_Kraft
        global platz
        global lab_platz
        if (Wert_Kraft>0):
            Wert_AP += 17
            Wert_Kraft -= 1
            Wert_LP = (Wert_Kraft+Wert_Ausdauer)
            lab_gplatz =Label (root, 
            text = gplatz,
            fg= "green",
            bg = "black",
            font = "Roman 20",
                    )
            lab_gplatz.place(x=850, y=105)
            lab_platz =Label (root, 
            text = platz,
            fg= "green",
            bg = "black",
            font = "Roman 20",
                    )
            lab_platz.place(x=410, y=10)
            lab_AP_Wert =Label (root, 
            text = Wert_AP,
            fg= "green",
            bg = "black",
            font = "Roman 20",
                    )
            lab_AP_Wert.place(x=850, y=105)
            lab_Kraft = Label (root, 
                 text = "Kraft",
                 fg= "green",
                 bg = "black",
                 font = "Roman 20",
                 )
            lab_Kraft_Wert = Label (root, 
                         text = Wert_Kraft,
                         fg= "green",
                         bg = "black",
                         font = "Roman 20",
                         )
            lab_Kraft.place(x=310, y=10)
            lab_Kraft_Wert.place(x=410, y=10)
            but_Kraft_plus.place(x= 390, y=10)
            but_Kraft_minus.place(x= 460, y=10) 

    #############################################################################################################

    def RechneplusAusdauer():
        global Wert_AP
        global Wert_Kraft
        global Wert_LP
        global lab_AP_Wert
        global lab_gplatz
        global gplatz
        global Wert_Ausdauer
        global platz
        global lab_platz
        if (Wert_AP>13):
            Wert_AP -= 14
            Wert_Ausdauer += 1
            Wert_LP = (Wert_Kraft+Wert_Ausdauer)
            lab_gplatz =Label (root, 
            text = gplatz,
            fg= "green",
            bg = "black",
            font = "Roman 20",
                  )
            lab_gplatz.place(x=850, y=105)
            lab_platz =Label (root, 
            text = platz,
            fg= "green",
            bg = "black",
            font = "Roman 20",
                    )
            lab_platz.place(x=690, y=10)
            lab_AP_Wert =Label (root, 
            text = Wert_AP,
            fg= "green",
            bg = "black",
            font = "Roman 20",
                     )
            lab_AP_Wert.place(x=850, y=105)
            lab_Ausdauer = Label (root, 
                 text = "Ausdauer",
                 fg= "green",
                 bg = "black",
                 font = "Roman 20",
                 )
            lab_Ausdauer_Wert = Label (root, 
                         text = Wert_Ausdauer,
                         fg= "green",
                         bg = "black",
                         font = "Roman 20",
                         )
            lab_Ausdauer.place(x=560, y=10)
            lab_Ausdauer_Wert.place(x=690, y=10)
            but_Ausdauer_plus.place(x= 670, y=10)
            but_Ausdauer_minus.place(x= 740, y=10)

    def RechneminusAusdauer():
        global Wert_AP
        global Wert_LP
        global Wert_Kraft
        global lab_AP_Wert
        global lab_gplatz
        global gplatz
        global Wert_Ausdauer
        global platz
        global lab_platz
        if (Wert_Ausdauer>0):
            Wert_AP += 14
            Wert_Ausdauer -= 1
            Wert_LP = (Wert_Kraft+Wert_Ausdauer)
            lab_gplatz =Label (root, 
            text = gplatz,
            fg= "green",
            bg = "black",
            font = "Roman 20",
                  )
            lab_gplatz.place(x=850, y=105)
            lab_platz =Label (root, 
            text = platz,
            fg= "green",
            bg = "black",
            font = "Roman 20",
                    )
            lab_platz.place(x=690, y=10)
            lab_AP_Wert =Label (root, 
            text = Wert_AP,
            fg= "green",
            bg = "black",
            font = "Roman 20",
                     )
            lab_AP_Wert.place(x=850, y=105)
            lab_Ausdauer = Label (root, 
                 text = "Ausdauer",
                 fg= "green",
                 bg = "black",
                 font = "Roman 20",
                 )
            lab_Ausdauer_Wert = Label (root, 
                         text = Wert_Ausdauer,
                         fg= "green",
                         bg = "black",
                         font = "Roman 20",
                         )
            lab_Ausdauer.place(x=560, y=10)
            lab_Ausdauer_Wert.place(x=690, y=10)
            but_Ausdauer_plus.place(x= 670, y=10)
            but_Ausdauer_minus.place(x= 740, y=10)

    #############################################################################################################

    def RechneplusCharisma():
        global Wert_AP
        global lab_AP_Wert
        global Wert_Charisma
        global lab_gplatz
        global gplatz
        global platz
        global lab_platz
        if (Wert_AP>7):
            Wert_AP -= 8
            Wert_Charisma += 1
            global lab_gplatz
            global gplatz
            lab_gplatz =Label (root, 
            text = gplatz,
            fg= "green",
            bg = "black",
            font = "Roman 20",
                     )
            lab_gplatz.place(x=850, y=105)
            lab_platz =Label (root, 
            text = platz,
            fg= "green",
            bg = "black",
            font = "Roman 20",
                    )
            lab_platz.place(x=980, y=10)
            lab_AP_Wert =Label (root, 
            text = Wert_AP,
            fg= "green",
            bg = "black",
            font = "Roman 20",
                    )
            lab_AP_Wert.place(x=850, y=105)
            lab_Charisma = Label (root, 
                         text = "Charisma",
                         fg= "green",
                         bg = "black",
                         font = "Roman 20",
                         )
            lab_Charisma_Wert = Label (root, 
                         text = Wert_Charisma,
                         fg= "green",
                         bg = "black",
                         font = "Roman 20",
                         )
            lab_Charisma.place(x=840, y=10)
            lab_Charisma_Wert.place(x=980, y=10)
            but_Charisma_plus.place(x= 960, y=10)
            but_Charisma_minus.place(x= 1030, y=10)

    def RechneminusCharisma():
        global Wert_AP
        global lab_AP_Wert
        global Wert_Charisma
        global lab_gplatz
        global gplatz
        global platz
        global lab_platz
        if (Wert_Charisma>0):
            Wert_AP += 8
            Wert_Charisma -= 1
            global lab_gplatz
            global gplatz
            lab_gplatz =Label (root, 
            text = gplatz,
            fg= "green",
            bg = "black",
            font = "Roman 20",
                     )
            lab_gplatz.place(x=850, y=105)
            lab_platz =Label (root, 
            text = platz,
            fg= "green",
            bg = "black",
            font = "Roman 20",
                    )
            lab_platz.place(x=980, y=10)
            lab_AP_Wert =Label (root, 
            text = Wert_AP,
            fg= "green",
            bg = "black",
            font = "Roman 20",
                    )
            lab_AP_Wert.place(x=850, y=105)
            lab_Charisma = Label (root, 
                         text = "Charisma",
                         fg= "green",
                         bg = "black",
                         font = "Roman 20",
                         )
            lab_Charisma_Wert = Label (root, 
                         text = Wert_Charisma,
                         fg= "green",
                         bg = "black",
                         font = "Roman 20",
                         )
            lab_Charisma.place(x=840, y=10)
            lab_Charisma_Wert.place(x=980, y=10)
            but_Charisma_plus.place(x= 960, y=10)
            but_Charisma_minus.place(x= 1030, y=10)
    #############################################################################################################

    def RechneplusIntuition():
        global Wert_AP
        global lab_AP_Wert
        global Wert_Intuition
        global lab_gplatz
        global gplatz
        global platz
        global lab_platz
        if (Wert_AP>21):
            Wert_AP -= 22
            Wert_Intuition += 1
            global lab_gplatz
            global gplatz
            lab_gplatz =Label (root, 
            text = gplatz,
            fg= "green",
            bg = "black",
            font = "Roman 20",
                     )
            lab_gplatz.place(x=850, y=105)
            lab_platz =Label (root, 
            text = platz,
            fg= "green",
            bg = "black",
            font = "Roman 20",
                    )
            lab_platz.place(x=1270, y=10)
            lab_AP_Wert =Label (root, 
            text = Wert_AP,
            fg= "green",
            bg = "black",
            font = "Roman 20",
                    )
            lab_AP_Wert.place(x=850, y=105)
            lab_Intuition = Label (root, 
                         text = "Intuition",
                         fg= "green",
                         bg = "black",
                         font = "Roman 20",
                         )
            lab_Intuition_Wert = Label (root, 
                         text = Wert_Intuition,
                         fg= "green",
                         bg = "black",
                         font = "Roman 20",
                         )
            lab_Intuition.place(x=1130, y=10)
            lab_Intuition_Wert.place(x=1270, y=10)
            but_Intuition_plus.place(x= 1250, y=10)
            but_Intuition_minus.place(x= 1320, y=10)

    def RechneminusIntuition():
        global Wert_AP
        global lab_AP_Wert
        global Wert_Intuition
        global lab_gplatz
        global gplatz
        global platz
        global lab_platz
        if (Wert_Intuition>0):
            Wert_AP += 22
            Wert_Intuition -= 1
            global lab_gplatz
            global gplatz
            lab_gplatz =Label (root, 
            text = gplatz,
            fg= "green",
            bg = "black",
            font = "Roman 20",
                     )
            lab_gplatz.place(x=850, y=105)
            lab_platz =Label (root, 
            text = platz,
            fg= "green",
            bg = "black",
            font = "Roman 20",
                    )
            lab_platz.place(x=1270, y=10)
            lab_AP_Wert =Label (root, 
            text = Wert_AP,
            fg= "green",
            bg = "black",
            font = "Roman 20",
                    )
            lab_AP_Wert.place(x=850, y=105)
            lab_Intuition = Label (root, 
                         text = "Intuition",
                         fg= "green",
                         bg = "black",
                         font = "Roman 20",
                         )
            lab_Intuition_Wert = Label (root, 
                         text = Wert_Intuition,
                         fg= "green",
                         bg = "black",
                         font = "Roman 20",
                         )
            lab_Intuition.place(x=1130, y=10)
            lab_Intuition_Wert.place(x=1270, y=10)
            but_Intuition_plus.place(x= 1250, y=10)
            but_Intuition_minus.place(x= 1320, y=10)

    #############################################################################################################

    def RechneplusFingerfertigkeit():
        global Wert_AP
        global lab_AP_Wert
        global lab_gplatz
        global gplatz
        global Wert_Fingerfertigkeit
        global platz
        global lab_platz
        if (Wert_AP>13):
            Wert_AP -= 14
            Wert_Fingerfertigkeit += 1
            lab_gplatz =Label (root, 
            text = gplatz,
            fg= "green",
            bg = "black",
            font = "Roman 20",
                  )
            lab_gplatz.place(x=850, y=105)
            lab_platz =Label (root, 
            text = platz,
            fg= "green",
            bg = "black",
            font = "Roman 20",
                    )
            lab_platz.place(x=1630, y=10)
            lab_AP_Wert =Label (root, 
            text = Wert_AP,
            fg= "green",
            bg = "black",
            font = "Roman 20",
                     )
            lab_AP_Wert.place(x=850, y=105)
            lab_Fingerfertigkeit  = Label (root, 
                         text = "Fingerfertigkeit ",
                         fg= "green",
                         bg = "black",
                         font = "Roman 20",
                         )
            lab_Fingerfertigkeit_Wert = Label (root, 
                         text = Wert_Fingerfertigkeit,
                         fg= "green",
                         bg = "black",
                         font = "Roman 20",
                         )
            lab_Fingerfertigkeit.place(x=1420, y=10)
            lab_Fingerfertigkeit_Wert.place(x=1630, y=10)
            but_Fingerfertigkeit_plus.place(x= 1610, y=10)
            but_Fingerfertigkeit_minus.place(x= 1680, y=10)

    def RechneminusFingerfertigkeit():
        global Wert_AP
        global lab_AP_Wert
        global lab_gplatz
        global gplatz
        global Wert_Fingerfertigkeit
        global platz
        global lab_platz
        if (Wert_Fingerfertigkeit>0):
            Wert_AP += 14
            Wert_Fingerfertigkeit -= 1
            lab_gplatz =Label (root, 
            text = gplatz,
            fg= "green",
            bg = "black",
            font = "Roman 20",
                  )
            lab_gplatz.place(x=850, y=105)
            lab_platz =Label (root, 
            text = platz,
            fg= "green",
            bg = "black",
            font = "Roman 20",
                    )
            lab_platz.place(x=1630, y=10)
            lab_AP_Wert =Label (root, 
            text = Wert_AP,
            fg= "green",
            bg = "black",
            font = "Roman 20",
                     )
            lab_AP_Wert.place(x=850, y=105)
            lab_Fingerfertigkeit  = Label (root, 
                         text = "Fingerfertigkeit ",
                        fg= "green",
                        bg = "black",
                         font = "Roman 20",
                         )
            lab_Fingerfertigkeit_Wert = Label (root, 
                         text = Wert_Fingerfertigkeit,
                         fg= "green",
                         bg = "black",
                         font = "Roman 20",
                         )
            lab_Fingerfertigkeit.place(x=1420, y=10)
            lab_Fingerfertigkeit_Wert.place(x=1630, y=10)
            but_Fingerfertigkeit_plus.place(x= 1610, y=10)
            but_Fingerfertigkeit_minus.place(x= 1680, y=10)

    #############################################################################################################
    #############################################################################################################

    def RechnepluseinsAP():
        global Wert_AP
        global lab_AP_Wert
        Wert_AP += 1
        global lab_platz
        global gplatz
        lab_gplatz =Label (root, 
        text = gplatz,
        fg= "green",
        bg = "black",
        font = "Roman 20",
                 )
        lab_gplatz.place(x=850, y=105)
        lab_AP_Wert =Label (root, 
        text = Wert_AP,
        fg= "green",
        bg = "black",
        font = "Roman 20",
                 )
        lab_AP_Wert.place(x=850, y=105)

    def RechneminuseinsAP():
        global Wert_AP
        global lab_AP_Wert
        Wert_AP -= 1
        if (Wert_AP>-1):
            global lab_gplatz
            global gplatz
            lab_gplatz =Label (root, 
            text = gplatz,
            fg= "green",
            bg = "black",
            font = "Roman 20",
                     )
            lab_gplatz.place(x=850, y=105)
            lab_AP_Wert =Label (root, 
            text = Wert_AP,
            fg= "green",
            bg = "black",
            font = "Roman 20",
                     )
            lab_AP_Wert.place(x=850, y=105)

    def RechnepluszehnAP():
        global Wert_AP
        global lab_AP_Wert
        Wert_AP += 10
        global lab_gplatz
        global gplatz
        lab_gplatz =Label (root, 
        text = gplatz,
        fg= "green",
        bg = "black",
        font = "Roman 20",
                 )
        lab_gplatz.place(x=850, y=105)
        lab_AP_Wert =Label (root, 
        text = Wert_AP,
        fg= "green",
        bg = "black",
        font = "Roman 20",
                 )
        lab_AP_Wert.place(x=850, y=105)

    def RechneminuszehnAP():
        global Wert_AP
        global lab_AP_Wert
        Wert_AP -= 10
        global lab_gplatz
        global gplatz
        lab_gplatz =Label (root, 
        text = gplatz,
        fg= "green",
        bg = "black",
        font = "Roman 20",
                 )
        lab_gplatz.place(x=850, y=105)
        lab_AP_Wert =Label (root, 
        text = Wert_AP,
        fg= "green",
        bg = "black",
        font = "Roman 20",
                 )
        lab_AP_Wert.place(x=850, y=105)

    def RechneplushundertAP():
        global Wert_AP
        global lab_AP_Wert
        Wert_AP += 100
        global lab_gplatz
        global gplatz
        lab_gplatz =Label (root, 
        text = gplatz,
        fg= "green",
        bg = "black",
        font = "Roman 20",
                 )
        lab_gplatz.place(x=850, y=105)
        lab_AP_Wert =Label (root, 
        text = Wert_AP,
        fg= "green",
        bg = "black",
        font = "Roman 20",
                 )
        lab_AP_Wert.place(x=850, y=105)

    def RechneminushundertAP():
        global Wert_AP
        global lab_AP_Wert
        Wert_AP -= 100
        global lab_gplatz
        global gplatz
        lab_gplatz =Label (root, 
        text = gplatz,
        fg= "green",
        bg = "black",
        font = "Roman 20",
                 )
        lab_gplatz.place(x=850, y=105)
        lab_AP_Wert =Label (root, 
        text = Wert_AP,
        fg= "green",
        bg = "black",
        font = "Roman 20",
                 )
        lab_AP_Wert.place(x=850, y=105)
        lab_AP_Wert =Label (root, 
        text = Wert_AP,
        fg= "green",
        bg = "black",
        font = "Roman 20",
                 )
        lab_AP_Wert.place(x=850, y=105)

    #############################################################################################################
    #############################################################################################################
    def RechneplusWurfwaffen_AT():
        global Wert_AP
        global Wert_Wurfwaffen_AT
        global lab_gplatz
        global gplatz
        global Wert_gesamt
        global platz
        global lab_platz
        if (Wert_AP>Wert_Rechne):
            Wert_Wurfwaffen_AT += plus_minus
            Wert_AP -= plus_minus
            Wert_gesamt += plus_minus
            lab_gplatz =Label (root, 
            text = gplatz,
            fg= "purple",
            bg = "black",
            font = "Roman 20",
                    )
            lab_gplatz.place(x=850, y=105)
            lab_platz =Label (root, 
            text = platz,
            fg= "purple",
            bg = "black",
            font = "Roman 20",
                    )
            lab_platz.place(x=330, y=200)
            lab_AP_Wert =Label (root, 
            text = Wert_AP,
            fg= "purple",
            bg= "black",
            font = "Roman 20",
                    )
            lab_AP_Wert.place(x=850, y=105)
            lab_Wurfwaffen_AT_Wert = Label (root, 
            text = Wert_Wurfwaffen_AT,
            fg= "purple",
            bg = "black",
            font = "Roman 20",
            )
            lab_Wurfwaffen_AT.place(x=10, y=200)
            lab_Wurfwaffen_AT_Wert.place(x=330, y=200)

    def RechneminusWurfwaffen_AT():
        global Wert_AP
        global Wert_Wurfwaffen_AT
        global lab_gplatz
        global gplatz
        global Wert_gesamt
        global platz
        global lab_platz
        if (Wert_Wurfwaffen_AT>Wert_Rechne):
            Wert_AP += plus_minus
            Wert_Wurfwaffen_AT -= plus_minus
            Wert_gesamt -= plus_minus
            lab_gplatz =Label (root, 
            text = gplatz,
            fg= "purple",
            bg = "black",
            font = "Roman 20",
                    )
            lab_gplatz.place(x=850, y=105)
            lab_platz =Label (root, 
            text = platz,
            fg= "purple",
            bg = "black",
            font = "Roman 20",
                    )
            lab_platz.place(x=330, y=200)
            lab_AP_Wert =Label (root, 
            text = Wert_AP,
            fg= "purple",
            bg = "black",
            font = "Roman 20",
                    )
            lab_AP_Wert.place(x=850, y=105)
            lab_Wurfwaffen_AT_Wert = Label (root, 
            text = Wert_Wurfwaffen_AT,
            fg= "purple",
            bg= "black",
            font = "Roman 20",
            )
            lab_Wurfwaffen_AT.place(x=10, y=200)
            lab_Wurfwaffen_AT_Wert.place(x=330, y=200)

    #------------------------------------------------------------------------------------------------------------#

    def RechneplusHiebwaffen_AT():
        global Wert_AP
        global Wert_Hiebwaffen_AT
        global lab_gplatz
        global gplatz
        global Wert_gesamt
        global platz
        global lab_platz
        if (Wert_AP>Wert_Rechne):
            Wert_Hiebwaffen_AT += plus_minus
            Wert_AP -= plus_minus
            Wert_gesamt += plus_minus
            lab_gplatz =Label (root, 
            text = gplatz,
            fg= "purple",
            bg = "black",
            font = "Roman 20",
                    )
            lab_gplatz.place(x=850, y=105)
            lab_platz =Label (root, 
            text = platz,
            fg= "purple",
            bg = "black",
            font = "Roman 20",
                    )
            lab_platz.place(x=330, y=300)
            lab_AP_Wert =Label (root, 
            text = Wert_AP,
            fg= "purple",
            bg= "black",
            font = "Roman 20",
                    )
            lab_AP_Wert.place(x=850, y=105)
            lab_Hiebwaffen_AT_Wert = Label (root, 
            text = Wert_Hiebwaffen_AT,
            fg= "purple",
            bg = "black",
            font = "Roman 20",
            )
            lab_Hiebwaffen_AT.place(x=10, y=300)
            lab_Hiebwaffen_AT_Wert.place(x=330, y=300)

    def RechneminusHiebwaffen_AT():
        global Wert_AP
        global Wert_Hiebwaffen_AT
        global lab_gplatz
        global gplatz
        global Wert_gesamt
        global platz
        global lab_platz
        if (Wert_Hiebwaffen_AT>Wert_Rechne):
            Wert_AP += plus_minus
            Wert_Hiebwaffen_AT -= plus_minus
            Wert_gesamt -= plus_minus
            lab_gplatz =Label (root, 
            text = gplatz,
            fg= "purple",
            bg = "black",
            font = "Roman 20",
                    )
            lab_gplatz.place(x=850, y=105)
            lab_platz =Label (root, 
            text = platz,
            fg= "purple",
            bg = "black",
            font = "Roman 20",
                    )
            lab_platz.place(x=330, y=300)
            lab_AP_Wert =Label (root, 
            text = Wert_AP,
            fg= "purple",
            bg = "black",
            font = "Roman 20",
                    )
            lab_AP_Wert.place(x=850, y=105)
            lab_Hiebwaffen_AT_Wert = Label (root, 
            text = Wert_Hiebwaffen_AT,
            fg= "purple",
            bg= "black",
            font = "Roman 20",
            )
            lab_Hiebwaffen_AT.place(x=10, y=300)
            lab_Hiebwaffen_AT_Wert.place(x=330, y=300)

    #------------------------------------------------------------------------------------------------------------#

    def RechneplusHiebwaffen_PA():
        global Wert_AP
        global Wert_Hiebwaffen_PA
        global lab_gplatz
        global gplatz
        global Wert_gesamt
        global platz
        global lab_platz
        if (Wert_AP>Wert_Rechne):
            Wert_Hiebwaffen_PA += plus_minus
            Wert_AP -= plus_minus
            Wert_gesamt += plus_minus
            lab_gplatz =Label (root, 
            text = gplatz,
            fg= "purple",
            bg = "black",
            font = "Roman 20",
                    )
            lab_gplatz.place(x=850, y=105)
            lab_platz =Label (root, 
            text = platz,
            fg= "purple",
            bg = "black",
            font = "Roman 20",
                    )
            lab_platz.place(x=330, y=400)
            lab_AP_Wert =Label (root, 
            text = Wert_AP,
            fg= "purple",
            bg= "black",
            font = "Roman 20",
                    )
            lab_AP_Wert.place(x=850, y=105)
            lab_Hiebwaffen_PA_Wert = Label (root, 
            text = Wert_Hiebwaffen_PA,
            fg= "purple",
            bg = "black",
            font = "Roman 20",
            )
            lab_Hiebwaffen_PA.place(x=10, y=400)
            lab_Hiebwaffen_PA_Wert.place(x=330, y=400)

    def RechneminusHiebwaffen_PA():
        global Wert_AP
        global Wert_Hiebwaffen_PA
        global lab_gplatz
        global gplatz
        global Wert_gesamt
        global platz
        global lab_platz
        if (Wert_Hiebwaffen_PA>Wert_Rechne):
            Wert_AP += plus_minus
            Wert_Hiebwaffen_PA -= plus_minus
            Wert_gesamt -= plus_minus
            lab_gplatz =Label (root, 
            text = gplatz,
            fg= "purple",
            bg = "black",
            font = "Roman 20",
                    )
            lab_gplatz.place(x=850, y=105)
            lab_platz =Label (root, 
            text = platz,
            fg= "purple",
            bg = "black",
            font = "Roman 20",
                    )
            lab_platz.place(x=330, y=400)
            lab_AP_Wert =Label (root, 
            text = Wert_AP,
            fg= "purple",
            bg = "black",
            font = "Roman 20",
                    )
            lab_AP_Wert.place(x=850, y=105)
            lab_Hiebwaffen_PA_Wert = Label (root, 
            text = Wert_Hiebwaffen_PA,
            fg= "purple",
            bg= "black",
            font = "Roman 20",
            )
            lab_Hiebwaffen_PA.place(x=10, y=400)
            lab_Hiebwaffen_PA_Wert.place(x=330, y=400)

    #------------------------------------------------------------------------------------------------------------#

    def RechneplusStabwaffen_AT():
        global Wert_AP
        global Wert_Stabwaffen_AT
        global lab_gplatz
        global gplatz
        global Wert_gesamt
        global platz
        global lab_platz
        if (Wert_AP>Wert_Rechne):
            Wert_Stabwaffen_AT += plus_minus
            Wert_AP -= plus_minus
            Wert_gesamt += plus_minus
            lab_gplatz =Label (root, 
            text = gplatz,
            fg= "purple",
            bg = "black",
            font = "Roman 20",
                    )
            lab_gplatz.place(x=850, y=105)
            lab_platz =Label (root, 
            text = platz,
            fg= "purple",
            bg = "black",
            font = "Roman 20",
                    )
            lab_platz.place(x=330, y=500)
            lab_AP_Wert =Label (root, 
            text = Wert_AP,
            fg= "purple",
            bg= "black",
            font = "Roman 20",
                    )
            lab_AP_Wert.place(x=850, y=105)
            lab_Stabwaffen_AT_Wert = Label (root, 
            text = Wert_Stabwaffen_AT,
            fg= "purple",
            bg = "black",
            font = "Roman 20",
            )
            lab_Stabwaffen_AT.place(x=10, y=500)
            lab_Stabwaffen_AT_Wert.place(x=330, y=500)

    def RechneminusStabwaffen_AT():
        global Wert_AP
        global Wert_Stabwaffen_AT
        global lab_gplatz
        global gplatz
        global Wert_gesamt
        global platz
        global lab_platz
        if (Wert_Stabwaffen_AT>Wert_Rechne):
            Wert_AP += plus_minus
            Wert_Stabwaffen_AT -= plus_minus
            Wert_gesamt -= plus_minus
            lab_gplatz =Label (root, 
            text = gplatz,
            fg= "purple",
            bg = "black",
            font = "Roman 20",
                    )
            lab_gplatz.place(x=850, y=105)
            lab_platz =Label (root, 
            text = platz,
            fg= "purple",
            bg = "black",
            font = "Roman 20",
                    )
            lab_platz.place(x=330, y=500)
            lab_AP_Wert =Label (root, 
            text = Wert_AP,
            fg= "purple",
            bg = "black",
            font = "Roman 20",
                    )
            lab_AP_Wert.place(x=850, y=105)
            lab_Stabwaffen_AT_Wert = Label (root, 
            text = Wert_Stabwaffen_AT,
            fg= "purple",
            bg= "black",
            font = "Roman 20",
            )
            lab_Stabwaffen_AT.place(x=10, y=500)
            lab_Stabwaffen_AT_Wert.place(x=330, y=500)

    #------------------------------------------------------------------------------------------------------------#

    def RechneplusStabwaffen_PA():
        global Wert_AP
        global Wert_Stabwaffen_PA
        global lab_gplatz
        global gplatz
        global Wert_gesamt
        global platz
        global lab_platz
        if (Wert_AP>Wert_Rechne):
            Wert_Stabwaffen_PA += plus_minus
            Wert_AP -= plus_minus
            Wert_gesamt += plus_minus
            lab_gplatz =Label (root, 
            text = gplatz,
            fg= "purple",
            bg = "black",
            font = "Roman 20",
                    )
            lab_gplatz.place(x=850, y=105)
            lab_platz =Label (root, 
            text = platz,
            fg= "purple",
            bg = "black",
            font = "Roman 20",
                    )
            lab_platz.place(x=330, y=600)
            lab_AP_Wert =Label (root, 
            text = Wert_AP,
            fg= "purple",
            bg= "black",
            font = "Roman 20",
                    )
            lab_AP_Wert.place(x=850, y=105)
            lab_Stabwaffen_PA_Wert = Label (root, 
            text = Wert_Stabwaffen_PA,
            fg= "purple",
            bg = "black",
            font = "Roman 20",
            )
            lab_Stabwaffen_PA.place(x=10, y=600)
            lab_Stabwaffen_PA_Wert.place(x=330, y=600)

    def RechneminusStabwaffen_PA():
        global Wert_AP
        global Wert_Stabwaffen_PA
        global lab_gplatz
        global gplatz
        global Wert_gesamt
        global platz
        global lab_platz
        if (Wert_Stabwaffen_PA>Wert_Rechne):
            Wert_AP += plus_minus
            Wert_Stabwaffen_PA -= plus_minus
            Wert_gesamt -= plus_minus
            lab_gplatz =Label (root, 
            text = gplatz,
            fg= "purple",
            bg = "black",
            font = "Roman 20",
                    )
            lab_gplatz.place(x=850, y=105)
            lab_platz =Label (root, 
            text = platz,
            fg= "purple",
            bg = "black",
            font = "Roman 20",
                    )
            lab_platz.place(x=330, y=600)
            lab_AP_Wert =Label (root, 
            text = Wert_AP,
            fg= "purple",
            bg = "black",
            font = "Roman 20",
                    )
            lab_AP_Wert.place(x=850, y=105)
            lab_Stabwaffen_PA_Wert = Label (root, 
            text = Wert_Stabwaffen_PA,
            fg= "purple",
            bg= "black",
            font = "Roman 20",
            )
            lab_Stabwaffen_PA.place(x=10, y=600)
            lab_Stabwaffen_PA_Wert.place(x=330, y=600)

    #------------------------------------------------------------------------------------------------------------#

    def RechneplusSchleudern_AT():
        global Wert_AP
        global Wert_Schleudern_AT
        global lab_gplatz
        global gplatz
        global Wert_gesamt
        global platz
        global lab_platz
        if (Wert_AP>Wert_Rechne):
            Wert_Schleudern_AT += plus_minus
            Wert_AP -= plus_minus
            Wert_gesamt += plus_minus
            lab_gplatz =Label (root, 
            text = gplatz,
            fg= "purple",
            bg = "black",
            font = "Roman 20",
                    )
            lab_gplatz.place(x=850, y=105)
            lab_platz =Label (root, 
            text = platz,
            fg= "purple",
            bg = "black",
            font = "Roman 20",
                    )
            lab_platz.place(x=330, y=700)
            lab_AP_Wert =Label (root, 
            text = Wert_AP,
            fg= "purple",
            bg= "black",
            font = "Roman 20",
                    )
            lab_AP_Wert.place(x=850, y=105)
            lab_Schleudern_AT_Wert = Label (root, 
            text = Wert_Schleudern_AT,
            fg= "purple",
            bg = "black",
            font = "Roman 20",
            )
            lab_Schleudern_AT.place(x=10, y=700)
            lab_Schleudern_AT_Wert.place(x=330, y=700)

    def RechneminusSchleudern_AT():
        global Wert_AP
        global Wert_Schleudern_AT
        global lab_gplatz
        global gplatz
        global Wert_gesamt
        global platz
        global lab_platz
        if (Wert_Schleudern_AT>Wert_Rechne):
            Wert_AP += plus_minus
            Wert_Schleudern_AT -= plus_minus
            Wert_gesamt -= plus_minus
            lab_gplatz =Label (root, 
            text = gplatz,
            fg= "purple",
            bg = "black",
            font = "Roman 20",
                    )
            lab_gplatz.place(x=850, y=105)
            lab_platz =Label (root, 
            text = platz,
            fg= "purple",
            bg = "black",
            font = "Roman 20",
                    )
            lab_platz.place(x=330, y=700)
            lab_AP_Wert =Label (root, 
            text = Wert_AP,
            fg= "purple",
            bg = "black",
            font = "Roman 20",
                    )
            lab_AP_Wert.place(x=850, y=105)
            lab_Schleudern_AT_Wert = Label (root, 
            text = Wert_Schleudern_AT,
            fg= "purple",
            bg= "black",
            font = "Roman 20",
            )
            lab_Schleudern_AT.place(x=10, y=700)
            lab_Schleudern_AT_Wert.place(x=330, y=700)
    #------------------------------------------------------------------------------------------------------------#

    def RechneplusPeitschen_AT():
        global Wert_AP
        global Wert_Peitschen_AT
        global lab_gplatz
        global gplatz
        global Wert_gesamt
        global platz
        global lab_platz
        if (Wert_AP>Wert_Rechne):
            Wert_Peitschen_AT += plus_minus
            Wert_AP -= plus_minus
            Wert_gesamt += plus_minus
            lab_gplatz =Label (root, 
            text = gplatz,
            fg= "purple",
            bg = "black",
            font = "Roman 20",
                    )
            lab_gplatz.place(x=850, y=105)
            lab_platz =Label (root, 
            text = platz,
            fg= "purple",
            bg = "black",
            font = "Roman 20",
                    )
            lab_platz.place(x=330, y=800)
            lab_AP_Wert =Label (root, 
            text = Wert_AP,
            fg= "purple",
            bg= "black",
            font = "Roman 20",
                    )
            lab_AP_Wert.place(x=850, y=105)
            lab_Peitschen_AT_Wert = Label (root, 
            text = Wert_Peitschen_AT,
            fg= "purple",
            bg = "black",
            font = "Roman 20",
            )
            lab_Peitschen_AT.place(x=10, y=800)
            lab_Peitschen_AT_Wert.place(x=330, y=800)

    def RechneminusPeitschen_AT():
        global Wert_AP
        global Wert_Peitschen_AT
        global lab_gplatz
        global gplatz
        global Wert_gesamt
        global platz
        global lab_platz
        if (Wert_Peitschen_AT>Wert_Rechne):
            Wert_AP += plus_minus
            Wert_Peitschen_AT -= plus_minus
            Wert_gesamt -= plus_minus
            lab_gplatz =Label (root, 
            text = gplatz,
            fg= "purple",
            bg = "black",
            font = "Roman 20",
                    )
            lab_gplatz.place(x=850, y=105)
            lab_platz =Label (root, 
            text = platz,
            fg= "purple",
            bg = "black",
            font = "Roman 20",
                    )
            lab_platz.place(x=330, y=800)
            lab_AP_Wert =Label (root, 
            text = Wert_AP,
            fg= "purple",
            bg = "black",
            font = "Roman 20",
                    )
            lab_AP_Wert.place(x=850, y=105)
            lab_Peitschen_AT_Wert = Label (root, 
            text = Wert_Peitschen_AT,
            fg= "purple",
            bg= "black",
            font = "Roman 20",
            )
            lab_Peitschen_AT.place(x=10, y=800)
            lab_Peitschen_AT_Wert.place(x=330, y=800)

    #------------------------------------------------------------------------------------------------------------#

    def RechneplusArmbrust_AT():
        global Wert_AP
        global Wert_Armbrust_AT
        global lab_gplatz
        global gplatz
        global Wert_gesamt
        global platz
        global lab_platz
        if (Wert_AP>Wert_Rechne):
            Wert_Armbrust_AT += plus_minus
            Wert_AP -= plus_minus
            Wert_gesamt += plus_minus
            lab_gplatz =Label (root, 
            text = gplatz,
            fg= "purple",
            bg = "black",
            font = "Roman 20",
                    )
            lab_gplatz.place(x=850, y=105)
            lab_platz =Label (root, 
            text = platz,
            fg= "purple",
            bg = "black",
            font = "Roman 20",
                    )
            lab_platz.place(x=330, y=900)
            lab_AP_Wert =Label (root, 
            text = Wert_AP,
            fg= "purple",
            bg= "black",
            font = "Roman 20",
                    )
            lab_AP_Wert.place(x=850, y=105)
            lab_Armbrust_AT_Wert = Label (root, 
            text = Wert_Armbrust_AT,
            fg= "purple",
            bg = "black",
            font = "Roman 20",
            )
            lab_Armbrust_AT.place(x=10, y=900)
            lab_Armbrust_AT_Wert.place(x=330, y=900)

    def RechneminusArmbrust_AT():
        global Wert_AP
        global Wert_Armbrust_AT
        global lab_gplatz
        global gplatz
        global Wert_gesamt
        global platz
        global lab_platz
        if (Wert_Armbrust_AT>Wert_Rechne):
            Wert_AP += plus_minus
            Wert_Armbrust_AT -= plus_minus
            Wert_gesamt -= plus_minus
            lab_gplatz =Label (root, 
            text = gplatz,
            fg= "purple",
            bg = "black",
            font = "Roman 20",
                    )
            lab_gplatz.place(x=850, y=105)
            lab_platz =Label (root, 
            text = platz,
            fg= "purple",
            bg = "black",
            font = "Roman 20",
                    )
            lab_platz.place(x=330, y=900)
            lab_AP_Wert =Label (root, 
            text = Wert_AP,
            fg= "purple",
            bg = "black",
            font = "Roman 20",
                    )
            lab_AP_Wert.place(x=850, y=105)
            lab_Armbrust_AT_Wert = Label (root, 
            text = Wert_Armbrust_AT,
            fg= "purple",
            bg= "black",
            font = "Roman 20",
            )
            lab_Armbrust_AT.place(x=10, y=900)
            lab_Armbrust_AT_Wert.place(x=330, y=900)

    #------------------------------------------------------------------------------------------------------------#
    def RechneplusSchwerter_AT():
        global Wert_AP
        global Wert_Schwerter_AT
        global lab_gplatz
        global gplatz
        global Wert_gesamt
        global platz
        global lab_platz
        if (Wert_AP>Wert_Rechne):
            Wert_Schwerter_AT += plus_minus
            Wert_AP -= plus_minus
            Wert_gesamt += plus_minus
            lab_gplatz =Label (root, 
            text = gplatz,
            fg= "purple",
            bg = "black",
            font = "Roman 20",
                    )
            lab_gplatz.place(x=850, y=105)
            lab_platz =Label (root, 
            text = platz,
            fg= "purple",
            bg = "black",
            font = "Roman 20",
                    )
            lab_platz.place(x=700, y=200)
            lab_AP_Wert =Label (root, 
            text = Wert_AP,
            fg= "purple",
            bg= "black",
            font = "Roman 20",
                    )
            lab_AP_Wert.place(x=850, y=105)
            lab_Schwerter_AT_Wert = Label (root, 
            text = Wert_Schwerter_AT,
            fg= "purple",
            bg = "black",
            font = "Roman 20",
            )
            lab_Schwerter_AT.place(x=480, y=200)
            lab_Schwerter_AT_Wert.place(x=700, y=200)

    def RechneminusSchwerter_AT():
        global Wert_AP
        global Wert_Schwerter_AT
        global lab_gplatz
        global gplatz
        global Wert_gesamt
        global platz
        global lab_platz
        if (Wert_Schwerter_AT>Wert_Rechne):
            Wert_AP += plus_minus
            Wert_Schwerter_AT -= plus_minus
            Wert_gesamt -= plus_minus
            lab_gplatz =Label (root, 
            text = gplatz,
            fg= "purple",
            bg = "black",
            font = "Roman 20",
                    )
            lab_gplatz.place(x=850, y=105)
            lab_platz =Label (root, 
            text = platz,
            fg= "purple",
            bg = "black",
            font = "Roman 20",
                    )
            lab_platz.place(x=700, y=200)
            lab_AP_Wert =Label (root, 
            text = Wert_AP,
            fg= "purple",
            bg = "black",
            font = "Roman 20",
                    )
            lab_AP_Wert.place(x=850, y=105)
            lab_Schwerter_AT_Wert = Label (root, 
            text = Wert_Schwerter_AT,
            fg= "purple",
            bg= "black",
            font = "Roman 20",
            )
            lab_Schwerter_AT.place(x=480, y=200)
            lab_Schwerter_AT_Wert.place(x=700, y=200)

    #------------------------------------------------------------------------------------------------------------#

    def RechneplusSchwerter_PA():
        global Wert_AP
        global Wert_Schwerter_PA
        global lab_gplatz
        global gplatz
        global Wert_gesamt
        global platz
        global lab_platz
        if (Wert_AP>Wert_Rechne):
            Wert_Schwerter_PA += plus_minus
            Wert_AP -= plus_minus
            Wert_gesamt += plus_minus
            lab_gplatz =Label (root, 
            text = gplatz,
            fg= "purple",
            bg = "black",
            font = "Roman 20",
                    )
            lab_gplatz.place(x=850, y=105)
            lab_platz =Label (root, 
            text = platz,
            fg= "purple",
            bg = "black",
            font = "Roman 20",
                    )
            lab_platz.place(x=700, y=300)
            lab_AP_Wert =Label (root, 
            text = Wert_AP,
            fg= "purple",
            bg= "black",
            font = "Roman 20",
                    )
            lab_AP_Wert.place(x=850, y=105)
            lab_Schwerter_PA_Wert = Label (root, 
            text = Wert_Schwerter_PA,
            fg= "purple",
            bg = "black",
            font = "Roman 20",
            )
            lab_Schwerter_PA.place(x=480, y=300)
            lab_Schwerter_PA_Wert.place(x=700, y=300)

    def RechneminusSchwerter_PA():
        global Wert_AP
        global Wert_Schwerter_PA
        global lab_gplatz
        global gplatz
        global Wert_gesamt
        global platz
        global lab_platz
        if (Wert_Schwerter_PA>Wert_Rechne):
            Wert_AP += plus_minus
            Wert_Schwerter_PA -= plus_minus
            Wert_gesamt -= plus_minus
            lab_gplatz =Label (root, 
            text = gplatz,
            fg= "purple",
            bg = "black",
            font = "Roman 20",
                    )
            lab_gplatz.place(x=850, y=105)
            lab_platz =Label (root, 
            text = platz,
            fg= "purple",
            bg = "black",
            font = "Roman 20",
                    )
            lab_platz.place(x=700, y=300)
            lab_AP_Wert =Label (root, 
            text = Wert_AP,
            fg= "purple",
            bg = "black",
            font = "Roman 20",
                    )
            lab_AP_Wert.place(x=850, y=105)
            lab_Schwerter_PA_Wert = Label (root, 
            text = Wert_Schwerter_PA,
            fg= "purple",
            bg= "black",
            font = "Roman 20",
            )
            lab_Schwerter_PA.place(x=480, y=300)
            lab_Schwerter_PA_Wert.place(x=700, y=300)
        
    #------------------------------------------------------------------------------------------------------------#

    def RechneplusSchilde_AT():
        global Wert_AP
        global Wert_Schilde_AT
        global lab_gplatz
        global gplatz
        global Wert_gesamt
        global platz
        global lab_platz
        if (Wert_AP>Wert_Rechne):
            Wert_Schilde_AT += plus_minus
            Wert_AP -= plus_minus
            Wert_gesamt += plus_minus
            lab_gplatz =Label (root, 
            text = gplatz,
            fg= "purple",
            bg = "black",
            font = "Roman 20",
                    )
            lab_gplatz.place(x=850, y=105)
            lab_platz =Label (root, 
            text = platz,
            fg= "purple",
            bg = "black",
            font = "Roman 20",
                    )
            lab_platz.place(x=700, y=400)
            lab_AP_Wert =Label (root, 
            text = Wert_AP,
            fg= "purple",
            bg= "black",
            font = "Roman 20",
                    )
            lab_AP_Wert.place(x=850, y=105)
            lab_Schilde_AT_Wert = Label (root, 
            text = Wert_Schilde_AT,
            fg= "purple",
            bg = "black",
            font = "Roman 20",
            )
            lab_Schilde_AT.place(x=480, y=400)
            lab_Schilde_AT_Wert.place(x=700, y=400)

    def RechneminusSchilde_AT():
        global Wert_AP
        global Wert_Schilde_AT
        global lab_gplatz
        global gplatz
        global Wert_gesamt
        global platz
        global lab_platz
        if (Wert_Schilde_AT>Wert_Rechne):
            Wert_AP += plus_minus
            Wert_Schilde_AT -= plus_minus
            Wert_gesamt -= plus_minus
            lab_gplatz =Label (root, 
            text = gplatz,
            fg= "purple",
            bg = "black",
            font = "Roman 20",
                    )
            lab_gplatz.place(x=850, y=105)
            lab_platz =Label (root, 
            text = platz,
            fg= "purple",
            bg = "black",
            font = "Roman 20",
                    )
            lab_platz.place(x=700, y=400)
            lab_AP_Wert =Label (root, 
            text = Wert_AP,
            fg= "purple",
            bg = "black",
            font = "Roman 20",
                    )
            lab_AP_Wert.place(x=850, y=105)
            lab_Schilde_AT_Wert = Label (root, 
            text = Wert_Schilde_AT,
            fg= "purple",
            bg= "black",
            font = "Roman 20",
            )
            lab_Schilde_AT.place(x=480, y=400)
            lab_Schilde_AT_Wert.place(x=700, y=400)
     
    #------------------------------------------------------------------------------------------------------------#

    def RechneplusSchilde_PA():
        global Wert_AP
        global Wert_Schilde_PA
        global lab_gplatz
        global gplatz
        global Wert_gesamt
        global platz
        global lab_platz
        if (Wert_AP>Wert_Rechne):
            Wert_Schilde_PA += plus_minus
            Wert_AP -= plus_minus
            Wert_gesamt += plus_minus
            lab_gplatz =Label (root, 
            text = gplatz,
            fg= "purple",
            bg = "black",
            font = "Roman 20",
                    )
            lab_gplatz.place(x=850, y=105)
            lab_platz =Label (root, 
            text = platz,
            fg= "purple",
            bg = "black",
            font = "Roman 20",
                    )
            lab_platz.place(x=700, y=500)
            lab_AP_Wert =Label (root, 
            text = Wert_AP,
            fg= "purple",
            bg= "black",
            font = "Roman 20",
                    )
            lab_AP_Wert.place(x=850, y=105)
            lab_Schilde_PA_Wert = Label (root, 
            text = Wert_Schilde_PA,
            fg= "purple",
            bg = "black",
            font = "Roman 20",
            )
            lab_Schilde_PA.place(x=480, y=500)
            lab_Schilde_PA_Wert.place(x=700, y=500)

    def RechneminusSchilde_PA():
        global Wert_AP
        global Wert_Schilde_PA
        global lab_gplatz
        global gplatz
        global Wert_gesamt
        global platz
        global lab_platz
        if (Wert_Schilde_PA>Wert_Rechne):
            Wert_AP += plus_minus
            Wert_Schilde_PA -= plus_minus
            Wert_gesamt -= plus_minus
            lab_gplatz =Label (root, 
            text = gplatz,
            fg= "purple",
            bg = "black",
            font = "Roman 20",
                    )
            lab_gplatz.place(x=850, y=105)
            lab_platz =Label (root, 
            text = platz,
            fg= "purple",
            bg = "black",
            font = "Roman 20",
                    )
            lab_platz.place(x=700, y=500)
            lab_AP_Wert =Label (root, 
            text = Wert_AP,
            fg= "purple",
            bg = "black",
            font = "Roman 20",
                    )
            lab_AP_Wert.place(x=850, y=105)
            lab_Schilde_PA_Wert = Label (root, 
            text = Wert_Schilde_PA,
            fg= "purple",
            bg= "black",
            font = "Roman 20",
            )
            lab_Schilde_PA.place(x=480, y=500)
            lab_Schilde_PA_Wert.place(x=700, y=500)
     
    #------------------------------------------------------------------------------------------------------------#

    def RechneplusRaufen_AT():
        global Wert_AP
        global Wert_Raufen_AT
        global lab_gplatz
        global gplatz
        global Wert_gesamt
        global platz
        global lab_platz
        if (Wert_AP>Wert_Rechne):
            Wert_Raufen_AT += plus_minus
            Wert_AP -= plus_minus
            Wert_gesamt += plus_minus
            lab_gplatz =Label (root, 
            text = gplatz,
            fg= "purple",
            bg = "black",
            font = "Roman 20",
                    )
            lab_gplatz.place(x=850, y=105)
            lab_platz =Label (root, 
            text = platz,
            fg= "purple",
            bg = "black",
            font = "Roman 20",
                    )
            lab_platz.place(x=700, y=600)
            lab_AP_Wert =Label (root, 
            text = Wert_AP,
            fg= "purple",
            bg= "black",
            font = "Roman 20",
                    )
            lab_AP_Wert.place(x=850, y=105)
            lab_Raufen_AT_Wert = Label (root, 
            text = Wert_Raufen_AT,
            fg= "purple",
            bg = "black",
            font = "Roman 20",
            )
            lab_Raufen_AT.place(x=480, y=600)
            lab_Raufen_AT_Wert.place(x=700, y=600)

    def RechneminusRaufen_AT():
        global Wert_AP
        global Wert_Raufen_AT
        global lab_gplatz
        global gplatz
        global Wert_gesamt
        global platz
        global lab_platz
        if (Wert_Raufen_AT>Wert_Rechne):
            Wert_AP += plus_minus
            Wert_Raufen_AT -= plus_minus
            Wert_gesamt -= plus_minus
            lab_gplatz =Label (root, 
            text = gplatz,
            fg= "purple",
            bg = "black",
            font = "Roman 20",
                    )
            lab_gplatz.place(x=850, y=105)
            lab_platz =Label (root, 
            text = platz,
            fg= "purple",
            bg = "black",
            font = "Roman 20",
                    )
            lab_platz.place(x=700, y=600)
            lab_AP_Wert =Label (root, 
            text = Wert_AP,
            fg= "purple",
            bg = "black",
            font = "Roman 20",
                    )
            lab_AP_Wert.place(x=850, y=105)
            lab_Raufen_AT_Wert = Label (root, 
            text = Wert_Raufen_AT,
            fg= "purple",
            bg= "black",
            font = "Roman 20",
            )
            lab_Raufen_AT.place(x=480, y=600)
            lab_Raufen_AT_Wert.place(x=700, y=600)
     
    #------------------------------------------------------------------------------------------------------------#

    def RechneplusRaufen_PA():
        global Wert_AP
        global Wert_Raufen_PA
        global lab_gplatz
        global gplatz
        global Wert_gesamt
        global platz
        global lab_platz
        if (Wert_AP>Wert_Rechne):
            Wert_Raufen_PA += plus_minus
            Wert_AP -= plus_minus
            Wert_gesamt += plus_minus
            lab_gplatz =Label (root, 
            text = gplatz,
            fg= "purple",
            bg = "black",
            font = "Roman 20",
                    )
            lab_gplatz.place(x=850, y=105)
            lab_platz =Label (root, 
            text = platz,
            fg= "purple",
            bg = "black",
            font = "Roman 20",
                    )
            lab_platz.place(x=700, y=700)
            lab_AP_Wert =Label (root, 
            text = Wert_AP,
            fg= "purple",
            bg= "black",
            font = "Roman 20",
                    )
            lab_AP_Wert.place(x=850, y=105)
            lab_Raufen_PA_Wert = Label (root, 
            text = Wert_Raufen_PA,
            fg= "purple",
            bg = "black",
            font = "Roman 20",
            )
            lab_Raufen_PA.place(x=480, y=700)
            lab_Raufen_PA_Wert.place(x=700, y=700)

    def RechneminusRaufen_PA():
        global Wert_AP
        global Wert_Raufen_PA
        global lab_gplatz
        global gplatz
        global Wert_gesamt
        global platz
        global lab_platz
        if (Wert_Raufen_PA>Wert_Rechne):
            Wert_AP += plus_minus
            Wert_Raufen_PA -= plus_minus
            Wert_gesamt -= plus_minus
            lab_gplatz =Label (root, 
            text = gplatz,
            fg= "purple",
            bg = "black",
            font = "Roman 20",
                    )
            lab_gplatz.place(x=850, y=105)
            lab_platz =Label (root, 
            text = platz,
            fg= "purple",
            bg = "black",
            font = "Roman 20",
                    )
            lab_platz.place(x=700, y=700)
            lab_AP_Wert =Label (root, 
            text = Wert_AP,
            fg= "purple",
            bg = "black",
            font = "Roman 20",
                    )
            lab_AP_Wert.place(x=850, y=105)
            lab_Raufen_PA_Wert = Label (root, 
            text = Wert_Raufen_PA,
            fg= "purple",
            bg= "black",
            font = "Roman 20",
            )
            lab_Raufen_PA.place(x=480, y=700)
            lab_Raufen_PA_Wert.place(x=700, y=700)
     
    #------------------------------------------------------------------------------------------------------------#

    def RechneplusDolche_AT():
        global Wert_AP
        global Wert_Dolche_AT
        global lab_gplatz
        global gplatz
        global Wert_gesamt
        global platz
        global lab_platz
        if (Wert_AP>Wert_Rechne):
            Wert_Dolche_AT += plus_minus
            Wert_AP -= plus_minus
            Wert_gesamt += plus_minus
            lab_gplatz =Label (root, 
            text = gplatz,
            fg= "purple",
            bg = "black",
            font = "Roman 20",
                    )
            lab_gplatz.place(x=850, y=105)
            lab_platz =Label (root, 
            text = platz,
            fg= "purple",
            bg = "black",
            font = "Roman 20",
                    )
            lab_platz.place(x=700, y=800)
            lab_AP_Wert =Label (root, 
            text = Wert_AP,
            fg= "purple",
            bg= "black",
            font = "Roman 20",
                    )
            lab_AP_Wert.place(x=850, y=105)
            lab_Dolche_AT_Wert = Label (root, 
            text = Wert_Dolche_AT,
            fg= "purple",
            bg = "black",
            font = "Roman 20",
            )
            lab_Dolche_AT.place(x=480, y=800)
            lab_Dolche_AT_Wert.place(x=700, y=800)

    def RechneminusDolche_AT():
        global Wert_AP
        global Wert_Dolche_AT
        global lab_gplatz
        global gplatz
        global Wert_gesamt
        global platz
        global lab_platz
        if (Wert_Dolche_AT>Wert_Rechne):
            Wert_AP += plus_minus
            Wert_Dolche_AT -= plus_minus
            Wert_gesamt -= plus_minus
            lab_gplatz =Label (root, 
            text = gplatz,
            fg= "purple",
            bg = "black",
            font = "Roman 20",
                    )
            lab_gplatz.place(x=850, y=105)
            lab_platz =Label (root, 
            text = platz,
            fg= "purple",
            bg = "black",
            font = "Roman 20",
                    )
            lab_platz.place(x=700, y=800)
            lab_AP_Wert =Label (root, 
            text = Wert_AP,
            fg= "purple",
            bg = "black",
            font = "Roman 20",
                    )
            lab_AP_Wert.place(x=850, y=105)
            lab_Dolche_AT_Wert = Label (root, 
            text = Wert_Dolche_AT,
            fg= "purple",
            bg= "black",
            font = "Roman 20",
            )
            lab_Dolche_AT.place(x=480, y=800)
            lab_Dolche_AT_Wert.place(x=700, y=800)
     
    #------------------------------------------------------------------------------------------------------------#

    def RechneplusDolche_PA():
        global Wert_AP
        global Wert_Dolche_PA
        global lab_gplatz
        global gplatz
        global Wert_gesamt
        global platz
        global lab_platz
        if (Wert_AP>Wert_Rechne):
            Wert_Dolche_PA += plus_minus
            Wert_AP -= plus_minus
            Wert_gesamt += plus_minus
            lab_gplatz =Label (root, 
            text = gplatz,
            fg= "purple",
            bg = "black",
            font = "Roman 20",
                    )
            lab_gplatz.place(x=850, y=105)
            lab_platz =Label (root, 
            text = platz,
            fg= "purple",
            bg = "black",
            font = "Roman 20",
                    )
            lab_platz.place(x=700, y=900)
            lab_AP_Wert =Label (root, 
            text = Wert_AP,
            fg= "purple",
            bg= "black",
            font = "Roman 20",
                    )
            lab_AP_Wert.place(x=850, y=105)
            lab_Dolche_PA_Wert = Label (root, 
            text = Wert_Dolche_PA,
            fg= "purple",
            bg = "black",
            font = "Roman 20",
            )
            lab_Dolche_PA.place(x=480, y=900)
            lab_Dolche_PA_Wert.place(x=700, y=900)

    def RechneminusDolche_PA():
        global Wert_AP
        global Wert_Dolche_PA
        global lab_gplatz
        global gplatz
        global Wert_gesamt
        global platz
        global lab_platz
        if (Wert_Dolche_PA>Wert_Rechne):
            Wert_AP += plus_minus
            Wert_Dolche_PA -= plus_minus
            Wert_gesamt -= plus_minus
            lab_gplatz =Label (root, 
            text = gplatz,
            fg= "purple",
            bg = "black",
            font = "Roman 20",
                    )
            lab_gplatz.place(x=850, y=105)
            lab_platz =Label (root, 
            text = platz,
            fg= "purple",
            bg = "black",
            font = "Roman 20",
                    )
            lab_platz.place(x=700, y=900)
            lab_AP_Wert =Label (root, 
            text = Wert_AP,
            fg= "purple",
            bg = "black",
            font = "Roman 20",
                    )
            lab_AP_Wert.place(x=850, y=105)
            lab_Dolche_PA_Wert = Label (root, 
            text = Wert_Dolche_PA,
            fg= "purple",
            bg= "black",
            font = "Roman 20",
            )
            lab_Dolche_PA.place(x=480, y=900)
            lab_Dolche_PA_Wert.place(x=700, y=900)
     
    #------------------------------------------------------------------------------------------------------------#
    def RechneplusBoegen_AT():
        global Wert_AP
        global Wert_Boegen_AT
        global lab_gplatz
        global gplatz
        global Wert_gesamt
        global platz
        global lab_platz
        if (Wert_AP>Wert_Rechne):
            Wert_Boegen_AT += plus_minus
            Wert_AP -= plus_minus
            Wert_gesamt += plus_minus
            lab_gplatz =Label (root, 
            text = gplatz,
            fg= "purple",
            bg = "black",
            font = "Roman 20",
                    )
            lab_gplatz.place(x=850, y=105)
            lab_platz =Label (root, 
            text = platz,
            fg= "purple",
            bg = "black",
            font = "Roman 20",
                    )
            lab_platz.place(x=1020, y=200)
            lab_AP_Wert =Label (root, 
            text = Wert_AP,
            fg= "purple",
            bg= "black",
            font = "Roman 20",
                    )
            lab_AP_Wert.place(x=850, y=105)
            lab_Boegen_AT_Wert = Label (root, 
            text = Wert_Boegen_AT,
            fg= "purple",
            bg = "black",
            font = "Roman 20",
            )
            lab_Boegen_AT.place(x=850, y=200)
            lab_Boegen_AT_Wert.place(x=1020, y=200)

    def RechneminusBoegen_AT():
        global Wert_AP
        global Wert_Boegen_AT
        global lab_gplatz
        global gplatz
        global Wert_gesamt
        global platz
        global lab_platz
        if (Wert_Boegen_AT>Wert_Rechne):
            Wert_Boegen_AT -= plus_minus
            Wert_AP += plus_minus
            Wert_gesamt += plus_minus
            lab_gplatz =Label (root, 
            text = gplatz,
            fg= "purple",
            bg = "black",
            font = "Roman 20",
                    )
            lab_gplatz.place(x=850, y=105)
            lab_platz =Label (root, 
            text = platz,
            fg= "purple",
            bg = "black",
            font = "Roman 20",
                    )
            lab_platz.place(x=1020, y=200)
            lab_AP_Wert =Label (root, 
            text = Wert_AP,
            fg= "purple",
            bg= "black",
            font = "Roman 20",
                    )
            lab_AP_Wert.place(x=850, y=105)
            lab_Boegen_AT_Wert = Label (root, 
            text = Wert_Boegen_AT,
            fg= "purple",
            bg = "black",
            font = "Roman 20",
            )
            lab_Boegen_AT.place(x=850, y=200)
            lab_Boegen_AT_Wert.place(x=1020, y=200)
     #------------------------------------------------------------------------------------------------------------#
    def RechneplusZauber():
        global Wert_AP
        global Wert_Zauber
        global lab_gplatz
        global gplatz
        global Wert_gesamt
        global platz
        global lab_platz
        if (Wert_AP>0):
            Wert_Zauber += 1
            Wert_AP -= 100
            Wert_gesamt += 1
            lab_gplatz =Label (root, 
            text = gplatz,
            fg= "purple",
            bg = "black",
            font = "Roman 20",
                    )
            lab_gplatz.place(x=850, y=105)
            lab_platz =Label (root, 
            text = platz,
            fg= "purple",
            bg = "black",
            font = "Roman 20",
                    )
            lab_platz.place(x=1020, y=300)
            lab_AP_Wert =Label (root, 
            text = Wert_AP,
            fg= "purple",
            bg= "black",
            font = "Roman 20",
                    )
            lab_AP_Wert.place(x=850, y=105)
            lab_Zauber_Wert = Label (root, 
            text = Wert_Zauber,
            fg= "purple",
            bg = "black",
            font = "Roman 20",
            )
            lab_Zauber_Wert.place(x=850, y=300)
            lab_Zauber_Wert.place(x=1020, y=300)

    def RechneminusZauber():
        global Wert_AP
        global Wert_Zauber
        global lab_gplatz
        global gplatz
        global Wert_gesamt
        global platz
        global lab_platz
        if (Wert_Zauber>0):
            Wert_Zauber -= 1
            Wert_AP += 100
            Wert_gesamt += plus_minus
            lab_gplatz =Label (root, 
            text = gplatz,
            fg= "purple",
            bg = "black",
            font = "Roman 20",
                    )
            lab_gplatz.place(x=850, y=105)
            lab_platz =Label (root, 
            text = platz,
            fg= "purple",
            bg = "black",
            font = "Roman 20",
                    )
            lab_platz.place(x=1020, y=300)
            lab_AP_Wert =Label (root, 
            text = Wert_AP,
            fg= "purple",
            bg= "black",
            font = "Roman 20",
                    )
            lab_AP_Wert.place(x=850, y=105)
            lab_Zauber_Wert = Label (root, 
            text = Wert_Zauber,
            fg= "purple",
            bg = "black",
            font = "Roman 20",
            )
            lab_Zauber.place(x=850, y=300)
            lab_Zauber_Wert.place(x=1020, y=300)       
     #------------------------------------------------------------------------------------------------------------#
    def RechneplusFaehigkeiten():
        global Wert_AP
        global Wert_Faehigkeiten
        global lab_gplatz
        global gplatz
        global Wert_gesamt
        global platz
        global lab_platz
        if (Wert_AP>0):
            Wert_Faehigkeiten += 1
            Wert_AP -= 100
            Wert_gesamt += 1
            lab_gplatz =Label (root, 
            text = gplatz,
            fg= "purple",
            bg = "black",
            font = "Roman 20",
                    )
            lab_gplatz.place(x=850, y=105)
            lab_platz =Label (root, 
            text = platz,
            fg= "purple",
            bg = "black",
            font = "Roman 20",
                    )
            lab_platz.place(x=1020, y=400)
            lab_AP_Wert =Label (root, 
            text = Wert_AP,
            fg= "purple",
            bg= "black",
            font = "Roman 20",
                    )
            lab_AP_Wert.place(x=850, y=105)
            lab_Faehigkeiten_Wert = Label (root, 
            text = Wert_Faehigkeiten,
            fg= "purple",
            bg = "black",
            font = "Roman 20",
            )
            lab_Faehigkeiten_Wert.place(x=850, y=400)
            lab_Faehigkeiten_Wert.place(x=1020, y=400)

    def RechneminusFaehigkeiten():
        global Wert_AP
        global Wert_Faehigkeiten
        global lab_gplatz
        global gplatz
        global Wert_gesamt
        global platz
        global lab_platz
        if (Wert_Faehigkeiten>0):
            Wert_Faehigkeiten -= 1
            Wert_AP += 100
            Wert_gesamt += 1
            lab_gplatz =Label (root, 
            text = gplatz,
            fg= "purple",
            bg = "black",
            font = "Roman 20",
                    )
            lab_gplatz.place(x=850, y=105)
            lab_platz =Label (root, 
            text = platz,
            fg= "purple",
            bg = "black",
            font = "Roman 20",
                    )
            lab_platz.place(x=1020, y=400)
            lab_AP_Wert =Label (root, 
            text = Wert_AP,
            fg= "purple",
            bg= "black",
            font = "Roman 20",
                    )
            lab_AP_Wert.place(x=850, y=105)
            lab_Faehigkeiten_Wert = Label (root, 
            text = Wert_Faehigkeiten,
            fg= "purple",
            bg = "black",
            font = "Roman 20",
            )
            lab_Faehigkeiten.place(x=850, y=400)
            lab_Faehigkeiten_Wert.place(x=1020, y=400)   
    #############################################################################################################
    #############################################################################################################
    #but_nextPage =Button(root,text="Seite vor",fg="purple",bg="black",font = "Arial 20", command= nextPage )
    #but_prevPage =Button(root,text="Seite zurueck",fg="purple",bg="black",font = "Arial 20", command= prevPage )



    #------------------------------------------------------------------------------------------------------------#

    but_AP_pluseins =Button(root,text="+ 1",fg="green",bg="black",font = "Roman 10", command= RechnepluseinsAP )
    but_AP_minuseins=Button(root,text="- 1",fg="green",bg="black",font = "Roman 10", command=RechneminuseinsAP)

    but_AP_pluszehn =Button(root,text="+ 10",fg="green",bg="black",font = "Roman 10", command= RechnepluszehnAP )
    but_AP_minuszehn=Button(root,text="- 10",fg="green",bg="black",font = "Roman 10", command=RechneminuszehnAP)

    but_AP_plushundert =Button(root,text="+ 100",fg="green",bg="black",font = "Roman 10", command= RechneplushundertAP )
    but_AP_minushundert=Button(root,text="- 100",fg="green",bg="black",font = "Roman 10", command=RechneminushundertAP)

    #------------------------------------------------------------------------------------------------------------#
    but_Rechne1 = Button (root,text="Um Eins steigern",fg="purple",bg="black",font = "Arial 20", command= Rechne1 )
    but_Rechne10 = Button (root,text="Um Zehn steigern",fg="purple",bg="black",font = "Arial 20", command= Rechne10 )
    #------------------------------------------------------------------------------------------------------------#
    but_Intelligenz_plus =Button(root,text="+",fg="green",bg="black",font = "Roman 10", command=lambda: [RechneplusIntelligenz()])
    but_Intelligenz_minus=Button(root,text="-",fg="green",bg="black",font = "Roman 10", command=lambda: [RechneminusIntelligenz()])

    but_Kraft_plus =Button(root,text="+",fg="green",bg="black",font = "Roman 10", command=lambda: [RechneplusKraft()])
    but_Kraft_minus=Button(root,text="-", fg="green",bg="black",font = "Roman 10",command=lambda: [RechneminusKraft()])

    but_Ausdauer_plus =Button(root,text="+",fg="green",bg="black",font = "Roman 10", command=lambda: [RechneplusAusdauer()]) 
    but_Ausdauer_minus=Button(root,text="-",fg="green",bg="black",font = "Roman 10", command=lambda: [RechneminusAusdauer()])

    but_Charisma_plus =Button(root,text="+",fg="green",bg="black",font = "Roman 10", command=lambda: [RechneplusCharisma()]) 
    but_Charisma_minus=Button(root,text="-",fg="green",bg="black",font = "Roman 10", command=lambda: [RechneminusCharisma()])

    but_Intuition_plus =Button(root,text="+",fg="green",bg="black",font = "Roman 10", command=lambda: [RechneplusIntuition()])
    but_Intuition_minus=Button(root,text="-",fg="green",bg="black",font = "Roman 10", command=lambda: [RechneminusIntuition()])

    but_Fingerfertigkeit_plus =Button(root,text="+",fg="green",bg="black",font = "Roman 10", command=lambda: [RechneplusFingerfertigkeit()])
    but_Fingerfertigkeit_minus=Button(root,text="-",fg="green",bg="black",font = "Roman 10", command=lambda: [RechneminusFingerfertigkeit()])

    #------------------------------------------------------------------------------------------------------------#

    but_Wurfwaffen_AT_plus =Button(root,text="+",fg="purple",bg="black",font = "Roman 10", command=lambda: [RechneplusWurfwaffen_AT()])
    but_Wurfwaffen_AT_minus=Button(root,text="-",fg="purple",bg="black",font = "Roman 10", command=lambda: [RechneminusWurfwaffen_AT()])

    but_Hiebwaffen_AT_plus =Button(root,text="+",fg="purple",bg="black",font = "Roman 10", command=lambda: [RechneplusHiebwaffen_AT()])
    but_Hiebwaffen_AT_minus=Button(root,text="-",fg="purple",bg="black",font = "Roman 10", command=lambda: [RechneminusHiebwaffen_AT()])

    but_Hiebwaffen_PA_plus =Button(root,text="+",fg="purple",bg="black",font = "Roman 10", command=lambda: [RechneplusHiebwaffen_PA()])
    but_Hiebwaffen_PA_minus=Button(root,text="-",fg="purple",bg="black",font = "Roman 10", command=lambda: [RechneminusHiebwaffen_PA()])

    but_Stabwaffen_AT_plus =Button(root,text="+",fg="purple",bg="black",font = "Roman 10", command=lambda: [RechneplusStabwaffen_AT()])
    but_Stabwaffen_AT_minus=Button(root,text="-",fg="purple",bg="black",font = "Roman 10", command=lambda: [RechneminusStabwaffen_AT()])

    but_Stabwaffen_PA_plus =Button(root,text="+",fg="purple",bg="black",font = "Roman 10", command=lambda: [RechneplusStabwaffen_PA()])
    but_Stabwaffen_PA_minus=Button(root,text="-",fg="purple",bg="black",font = "Roman 10", command=lambda: [RechneminusStabwaffen_PA()])

    but_Schleudern_AT_plus =Button(root,text="+",fg="purple",bg="black",font = "Roman 10", command=lambda: [RechneplusSchleudern_AT()])
    but_Schleudern_AT_minus=Button(root,text="-",fg="purple",bg="black",font = "Roman 10", command=lambda: [RechneminusSchleudern_AT()])

    but_Peitschen_AT_plus =Button(root,text="+",fg="purple",bg="black",font = "Roman 10", command=lambda: [RechneplusPeitschen_AT()])
    but_Peitschen_AT_minus=Button(root,text="-",fg="purple",bg="black",font = "Roman 10", command=lambda: [RechneminusPeitschen_AT()])

    but_Armbrust_AT_plus =Button(root,text="+",fg="purple",bg="black",font = "Roman 10", command=lambda: [RechneplusArmbrust_AT()])
    but_Armbrust_AT_minus=Button(root,text="-",fg="purple",bg="black",font = "Roman 10", command=lambda: [RechneminusArmbrust_AT()])

    but_Schwerter_AT_plus =Button(root,text="+",fg="purple",bg="black",font = "Roman 10", command=lambda: [RechneplusSchwerter_AT()])
    but_Schwerter_AT_minus=Button(root,text="-",fg="purple",bg="black",font = "Roman 10", command=lambda: [RechneminusSchwerter_AT()])

    but_Schwerter_PA_plus =Button(root,text="+",fg="purple",bg="black",font = "Roman 10", command=lambda: [RechneplusSchwerter_PA()])
    but_Schwerter_PA_minus=Button(root,text="-",fg="purple",bg="black",font = "Roman 10", command=lambda: [RechneminusSchwerter_PA()])

    but_Schilde_AT_plus =Button(root,text="+",fg="purple",bg="black",font = "Roman 10", command=lambda: [RechneplusSchilde_AT()])
    but_Schilde_AT_minus=Button(root,text="-",fg="purple",bg="black",font = "Roman 10", command=lambda: [RechneminusSchilde_AT()])

    but_Schilde_PA_plus =Button(root,text="+",fg="purple",bg="black",font = "Roman 10", command=lambda: [RechneplusSchilde_PA()])
    but_Schilde_PA_minus=Button(root,text="-",fg="purple",bg="black",font = "Roman 10", command=lambda: [RechneminusSchilde_PA()])

    but_Raufen_AT_plus =Button(root,text="+",fg="purple",bg="black",font = "Roman 10", command=lambda: [RechneplusRaufen_AT()])
    but_Raufen_AT_minus=Button(root,text="-",fg="purple",bg="black",font = "Roman 10", command=lambda: [RechneminusRaufen_AT()])

    but_Raufen_PA_plus =Button(root,text="+",fg="purple",bg="black",font = "Roman 10", command=lambda: [RechneplusRaufen_PA()])
    but_Raufen_PA_minus=Button(root,text="-",fg="purple",bg="black",font = "Roman 10", command=lambda: [RechneminusRaufen_PA()])

    but_Dolche_AT_plus =Button(root,text="+",fg="purple",bg="black",font = "Roman 10", command=lambda: [RechneplusDolche_AT()])
    but_Dolche_AT_minus=Button(root,text="-",fg="purple",bg="black",font = "Roman 10", command=lambda: [RechneminusDolche_AT()])

    but_Dolche_PA_plus =Button(root,text="+",fg="purple",bg="black",font = "Roman 10", command=lambda: [RechneplusDolche_PA()])
    but_Dolche_PA_minus=Button(root,text="-",fg="purple",bg="black",font = "Roman 10", command=lambda: [RechneminusDolche_PA()])

    but_Boegen_AT_plus =Button(root,text="+",fg="purple",bg="black",font = "Roman 10", command=lambda: [RechneplusBoegen_AT()])
    but_Boegen_AT_minus=Button(root,text="-",fg="purple",bg="black",font = "Roman 10", command=lambda: [RechneminusBoegen_AT()])
    
    but_Zauber_plus =Button(root,text="+",fg="purple",bg="black",font = "Roman 10", command=lambda: [RechneplusZauber()])
    but_Zauber_minus=Button(root,text="-",fg="purple",bg="black",font = "Roman 10", command=lambda: [RechneminusZauber()])
    
    but_Faehigkeiten_plus =Button(root,text="+",fg="purple",bg="black",font = "Roman 10", command=lambda: [RechneplusFaehigkeiten()])
    but_Faehigkeiten_minus=Button(root,text="-",fg="purple",bg="black",font = "Roman 10", command=lambda: [RechneminusFaehigkeiten()])
    #############################################################################################################
    ##################################Es folgt die Grafische Umsetzung der Werte#################################
    #############################################################################################################

    but_Rechne1.place(x= 1600, y=250)
    but_Rechne10.place(x =1600 ,y= 350)
    #------------------------------------------------------------------------------------------------------------#

    #------------------------------------------------------------------------------------------------------------#

    lab_AP = Label (root, 
                 text = "AP",
                 fg= "green",
                 bg = "black",
                 font = "Roman 20",
                 )
    lab_AP_Wert = Label (root, 
                 text = Wert_AP,
                 fg= "green",
                 bg = "black",
                 font = "Roman 20",
                 )
    lab_AP.place(x=750, y=105)
    lab_AP_Wert.place(x=850, y=105)
    but_AP_pluseins.place(x= 1340, y=105)
    but_AP_minuseins.place(x= 310, y=105)
    but_AP_pluszehn.place(x= 1440, y=105)
    but_AP_minuszehn.place(x= 410, y=105) 
    but_AP_plushundert.place(x= 1540, y=105)
    but_AP_minushundert.place(x= 510, y=105) 

    lab_Intelligenz = Label (root, 
                 text = "Intelligenz",
                 fg= "green",
                 bg = "black",
                 font = "Roman 20",
                 )
    lab_Intelligenz_Wert = Label (root, 
                 text = Wert_Intelligenz,
                 fg= "green",
                 bg = "black",
                 font = "Roman 20",
                 )
    lab_Intelligenz.place(x=10, y=10)
    lab_Intelligenz_Wert.place(x=160, y=10)
    but_Intelligenz_plus.place(x= 140, y=10)
    but_Intelligenz_minus.place(x= 210, y=10) 
    #------------------------------------------------------------------------------------------------------------#
    lab_Kraft = Label (root, 
                 text = "Kraft",
                 fg= "green",
                 bg = "black",
                 font = "Roman 20",
                 )
    lab_Kraft_Wert = Label (root, 
                 text = Wert_Kraft,
                 fg= "green",
                 bg = "black",
                 font = "Roman 20",
                 )
    lab_Kraft.place(x=310, y=10)
    lab_Kraft_Wert.place(x=410, y=10)
    but_Kraft_plus.place(x= 390, y=10)
    but_Kraft_minus.place(x= 460, y=10) 
    #------------------------------------------------------------------------------------------------------------#
    lab_Ausdauer = Label (root, 
                 text = "Ausdauer",
                 fg= "green",
                 bg = "black",
                 font = "Roman 20",
                 )
    lab_Ausdauer_Wert = Label (root, 
                 text = Wert_Ausdauer,
                 fg= "green",
                 bg = "black",
                 font = "Roman 20",
                 )
    lab_Ausdauer.place(x=560, y=10)
    lab_Ausdauer_Wert.place(x=690, y=10)
    but_Ausdauer_plus.place(x= 670, y=10)
    but_Ausdauer_minus.place(x= 740, y=10)
    #------------------------------------------------------------------------------------------------------------#             
    lab_Charisma = Label (root, 
                 text = "Charisma",
                 fg= "green",
                 bg = "black",
                 font = "Roman 20",
                 )
    lab_Charisma_Wert = Label (root, 
                 text = Wert_Ausdauer,
                 fg= "green",
                 bg = "black",
                 font = "Roman 20",
                 )
    lab_Charisma.place(x=840, y=10)       
    lab_Charisma_Wert.place(x=980, y=10)
    but_Charisma_plus.place(x= 960, y=10)
    but_Charisma_minus.place(x= 1030, y=10)
    #------------------------------------------------------------------------------------------------------------#
    lab_Intuition = Label (root, 
                 text = "Intuition",
                 fg= "green",
                 bg = "black",
                 font = "Roman 20",
                 )
    lab_Intuition_Wert = Label (root, 
                 text = Wert_Intuition,
                 fg= "green",
                 bg = "black",
                 font = "Roman 20",
                 )
    lab_Intuition.place(x=1130, y=10)
    lab_Intuition_Wert.place(x=1270, y=10)
    but_Intuition_plus.place(x= 1250, y=10)
    but_Intuition_minus.place(x= 1320, y=10)
    #------------------------------------------------------------------------------------------------------------#
    lab_Fingerfertigkeit  = Label (root, 
                 text = "Fingerfertigkeit ",
                 fg= "green",
                 bg = "black",
                 font = "Roman 20",
                 )
    lab_Fingerfertigkeit_Wert = Label (root, 
                 text = Wert_Fingerfertigkeit,
                 fg= "green",
                 bg = "black",
                 font = "Roman 20",
                 )
    lab_Fingerfertigkeit.place(x=1420, y=10)
    lab_Fingerfertigkeit_Wert.place(x=1630, y=10)
    but_Fingerfertigkeit_plus.place(x= 1610, y=10)
    but_Fingerfertigkeit_minus.place(x= 1680, y=10)
    ##############################################################################################################
    lab_Wurfwaffen_AT = Label (root, 
                 text = "Wurfwaffen_AT",
                 fg= "purple",
                 bg = "black",
                 font = "Roman 20",
                 )
    lab_Wurfwaffen_AT_Wert = Label (root, 
                 text = Wert_Wurfwaffen_AT,
                 fg= "purple",
                 bg = "black",
                 font = "Roman 20",
                 )
    lab_Wurfwaffen_AT.place(x=10, y=200)
    lab_Wurfwaffen_AT_Wert.place(x=330, y=200)
    but_Wurfwaffen_AT_plus.place(x= 310, y=200)
    but_Wurfwaffen_AT_minus.place(x= 380, y=200) 
    #------------------------------------------------------------------------------------------------------------#
    lab_Hiebwaffen_AT = Label (root, 
                 text = "Hiebwaffen_AT",
                 fg= "purple",
                 bg = "black",
                 font = "Roman 20",
                 )
    lab_Hiebwaffen_AT_Wert = Label (root, 
                 text = Wert_Hiebwaffen_AT,
                 fg= "purple",
                 bg = "black",
                 font = "Roman 20",
                 )
    lab_Hiebwaffen_AT.place(x=10, y=300)
    lab_Hiebwaffen_AT_Wert.place(x=330, y=300)
    but_Hiebwaffen_AT_plus.place(x= 310, y=300)
    but_Hiebwaffen_AT_minus.place(x= 380, y=300)
    #------------------------------------------------------------------------------------------------------------#
    lab_Hiebwaffen_PA = Label (root, 
                 text = "Hiebwaffen_PA",
                 fg= "purple",
                 bg = "black",
                 font = "Roman 20",
                 )
    lab_Hiebwaffen_PA_Wert = Label (root, 
                 text = Wert_Hiebwaffen_PA,
                 fg= "purple",
                 bg = "black",
                 font = "Roman 20",
                 )
    lab_Hiebwaffen_PA.place(x=10, y=400)
    lab_Hiebwaffen_PA_Wert.place(x=330, y=400)
    but_Hiebwaffen_PA_plus.place(x= 310, y=400)
    but_Hiebwaffen_PA_minus.place(x= 380, y=400)
    #------------------------------------------------------------------------------------------------------------#
    lab_Stabwaffen_AT = Label (root, 
                 text = "Stabwaffen_AT",
                 fg= "purple",
                 bg = "black",
                 font = "Roman 20",
                 )
    lab_Stabwaffen_AT_Wert = Label (root, 
                 text = Wert_Stabwaffen_AT,
                 fg= "purple",
                 bg = "black",
                 font = "Roman 20",
                 )
    lab_Stabwaffen_AT.place(x=10, y=500)
    lab_Stabwaffen_AT_Wert.place(x=330, y=500)
    but_Stabwaffen_AT_plus.place(x= 310, y=500)
    but_Stabwaffen_AT_minus.place(x= 380, y=500)
    #------------------------------------------------------------------------------------------------------------#
    lab_Stabwaffen_PA = Label (root, 
                 text = "Stabwaffen_PA",
                 fg= "purple",
                 bg = "black",
                 font = "Roman 20",
                 )
    lab_Stabwaffen_PA_Wert = Label (root, 
                 text = Wert_Stabwaffen_PA,
                 fg= "purple",
                 bg = "black",
                 font = "Roman 20",
                 )
    lab_Stabwaffen_PA.place(x=10, y=600)
    lab_Stabwaffen_PA_Wert.place(x=330, y=600)
    but_Stabwaffen_PA_plus.place(x= 310, y=600)
    but_Stabwaffen_PA_minus.place(x= 380, y=600)
    #------------------------------------------------------------------------------------------------------------#
    lab_Schleudern_AT = Label (root, 
                 text = "Schleudern_AT",
                 fg= "purple",
                 bg = "black",
                 font = "Roman 20",
                 )
    lab_Schleudern_AT_Wert = Label (root, 
                 text = Wert_Schleudern_AT,
                 fg= "purple",
                 bg = "black",
                 font = "Roman 20",
                 )
    lab_Schleudern_AT.place(x=10, y=700)
    lab_Schleudern_AT_Wert.place(x=330, y=700)
    but_Schleudern_AT_plus.place(x= 310, y=700)
    but_Schleudern_AT_minus.place(x= 380, y=700)
    #------------------------------------------------------------------------------------------------------------#
    lab_Peitschen_AT = Label (root, 
                 text = "Peitschen_AT",
                 fg= "purple",
                 bg = "black",
                 font = "Roman 20",
                 )
    lab_Peitschen_AT_Wert = Label (root, 
                 text = Wert_Peitschen_AT,
                 fg= "purple",
                 bg = "black",
                 font = "Roman 20",
                 )
    lab_Peitschen_AT.place(x=10, y=800)
    lab_Peitschen_AT_Wert.place(x=330, y=800)
    but_Peitschen_AT_plus.place(x= 310, y=800)
    but_Peitschen_AT_minus.place(x= 380, y=800)
    #------------------------------------------------------------------------------------------------------------#
    lab_Armbrust_AT = Label (root, 
                 text = "Armbrust_AT",
                 fg= "purple",
                 bg = "black",
                 font = "Roman 20",
                 )
    lab_Armbrust_AT_Wert = Label (root, 
                 text = Wert_Armbrust_AT,
                 fg= "purple",
                 bg = "black",
                 font = "Roman 20",
                 )
    lab_Armbrust_AT.place(x=10, y=900)
    lab_Armbrust_AT_Wert.place(x=330, y=900)
    but_Armbrust_AT_plus.place(x= 310, y=900)
    but_Armbrust_AT_minus.place(x= 380, y=900)
    #------------------------------------------------------------------------------------------------------------#
    lab_Schwerter_AT = Label (root, 
                 text = "Schwerter_AT",
                 fg= "purple",
                 bg = "black",
                 font = "Roman 20",
                 )
    lab_Schwerter_AT_Wert = Label (root, 
                 text = Wert_Schwerter_AT,
                 fg= "purple",
                 bg = "black",
                 font = "Roman 20",
                 )
    lab_Schwerter_AT.place(x=480, y=200)
    lab_Schwerter_AT_Wert.place(x=700, y=200)
    but_Schwerter_AT_plus.place(x= 680, y=200)
    but_Schwerter_AT_minus.place(x= 750, y=200)
    #------------------------------------------------------------------------------------------------------------#
    lab_Schwerter_PA = Label (root, 
                 text = "Schwerter_PA",
                 fg= "purple",
                 bg = "black",
                 font = "Roman 20",
                 )
    lab_Schwerter_PA_Wert = Label (root, 
                 text = Wert_Schwerter_PA,
                 fg= "purple",
                 bg = "black",
                 font = "Roman 20",
                 )
    lab_Schwerter_PA.place(x=480, y=300)
    lab_Schwerter_PA_Wert.place(x=700, y=300)
    but_Schwerter_PA_plus.place(x= 680, y=300)
    but_Schwerter_PA_minus.place(x= 750, y=300)
    #------------------------------------------------------------------------------------------------------------#
    lab_Schilde_AT = Label (root, 
                 text = "Schilde_AT",
                 fg= "purple",
                 bg = "black",
                 font = "Roman 20",
                 )
    lab_Schilde_AT_Wert = Label (root, 
                 text = Wert_Schilde_AT,
                 fg= "purple",
                 bg = "black",
                 font = "Roman 20",
                 )
    lab_Schilde_AT.place(x=480, y=400)
    lab_Schilde_AT_Wert.place(x=700, y=400)
    but_Schilde_AT_plus.place(x= 680, y=400)
    but_Schilde_AT_minus.place(x= 750, y=400)
    #------------------------------------------------------------------------------------------------------------#
    lab_Schilde_PA = Label (root, 
                 text = "Schilde_PA",
                 fg= "purple",
                 bg = "black",
                 font = "Roman 20",
                 )
    lab_Schilde_PA_Wert = Label (root, 
                 text = Wert_Schilde_PA,
                 fg= "purple",
                 bg = "black",
                 font = "Roman 20",
                 )
    lab_Schilde_PA.place(x=480, y=500)
    lab_Schilde_PA_Wert.place(x=700, y=500)
    but_Schilde_PA_plus.place(x= 680, y=500)
    but_Schilde_PA_minus.place(x= 750, y=500)
    #------------------------------------------------------------------------------------------------------------#
    lab_Raufen_AT = Label (root, 
                 text = "Raufen_AT",
                 fg= "purple",
                 bg = "black",
                 font = "Roman 20",
                 )
    lab_Raufen_AT_Wert = Label (root, 
                 text = Wert_Raufen_AT,
                 fg= "purple",
                 bg = "black",
                 font = "Roman 20",
                 )
    lab_Raufen_AT.place(x=480, y=600)
    lab_Raufen_AT_Wert.place(x=700, y=600)
    but_Raufen_AT_plus.place(x= 680, y=600)
    but_Raufen_AT_minus.place(x= 750, y=600)
    #------------------------------------------------------------------------------------------------------------#
    lab_Raufen_PA = Label (root, 
                 text = "Raufen_PA",
                 fg= "purple",
                 bg = "black",
                 font = "Roman 20",
                 )
    lab_Raufen_PA_Wert = Label (root, 
                 text = Wert_Raufen_PA,
                 fg= "purple",
                 bg = "black",
                 font = "Roman 20",
                 )
    lab_Raufen_PA.place(x=480, y=700)
    lab_Raufen_PA_Wert.place(x=700, y=700)
    but_Raufen_PA_plus.place(x= 680, y=700)
    but_Raufen_PA_minus.place(x= 750, y=700)
    #------------------------------------------------------------------------------------------------------------#
    lab_Dolche_AT = Label (root, 
                 text = "Dolche_AT",
                 fg= "purple",
                 bg = "black",
                 font = "Roman 20",
                 )
    lab_Dolche_AT_Wert = Label (root, 
                 text = Wert_Dolche_AT,
                 fg= "purple",
                 bg = "black",
                 font = "Roman 20",
                 )
    lab_Dolche_AT.place(x=480, y=800)
    lab_Dolche_AT_Wert.place(x=700, y=800)
    but_Dolche_AT_plus.place(x= 680, y=800)
    but_Dolche_AT_minus.place(x= 750, y=800)
    #------------------------------------------------------------------------------------------------------------#
    lab_Dolche_PA = Label (root, 
                 text = "Dolche_PA",
                 fg= "purple",
                 bg = "black",
                 font = "Roman 20",
                 )
    lab_Dolche_PA_Wert = Label (root, 
                 text = Wert_Dolche_PA,
                 fg= "purple",
                 bg = "black",
                 font = "Roman 20",
                 )
    lab_Dolche_PA.place(x=480, y=900)
    lab_Dolche_PA_Wert.place(x=700, y=900)
    but_Dolche_PA_plus.place(x= 680, y=900)
    but_Dolche_PA_minus.place(x= 750, y=900)
    #------------------------------------------------------------------------------------------------------------#
    lab_Boegen_AT = Label (root, 
                 text = "Boegen_AT",
                 fg= "purple",
                 bg = "black",
                 font = "Roman 20",
                 )
    lab_Boegen_AT_Wert = Label (root, 
                 text = Wert_Boegen_AT,
                 fg= "purple",
                 bg = "black",
                 font = "Roman 20",
                 )
    lab_Boegen_AT.place(x=850, y=200)
    lab_Boegen_AT_Wert.place(x=1020, y=200)
    but_Boegen_AT_plus.place(x= 1000, y=200)
    but_Boegen_AT_minus.place(x= 1070, y=200)
    #------------------------------------------------------------------------------------------------------------#
    lab_Zauber = Label (root, 
                 text = "Zauber",
                 fg= "purple",
                 bg = "black",
                 font = "Roman 20",
                 )
    lab_Zauber_Wert = Label (root, 
                 text = Wert_Zauber,
                 fg= "purple",
                 bg = "black",
                 font = "Roman 20",
                 )
    lab_Zauber.place(x=850, y=300)
    lab_Zauber_Wert.place(x=1020, y=300)
    but_Zauber_plus.place(x= 1000, y=300)
    but_Zauber_minus.place(x= 1070, y=300)
#------------------------------------------------------------------------------------------------------------#
    lab_Faehigkeiten = Label (root, 
                 text = "Faehigkeiten",
                 fg= "purple",
                 bg = "black",
                 font = "Roman 20",
                 )
    lab_Faehigkeiten_Wert = Label (root, 
                 text = Wert_Faehigkeiten,
                 fg= "purple",
                 bg = "black",
                 font = "Roman 20",
                 )
    lab_Faehigkeiten.place(x=850, y=400)
    lab_Faehigkeiten_Wert.place(x=1020, y=400)
    but_Faehigkeiten_plus.place(x= 1000, y=400)
    but_Faehigkeiten_minus.place(x= 1070, y=400)
import csv
import Charakterseite as CH
def char_csv_write():
 
        # field names
        fields = ['Name', 'Alter', 'Koerpergroese', 'Gewicht']
 
        # data rows of csv file
        rows = [ [CH.entryName.get(), CH.entryAlter.get(), CH.entryKoerpergroesse.get(), CH.entryGewicht.get()] ]
 
        # name of csv file
        filename = CH.entryName.get()+".csv"
 
        # writing to csv file
        with open(filename, 'w') as csvfile:
                # creating a csv writer object
                csvwriter = csv.writer(csvfile)
     
                # writing the fields
                csvwriter.writerow(fields)
     
                # writing the data rows
                csvwriter.writerows(rows)
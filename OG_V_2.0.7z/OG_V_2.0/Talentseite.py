from tkinter import *
import Charakterseite as CS
import Kampfbogenseite as KBS

def Talentseite():

    global gplatz
    global platz
    global Wort
    global Zahl
    global Wert_AP
    global Wert_gesamt
    global Wert_Intelligenz
    global Wert_Kraft
    global Wert_Ausdauer
    global Wert_Charisma
    global Wert_Intuition
    global Wert_Fingerfertigkeit
    global Wert_Lebensmittelbearbeitung
    global Wert_Koerperbeherrschung
    global Wert_SagenundLegenden
    global Wert_Selbstbeherrschung
    global Wert_Schloesserknacken
    global Wert_Menschenkenntnis
    global Wert_Taschendiebstahl
    global Wert_Pflanzenkunde
    global Wert_Einschuechtern
    global Wert_Wildniskunde
    global Wert_Geistesblitz
    global Wert_Gassenwissen
    global Wert_Orientierung
    global Wert_Kriegskunst
    global Wert_Wahrnehmung
    global Wert_Ueberreden
    global Wert_Magiekunde
    global Wert_Ablenkung
    global Wert_Verbergen
    global Wert_Schwimmen
    global Wert_Heilkunde
    global Wert_Tierkunde
    global Wert_Betoeren
    global Wert_Klettern
    global Wert_Handwerk
    global Wert_Alchemie
    global Wert_Kraftakt
    global Wert_Sammeln
    global Wert_Handeln
    global Wert_Fesseln
    global Wert_Zechen
    global Wert_Jagen
    global convert_Wert
    global Wert_Rechne
    global plus_minus
    global but_Rechne1
    global but_Rechne10
    
    gplatz = "          "
    platz = "    "
    Wort = ""
    Zahl = 0
    Wert_AP = 0
    Wert_gesamt = 0
    Wert_Intelligenz = 0
    Wert_Kraft = 0
    Wert_Ausdauer = 0
    Wert_Charisma = 0
    Wert_Intuition = 0
    Wert_Fingerfertigkeit = 0
    Wert_Lebensmittelbearbeitung = 0
    Wert_Koerperbeherrschung = 0
    Wert_SagenundLegenden = 0
    Wert_Selbstbeherrschung = 0
    Wert_Schloesserknacken = 0
    Wert_Menschenkenntnis = 0
    Wert_Taschendiebstahl = 0
    Wert_Pflanzenkunde = 0
    Wert_Einschuechtern = 0
    Wert_Wildniskunde = 0
    Wert_Geistesblitz = 0
    Wert_Gassenwissen = 0
    Wert_Orientierung = 0
    Wert_Kriegskunst = 0
    Wert_Wahrnehmung = 0
    Wert_Ueberreden = 0
    Wert_Magiekunde = 0 
    Wert_Ablenkung = 0
    Wert_Verbergen = 0
    Wert_Schwimmen = 0
    Wert_Heilkunde = 0
    Wert_Tierkunde = 0
    Wert_Betoeren = 0
    Wert_Klettern = 0
    Wert_Handwerk = 0
    Wert_Alchemie = 0
    Wert_Kraftakt = 0
    Wert_Sammeln = 0
    Wert_Handeln = 0
    Wert_Fesseln = 0
    Wert_Zechen = 0
    Wert_Jagen = 0
    convert_Wert = ""
    Wert_Rechne = 0
    plus_minus = 0
    
    TA=Tk()
    TA.title("Talente")
    TA.geometry("1920x1080")
    TA.configure (bg="black")
    TA.lift()


    Button (
        TA,
        text="Charakter",
        fg="purple",
        bg="black",
        font = "Arial 20",
        command=lambda: [Talentclose(),CS.Charakterseite()]
        ).place(x =1600 ,y= 450)

    Button (
        TA,
        text="Kampfbogen",
        fg="purple",
        bg="black",
        font = "Arial 20",
        command=lambda: [Talentclose(),KBS.Kampfbogenseite()]
        ).place(x =1600 ,y= 550)

    def Talentclose():
        TA.destroy()
    
    global seite2
    seite2 = True
    

    def Rechne10():
        global Wert_Rechne
        global plus_minus
        global but_Rechne1
        Wert_Rechne = 9
        plus_minus = 10
        but_Rechne10.configure(bg="grey")
        but_Rechne1.configure(bg="black")

    def Rechne1():
        global Wert_Rechne
        global plus_minus
        global but_Rechne10
        Wert_Rechne = 0
        plus_minus = 1
        but_Rechne1.configure(bg="grey")
        but_Rechne10.configure(bg="black")

    #############################################################################################################

    def RechneplusIntelligenz():
        global Wert_AP
        global Wert_Intelligenz
        global lab_gplatz
        global gplatz
        global Wert_gesamt
        global platz
        global lab_platz
        if (Wert_AP>24):
            Wert_Intelligenz += 1
            Wert_AP -= 25
            Wert_gesamt += 1
            lab_gplatz =Label (TA, 
            text = gplatz,
            fg= "green",
            bg = "black",
            font = "Roman 20",
                    )
            lab_gplatz.place(x=850, y=105)
            lab_platz =Label (TA, 
            text = platz,
            fg= "green",
            bg = "black",
            font = "Roman 20",
                    )
            lab_platz.place(x=160, y=10)
            lab_AP_Wert =Label (TA, 
            text = Wert_AP,
            fg= "green",
            bg= "black",
            font = "Roman 20",
                    )
            lab_AP_Wert.place(x=850, y=105)
            lab_Intelligenz_Wert = Label (TA, 
            text = Wert_Intelligenz,
            fg= "green",
            bg = "black",
            font = "Roman 20",
            )
            lab_Intelligenz.place(x=10, y=10)
            lab_Intelligenz_Wert.place(x=160, y=10)

    def RechneminusIntelligenz():
        global Wert_AP
        global Wert_Intelligenz
        global lab_gplatz
        global gplatz
        global Wert_gesamt
        global platz
        global lab_platz
        if (Wert_Intelligenz>0):
            Wert_AP += 25
            Wert_Intelligenz -= 1
            Wert_gesamt -= 1
            lab_gplatz =Label (TA, 
            text = gplatz,
            fg= "green",
            bg = "black",
            font = "Roman 20",
                    )
            lab_gplatz.place(x=850, y=105)
            lab_platz =Label (TA, 
            text = platz,
            fg= "green",
            bg = "black",
            font = "Roman 20",
                    )
            lab_platz.place(x=160, y=10)
            lab_AP_Wert =Label (TA, 
            text = Wert_AP,
            fg= "green",
            bg = "black",
            font = "Roman 20",
                    )
            lab_AP_Wert.place(x=850, y=105)
            lab_Intelligenz_Wert = Label (TA, 
            text = Wert_Intelligenz,
            fg= "green",
            bg= "black",
            font = "Roman 20",
            )
            lab_Intelligenz.place(x=10, y=10)
            lab_Intelligenz_Wert.place(x=160, y=10)
        #############################################################################################################
   
    def RechneplusKraft():
        global Wert_AP
        global Wert_LP
        global Wert_Ausdauer
        global lab_AP_Wert
        global Wert_Kraft
        global lab_gplatz
        global gplatz
        global platz
        global lab_platz
        if (Wert_AP>16):
            Wert_Kraft +=1
            Wert_AP -= 17
            Wert_LP = (Wert_Kraft+Wert_Ausdauer)
            lab_gplatz =Label (TA, 
            text = gplatz,
            fg= "green",
            bg = "black",
            font = "Roman 20",
                    )
            lab_gplatz.place(x=850, y=105)
            lab_platz =Label (TA, 
            text = platz,
            fg= "green",
            bg = "black",
            font = "Roman 20",
                    )
            lab_platz.place(x=410, y=10)
            lab_AP_Wert =Label (TA, 
            text = Wert_AP,
            fg= "green",
            bg = "black",
            font = "Roman 20",
                    )
            lab_AP_Wert.place(x=850, y=105)
            lab_Kraft = Label (TA, 
                 text = "Kraft",
                 fg= "green",
            bg = "black",
                 font = "Roman 20",
                 )
            lab_Kraft_Wert = Label (TA, 
                 text = Wert_Kraft,
                 fg= "green",
                 bg = "black",
                 font = "Roman 20",
                 )
            lab_Kraft.place(x=310, y=10)
            lab_Kraft_Wert.place(x=410, y=10)
            but_Kraft_plus.place(x= 390, y=10)
            but_Kraft_minus.place(x= 460, y=10)

    def RechneminusKraft():
        global Wert_AP
        global Wert_Ausdauer
        global lab_AP_Wert
        global lab_gplatz
        global Wert_LP
        global gplatz
        global Wert_Kraft
        global platz
        global lab_platz
        if (Wert_Kraft>0):
            Wert_AP += 17
            Wert_Kraft -= 1
            Wert_LP = (Wert_Kraft+Wert_Ausdauer)
            lab_gplatz =Label (TA, 
            text = gplatz,
            fg= "green",
            bg = "black",
            font = "Roman 20",
                    )
            lab_gplatz.place(x=850, y=105)
            lab_platz =Label (TA, 
            text = platz,
            fg= "green",
            bg = "black",
            font = "Roman 20",
                    )
            lab_platz.place(x=410, y=10)
            lab_AP_Wert =Label (TA, 
            text = Wert_AP,
            fg= "green",
            bg = "black",
            font = "Roman 20",
                    )
            lab_AP_Wert.place(x=850, y=105)
            lab_Kraft = Label (TA, 
                 text = "Kraft",
                 fg= "green",
                 bg = "black",
                 font = "Roman 20",
                 )
            lab_Kraft_Wert = Label (TA, 
                         text = Wert_Kraft,
                         fg= "green",
                         bg = "black",
                         font = "Roman 20",
                         )
            lab_Kraft.place(x=310, y=10)
            lab_Kraft_Wert.place(x=410, y=10)
            but_Kraft_plus.place(x= 390, y=10)
            but_Kraft_minus.place(x= 460, y=10) 

    #############################################################################################################

    def RechneplusAusdauer():
        global Wert_AP
        global Wert_LP
        global Wert_Kraft
        global lab_AP_Wert
        global lab_gplatz
        global gplatz
        global Wert_Ausdauer
        global platz
        global lab_platz
        if (Wert_AP>13):
            Wert_AP -= 14
            Wert_Ausdauer += 1
            Wert_LP = (Wert_Kraft+Wert_Ausdauer)
            lab_gplatz =Label (TA, 
            text = gplatz,
            fg= "green",
            bg = "black",
            font = "Roman 20",
                  )
            lab_gplatz.place(x=850, y=105)
            lab_platz =Label (TA, 
            text = platz,
            fg= "green",
            bg = "black",
            font = "Roman 20",
                    )
            lab_platz.place(x=690, y=10)
            lab_AP_Wert =Label (TA, 
            text = Wert_AP,
            fg= "green",
            bg = "black",
            font = "Roman 20",
                     )
            lab_AP_Wert.place(x=850, y=105)
            lab_Ausdauer = Label (TA, 
                 text = "Ausdauer",
                 fg= "green",
                 bg = "black",
                 font = "Roman 20",
                 )
            lab_Ausdauer_Wert = Label (TA, 
                         text = Wert_Ausdauer,
                         fg= "green",
                         bg = "black",
                         font = "Roman 20",
                         )
            lab_Ausdauer.place(x=560, y=10)
            lab_Ausdauer_Wert.place(x=690, y=10)
            but_Ausdauer_plus.place(x= 670, y=10)
            but_Ausdauer_minus.place(x= 740, y=10)

    def RechneminusAusdauer():
        global Wert_AP
        global Wert_Kraft
        global Wert_LP
        global lab_AP_Wert
        global lab_gplatz
        global gplatz
        global Wert_Ausdauer
        global platz
        global lab_platz
        if (Wert_Ausdauer>0):
            Wert_AP += 14
            Wert_Ausdauer -= 1
            Wert_LP = (Wert_Kraft+Wert_Ausdauer)
            lab_gplatz =Label (TA, 
            text = gplatz,
            fg= "green",
            bg = "black",
            font = "Roman 20",
                  )
            lab_gplatz.place(x=850, y=105)
            lab_platz =Label (TA, 
            text = platz,
            fg= "green",
            bg = "black",
            font = "Roman 20",
                    )
            lab_platz.place(x=690, y=10)
            lab_AP_Wert =Label (TA, 
            text = Wert_AP,
            fg= "green",
            bg = "black",
            font = "Roman 20",
                     )
            lab_AP_Wert.place(x=850, y=105)
            lab_Ausdauer = Label (TA, 
                 text = "Ausdauer",
                 fg= "green",
                 bg = "black",
                 font = "Roman 20",
                 )
            lab_Ausdauer_Wert = Label (TA, 
                         text = Wert_Ausdauer,
                         fg= "green",
                         bg = "black",
                         font = "Roman 20",
                         )
            lab_Ausdauer.place(x=560, y=10)
            lab_Ausdauer_Wert.place(x=690, y=10)
            but_Ausdauer_plus.place(x= 670, y=10)
            but_Ausdauer_minus.place(x= 740, y=10)

    #############################################################################################################

    def RechneplusCharisma():
        global Wert_AP
        global lab_AP_Wert
        global Wert_Charisma
        global lab_gplatz
        global gplatz
        global platz
        global lab_platz
        if (Wert_AP>7):
            Wert_AP -= 8
            Wert_Charisma += 1
            global lab_gplatz
            global gplatz
            lab_gplatz =Label (TA, 
            text = gplatz,
            fg= "green",
            bg = "black",
            font = "Roman 20",
                     )
            lab_gplatz.place(x=850, y=105)
            lab_platz =Label (TA, 
            text = platz,
            fg= "green",
            bg = "black",
            font = "Roman 20",
                    )
            lab_platz.place(x=980, y=10)
            lab_AP_Wert =Label (TA, 
            text = Wert_AP,
            fg= "green",
            bg = "black",
            font = "Roman 20",
                    )
            lab_AP_Wert.place(x=850, y=105)
            lab_Charisma = Label (TA, 
                         text = "Charisma",
                         fg= "green",
                         bg = "black",
                         font = "Roman 20",
                         )
            lab_Charisma_Wert = Label (TA, 
                         text = Wert_Charisma,
                         fg= "green",
                         bg = "black",
                         font = "Roman 20",
                         )
            lab_Charisma.place(x=840, y=10)
            lab_Charisma_Wert.place(x=980, y=10)
            but_Charisma_plus.place(x= 960, y=10)
            but_Charisma_minus.place(x= 1030, y=10)

    def RechneminusCharisma():
        global Wert_AP
        global lab_AP_Wert
        global Wert_Charisma
        global lab_gplatz
        global gplatz
        global platz
        global lab_platz
        if (Wert_Charisma>0):
            Wert_AP += 8
            Wert_Charisma -= 1
            global lab_gplatz
            global gplatz
            lab_gplatz =Label (TA, 
            text = gplatz,
            fg= "green",
            bg = "black",
            font = "Roman 20",
                     )
            lab_gplatz.place(x=850, y=105)
            lab_platz =Label (TA, 
            text = platz,
            fg= "green",
            bg = "black",
            font = "Roman 20",
                    )
            lab_platz.place(x=980, y=10)
            lab_AP_Wert =Label (TA, 
            text = Wert_AP,
            fg= "green",
            bg = "black",
            font = "Roman 20",
                    )
            lab_AP_Wert.place(x=850, y=105)
            lab_Charisma = Label (TA, 
                         text = "Charisma",
                         fg= "green",
                         bg = "black",
                         font = "Roman 20",
                         )
            lab_Charisma_Wert = Label (TA, 
                         text = Wert_Charisma,
                         fg= "green",
                         bg = "black",
                         font = "Roman 20",
                         )
            lab_Charisma.place(x=840, y=10)
            lab_Charisma_Wert.place(x=980, y=10)
            but_Charisma_plus.place(x= 960, y=10)
            but_Charisma_minus.place(x= 1030, y=10)
    #############################################################################################################

    def RechneplusIntuition():
        global Wert_AP
        global lab_AP_Wert
        global Wert_Intuition
        global lab_gplatz
        global gplatz
        global platz
        global lab_platz
        if (Wert_AP>21):
            Wert_AP -= 22
            Wert_Intuition += 1
            global lab_gplatz
            global gplatz
            lab_gplatz =Label (TA, 
            text = gplatz,
            fg= "green",
            bg = "black",
            font = "Roman 20",
                     )
            lab_gplatz.place(x=850, y=105)
            lab_platz =Label (TA, 
            text = platz,
            fg= "green",
            bg = "black",
            font = "Roman 20",
                    )
            lab_platz.place(x=1270, y=10)
            lab_AP_Wert =Label (TA, 
            text = Wert_AP,
            fg= "green",
            bg = "black",
            font = "Roman 20",
                    )
            lab_AP_Wert.place(x=850, y=105)
            lab_Intuition = Label (TA, 
                         text = "Intuition",
                         fg= "green",
                         bg = "black",
                         font = "Roman 20",
                         )
            lab_Intuition_Wert = Label (TA, 
                         text = Wert_Intuition,
                         fg= "green",
                         bg = "black",
                         font = "Roman 20",
                         )
            lab_Intuition.place(x=1130, y=10)
            lab_Intuition_Wert.place(x=1270, y=10)
            but_Intuition_plus.place(x= 1250, y=10)
            but_Intuition_minus.place(x= 1320, y=10)

    def RechneminusIntuition():
        global Wert_AP
        global lab_AP_Wert
        global Wert_Intuition
        global lab_gplatz
        global gplatz
        global platz
        global lab_platz
        if (Wert_Intuition>0):
            Wert_AP += 22
            Wert_Intuition -= 1
            global lab_gplatz
            global gplatz
            lab_gplatz =Label (TA, 
            text = gplatz,
            fg= "green",
            bg = "black",
            font = "Roman 20",
                     )
            lab_gplatz.place(x=850, y=105)
            lab_platz =Label (TA, 
            text = platz,
            fg= "green",
            bg = "black",
            font = "Roman 20",
                    )
            lab_platz.place(x=1270, y=10)
            lab_AP_Wert =Label (TA, 
            text = Wert_AP,
            fg= "green",
            bg = "black",
            font = "Roman 20",
                    )
            lab_AP_Wert.place(x=850, y=105)
            lab_Intuition = Label (TA, 
                         text = "Intuition",
                         fg= "green",
                         bg = "black",
                         font = "Roman 20",
                         )
            lab_Intuition_Wert = Label (TA, 
                         text = Wert_Intuition,
                         fg= "green",
                         bg = "black",
                         font = "Roman 20",
                         )
            lab_Intuition.place(x=1130, y=10)
            lab_Intuition_Wert.place(x=1270, y=10)
            but_Intuition_plus.place(x= 1250, y=10)
            but_Intuition_minus.place(x= 1320, y=10)

    #############################################################################################################

    def RechneplusFingerfertigkeit():
        global Wert_AP
        global lab_AP_Wert
        global lab_gplatz
        global gplatz
        global Wert_Fingerfertigkeit
        global platz
        global lab_platz
        if (Wert_AP>13):
            Wert_AP -= 14
            Wert_Fingerfertigkeit += 1
            lab_gplatz =Label (TA, 
            text = gplatz,
            fg= "green",
            bg = "black",
            font = "Roman 20",
                  )
            lab_gplatz.place(x=850, y=105)
            lab_platz =Label (TA, 
            text = platz,
            fg= "green",
            bg = "black",
            font = "Roman 20",
                    )
            lab_platz.place(x=1630, y=10)
            lab_AP_Wert =Label (TA, 
            text = Wert_AP,
            fg= "green",
            bg = "black",
            font = "Roman 20",
                     )
            lab_AP_Wert.place(x=850, y=105)
            lab_Fingerfertigkeit  = Label (TA, 
                         text = "Fingerfertigkeit ",
                         fg= "green",
                         bg = "black",
                         font = "Roman 20",
                         )
            lab_Fingerfertigkeit_Wert = Label (TA, 
                         text = Wert_Fingerfertigkeit,
                         fg= "green",
                         bg = "black",
                         font = "Roman 20",
                         )
            lab_Fingerfertigkeit.place(x=1420, y=10)
            lab_Fingerfertigkeit_Wert.place(x=1630, y=10)
            but_Fingerfertigkeit_plus.place(x= 1610, y=10)
            but_Fingerfertigkeit_minus.place(x= 1680, y=10)

    def RechneminusFingerfertigkeit():
        global Wert_AP
        global lab_AP_Wert
        global lab_gplatz
        global gplatz
        global Wert_Fingerfertigkeit
        global platz
        global lab_platz
        if (Wert_Fingerfertigkeit>0):
            Wert_AP += 14
            Wert_Fingerfertigkeit -= 1
            lab_gplatz =Label (TA, 
            text = gplatz,
            fg= "green",
            bg = "black",
            font = "Roman 20",
                  )
            lab_gplatz.place(x=850, y=105)
            lab_platz =Label (TA, 
            text = platz,
            fg= "green",
            bg = "black",
            font = "Roman 20",
                    )
            lab_platz.place(x=1630, y=10)
            lab_AP_Wert =Label (TA, 
            text = Wert_AP,
            fg= "green",
            bg = "black",
            font = "Roman 20",
                     )
            lab_AP_Wert.place(x=850, y=105)
            lab_Fingerfertigkeit  = Label (TA, 
                         text = "Fingerfertigkeit ",
                        fg= "green",
                        bg = "black",
                         font = "Roman 20",
                         )
            lab_Fingerfertigkeit_Wert = Label (TA, 
                         text = Wert_Fingerfertigkeit,
                         fg= "green",
                         bg = "black",
                         font = "Roman 20",
                         )
            lab_Fingerfertigkeit.place(x=1420, y=10)
            lab_Fingerfertigkeit_Wert.place(x=1630, y=10)
            but_Fingerfertigkeit_plus.place(x= 1610, y=10)
            but_Fingerfertigkeit_minus.place(x= 1680, y=10)

    #############################################################################################################
    #############################################################################################################

    def RechnepluseinsAP():
        global Wert_AP
        global lab_AP_Wert
        Wert_AP += 1
        global lab_platz
        global gplatz
        lab_gplatz =Label (TA, 
        text = gplatz,
        fg= "green",
        bg = "black",
        font = "Roman 20",
                 )
        lab_gplatz.place(x=850, y=105)
        lab_AP_Wert =Label (TA, 
        text = Wert_AP,
        fg= "green",
        bg = "black",
        font = "Roman 20",
                 )
        lab_AP_Wert.place(x=850, y=105)

    def RechneminuseinsAP():
        global Wert_AP
        global lab_AP_Wert
        Wert_AP -= 1
        if (Wert_AP>-1):
            global lab_gplatz
            global gplatz
            lab_gplatz =Label (TA, 
            text = gplatz,
            fg= "green",
            bg = "black",
            font = "Roman 20",
                     )
            lab_gplatz.place(x=850, y=105)
            lab_AP_Wert =Label (TA, 
            text = Wert_AP,
            fg= "green",
            bg = "black",
            font = "Roman 20",
                     )
            lab_AP_Wert.place(x=850, y=105)

    def RechnepluszehnAP():
        global Wert_AP
        global lab_AP_Wert
        Wert_AP += 10
        global lab_gplatz
        global gplatz
        lab_gplatz =Label (TA, 
        text = gplatz,
        fg= "green",
        bg = "black",
        font = "Roman 20",
                 )
        lab_gplatz.place(x=850, y=105)
        lab_AP_Wert =Label (TA, 
        text = Wert_AP,
        fg= "green",
        bg = "black",
        font = "Roman 20",
                 )
        lab_AP_Wert.place(x=850, y=105)

    def RechneminuszehnAP():
        global Wert_AP
        global lab_AP_Wert
        Wert_AP -= 10
        global lab_gplatz
        global gplatz
        lab_gplatz =Label (TA, 
        text = gplatz,
        fg= "green",
        bg = "black",
        font = "Roman 20",
                 )
        lab_gplatz.place(x=850, y=105)
        lab_AP_Wert =Label (TA, 
        text = Wert_AP,
        fg= "green",
        bg = "black",
        font = "Roman 20",
                 )
        lab_AP_Wert.place(x=850, y=105)

    def RechneplushundertAP():
        global Wert_AP
        global lab_AP_Wert
        Wert_AP += 100
        global lab_gplatz
        global gplatz
        lab_gplatz =Label (TA, 
        text = gplatz,
        fg= "green",
        bg = "black",
        font = "Roman 20",
                 )
        lab_gplatz.place(x=850, y=105)
        lab_AP_Wert =Label (TA, 
        text = Wert_AP,
        fg= "green",
        bg = "black",
        font = "Roman 20",
                 )
        lab_AP_Wert.place(x=850, y=105)

    def RechneminushundertAP():
        global Wert_AP
        global lab_AP_Wert
        Wert_AP -= 100
        global lab_gplatz
        global gplatz
        lab_gplatz =Label (TA, 
        text = gplatz,
        fg= "green",
        bg = "black",
        font = "Roman 20",
                 )
        lab_gplatz.place(x=850, y=105)
        lab_AP_Wert =Label (TA, 
        text = Wert_AP,
        fg= "green",
        bg = "black",
        font = "Roman 20",
                 )
        lab_AP_Wert.place(x=850, y=105)
        lab_AP_Wert =Label (TA, 
        text = Wert_AP,
        fg= "green",
        bg = "black",
        font = "Roman 20",
                 )
        lab_AP_Wert.place(x=850, y=105)

    #############################################################################################################
    #############################################################################################################

    def RechneplusLebensmittelbearbeitung():
        global Wert_AP
        global Schwer
        global Wert_Lebensmittelbearbeitung
        global lab_gplatz
        global gplatz
        global Wert_gesamt
        global platz
        global lab_platz
        if (Wert_AP>Wert_Rechne):
            Wert_Lebensmittelbearbeitung += plus_minus
            Wert_AP -= (plus_minus)
            Wert_gesamt += plus_minus
            lab_gplatz =Label (TA, 
            text = gplatz,
            fg= "green",
            bg = "black",
            font = "Roman 20",
                    )
            lab_gplatz.place(x=850, y=105)
            lab_platz =Label (TA, 
            text = platz,
            fg= "green",
            bg = "black",
            font = "Roman 20",
                    )
            lab_platz.place(x=330, y=200)
            lab_AP_Wert =Label (TA, 
            text = Wert_AP,
            fg= "green",
            bg= "black",
            font = "Roman 20",
                    )
            lab_AP_Wert.place(x=850, y=105)
            lab_Lebensmittelbearbeitung_Wert = Label (TA, 
            text = Wert_Lebensmittelbearbeitung,
            fg= "purple",
            bg = "black",
            font = "Roman 20",
            )
            lab_Lebensmittelbearbeitung.place(x=10, y=200)
            lab_Lebensmittelbearbeitung_Wert.place(x=330, y=200)

    def RechneminusLebensmittelbearbeitung():
        global Wert_AP
        global Wert_Lebensmittelbearbeitung
        global lab_gplatz
        global gplatz
        global Wert_gesamt
        global platz
        global lab_platz
        if (Wert_Lebensmittelbearbeitung>Wert_Rechne):
            Wert_AP += (plus_minus)
            Wert_Lebensmittelbearbeitung -= plus_minus
            Wert_gesamt -= plus_minus
            lab_gplatz =Label (TA, 
            text = gplatz,
            fg= "green",
            bg = "black",
            font = "Roman 20",
                    )
            lab_gplatz.place(x=850, y=105)
            lab_platz =Label (TA, 
            text = platz,
            fg= "green",
            bg = "black",
            font = "Roman 20",
                    )
            lab_platz.place(x=330, y=200)
            lab_AP_Wert =Label (TA, 
            text = Wert_AP,
            fg= "green",
            bg = "black",
            font = "Roman 20",
                    )
            lab_AP_Wert.place(x=850, y=105)
            lab_Lebensmittelbearbeitung_Wert = Label (TA, 
            text = Wert_Lebensmittelbearbeitung,
            fg= "purple",
            bg= "black",
            font = "Roman 20",
            )
            lab_Lebensmittelbearbeitung.place(x=10, y=200)
            lab_Lebensmittelbearbeitung_Wert.place(x=330, y=200)

    #------------------------------------------------------------------------------------------------------------#

    def RechneplusKoerperbeherrschung():
        global Wert_AP
        global Wert_Koerperbeherrschung
        global lab_gplatz
        global gplatz
        global Wert_gesamt
        global platz
        global lab_platz
        if (Wert_AP>Wert_Rechne):
            Wert_Koerperbeherrschung += plus_minus
            Wert_AP -= (plus_minus)
            Wert_gesamt += plus_minus
            lab_gplatz =Label (TA, 
            text = gplatz,
            fg= "purple",
            bg = "black",
            font = "Roman 20",
                    )
            lab_gplatz.place(x=850, y=105)
            lab_platz =Label (TA, 
            text = platz,
            fg= "purple",
            bg = "black",
            font = "Roman 20",
                    )
            lab_platz.place(x=330, y=300)
            lab_AP_Wert =Label (TA, 
            text = Wert_AP,
            fg= "green",
            bg= "black",
            font = "Roman 20",
                    )
            lab_AP_Wert.place(x=850, y=105)
            lab_Koerperbeherrschung_Wert = Label (TA, 
            text = Wert_Koerperbeherrschung,
            fg= "purple",
            bg = "black",
            font = "Roman 20",
            )
            lab_Koerperbeherrschung.place(x=10, y=300)
            lab_Koerperbeherrschung_Wert.place(x=330, y=300)

    def RechneminusKoerperbeherrschung():
        global Wert_AP
        global Wert_Koerperbeherrschung
        global lab_gplatz
        global gplatz
        global Wert_gesamt
        global platz
        global lab_platz
        if (Wert_Koerperbeherrschung>Wert_Rechne):
            Wert_AP += (plus_minus)
            Wert_Koerperbeherrschung -= plus_minus
            Wert_gesamt -= plus_minus
            lab_gplatz =Label (TA, 
            text = gplatz,
            fg= "purple",
            bg = "black",
            font = "Roman 20",
                    )
            lab_gplatz.place(x=850, y=105)
            lab_platz =Label (TA, 
            text = platz,
            fg= "purple",
            bg = "black",
            font = "Roman 20",
                    )
            lab_platz.place(x=330, y=300)
            lab_AP_Wert =Label (TA, 
            text = Wert_AP,
            fg= "green",
            bg = "black",
            font = "Roman 20",
                    )
            lab_AP_Wert.place(x=850, y=105)
            lab_Koerperbeherrschung_Wert = Label (TA, 
            text = Wert_Koerperbeherrschung,
            fg= "purple",
            bg= "black",
            font = "Roman 20",
            )
            lab_Koerperbeherrschung.place(x=10, y=300)
            lab_Koerperbeherrschung_Wert.place(x=330, y=300)

    #------------------------------------------------------------------------------------------------------------#

    def RechneplusSagenundLegenden():
        global Wert_AP
        global Wert_SagenundLegenden
        global lab_gplatz
        global gplatz
        global Wert_gesamt
        global platz
        global lab_platz
        if (Wert_AP>Wert_Rechne):
            Wert_SagenundLegenden += plus_minus
            Wert_AP -= (plus_minus)
            Wert_gesamt += plus_minus
            lab_gplatz =Label (TA, 
            text = gplatz,
            fg= "purple",
            bg = "black",
            font = "Roman 20",
                    )
            lab_gplatz.place(x=850, y=105)
            lab_platz =Label (TA, 
            text = platz,
            fg= "purple",
            bg = "black",
            font = "Roman 20",
                    )
            lab_platz.place(x=330, y=400)
            lab_AP_Wert =Label (TA, 
            text = Wert_AP,
            fg= "green",
            bg= "black",
            font = "Roman 20",
                    )
            lab_AP_Wert.place(x=850, y=105)
            lab_SagenundLegenden_Wert = Label (TA, 
            text = Wert_SagenundLegenden,
            fg= "purple",
            bg = "black",
            font = "Roman 20",
            )
            lab_SagenundLegenden.place(x=10, y=400)
            lab_SagenundLegenden_Wert.place(x=330, y=400)

    def RechneminusSagenundLegenden():
        global Wert_AP
        global Wert_SagenundLegenden
        global lab_gplatz
        global gplatz
        global Wert_gesamt
        global platz
        global lab_platz
        if (Wert_SagenundLegenden>Wert_Rechne):
            Wert_AP += (plus_minus)
            Wert_SagenundLegenden -= plus_minus
            Wert_gesamt -= plus_minus
            lab_gplatz =Label (TA, 
            text = gplatz,
            fg= "purple",
            bg = "black",
            font = "Roman 20",
                    )
            lab_gplatz.place(x=850, y=105)
            lab_platz =Label (TA, 
            text = platz,
            fg= "purple",
            bg = "black",
            font = "Roman 20",
                    )
            lab_platz.place(x=330, y=400)
            lab_AP_Wert =Label (TA, 
            text = Wert_AP,
            fg= "green",
            bg = "black",
            font = "Roman 20",
                    )
            lab_AP_Wert.place(x=850, y=105)
            lab_SagenundLegenden_Wert = Label (TA, 
            text = Wert_SagenundLegenden,
            fg= "purple",
            bg= "black",
            font = "Roman 20",
            )
            lab_SagenundLegenden.place(x=10, y=400)
            lab_SagenundLegenden_Wert.place(x=330, y=400)

    #------------------------------------------------------------------------------------------------------------#

    def RechneplusSelbstbeherrschung():
        global Wert_AP
        global Wert_Selbstbeherrschung
        global lab_gplatz
        global gplatz
        global Wert_gesamt
        global platz
        global lab_platz
        if (Wert_AP>Wert_Rechne):
            Wert_Selbstbeherrschung += plus_minus
            Wert_AP -= (plus_minus)
            Wert_gesamt += plus_minus
            lab_gplatz =Label (TA, 
            text = gplatz,
            fg= "purple",
            bg = "black",
            font = "Roman 20",
                    )
            lab_gplatz.place(x=850, y=105)
            lab_platz =Label (TA, 
            text = platz,
            fg= "purple",
            bg = "black",
            font = "Roman 20",
                    )
            lab_platz.place(x=330, y=500)
            lab_AP_Wert =Label (TA, 
            text = Wert_AP,
            fg= "green",
            bg= "black",
            font = "Roman 20",
                    )
            lab_AP_Wert.place(x=850, y=105)
            lab_Selbstbeherrschung_Wert = Label (TA, 
            text = Wert_Selbstbeherrschung,
            fg= "purple",
            bg = "black",
            font = "Roman 20",
            )
            lab_Selbstbeherrschung.place(x=10, y=500)
            lab_Selbstbeherrschung_Wert.place(x=330, y=500)

    def RechneminusSelbstbeherrschung():
        global Wert_AP
        global Wert_Selbstbeherrschung
        global lab_gplatz
        global gplatz
        global Wert_gesamt
        global platz
        global lab_platz
        if (Wert_Selbstbeherrschung>Wert_Rechne):
            Wert_AP += (plus_minus)
            Wert_Selbstbeherrschung -= plus_minus
            Wert_gesamt -= plus_minus
            lab_gplatz =Label (TA, 
            text = gplatz,
            fg= "purple",
            bg = "black",
            font = "Roman 20",
                    )
            lab_gplatz.place(x=850, y=105)
            lab_platz =Label (TA, 
            text = platz,
            fg= "purple",
            bg = "black",
            font = "Roman 20",
                    )
            lab_platz.place(x=330, y=500)
            lab_AP_Wert =Label (TA, 
            text = Wert_AP,
            fg= "green",
            bg = "black",
            font = "Roman 20",
                    )
            lab_AP_Wert.place(x=850, y=105)
            lab_Selbstbeherrschung_Wert = Label (TA, 
            text = Wert_Selbstbeherrschung,
            fg= "purple",
            bg= "black",
            font = "Roman 20",
            )
            lab_Selbstbeherrschung.place(x=10, y=500)
            lab_Selbstbeherrschung_Wert.place(x=330, y=500)

    #------------------------------------------------------------------------------------------------------------#

    def RechneplusSchloesserknacken():
        global Wert_AP
        global Wert_Schloesserknacken
        global lab_gplatz
        global gplatz
        global Wert_gesamt
        global platz
        global lab_platz
        if (Wert_AP>Wert_Rechne):
            Wert_Schloesserknacken += plus_minus
            Wert_AP -= (plus_minus)
            Wert_gesamt += plus_minus
            lab_gplatz =Label (TA, 
            text = gplatz,
            fg= "purple",
            bg = "black",
            font = "Roman 20",
                    )
            lab_gplatz.place(x=850, y=105)
            lab_platz =Label (TA, 
            text = platz,
            fg= "purple",
            bg = "black",
            font = "Roman 20",
                    )
            lab_platz.place(x=330, y=600)
            lab_AP_Wert =Label (TA, 
            text = Wert_AP,
            fg= "green",
            bg= "black",
            font = "Roman 20",
                    )
            lab_AP_Wert.place(x=850, y=105)
            lab_Schloesserknacken_Wert = Label (TA, 
            text = Wert_Schloesserknacken,
            fg= "purple",
            bg = "black",
            font = "Roman 20",
            )
            lab_Schloesserknacken.place(x=10, y=600)
            lab_Schloesserknacken_Wert.place(x=330, y=600)

    def RechneminusSchloesserknacken():
        global Wert_AP
        global Wert_Schloesserknacken
        global lab_gplatz
        global gplatz
        global Wert_gesamt
        global platz
        global lab_platz
        if (Wert_Schloesserknacken>Wert_Rechne):
            Wert_AP += (plus_minus)
            Wert_Schloesserknacken -= plus_minus
            Wert_gesamt -= plus_minus
            lab_gplatz =Label (TA, 
            text = gplatz,
            fg= "purple",
            bg = "black",
            font = "Roman 20",
                    )
            lab_gplatz.place(x=850, y=105)
            lab_platz =Label (TA, 
            text = platz,
            fg= "purple",
            bg = "black",
            font = "Roman 20",
                    )
            lab_platz.place(x=330, y=600)
            lab_AP_Wert =Label (TA, 
            text = Wert_AP,
            fg= "green",
            bg = "black",
            font = "Roman 20",
                    )
            lab_AP_Wert.place(x=850, y=105)
            lab_Schloesserknacken_Wert = Label (TA, 
            text = Wert_Schloesserknacken,
            fg= "purple",
            bg= "black",
            font = "Roman 20",
            )
            lab_Schloesserknacken.place(x=10, y=600)
            lab_Schloesserknacken_Wert.place(x=330, y=600)

    #------------------------------------------------------------------------------------------------------------#

    def RechneplusMenschenkenntnis():
        global Wert_AP
        global Wert_Menschenkenntnis
        global lab_gplatz
        global gplatz
        global Wert_gesamt
        global platz
        global lab_platz
        if (Wert_AP>Wert_Rechne):
            Wert_Menschenkenntnis += plus_minus
            Wert_AP -= (plus_minus)
            Wert_gesamt += plus_minus
            lab_gplatz =Label (TA, 
            text = gplatz,
            fg= "purple",
            bg = "black",
            font = "Roman 20",
                    )
            lab_gplatz.place(x=850, y=105)
            lab_platz =Label (TA, 
            text = platz,
            fg= "purple",
            bg = "black",
            font = "Roman 20",
                    )
            lab_platz.place(x=330, y=700)
            lab_AP_Wert =Label (TA, 
            text = Wert_AP,
            fg= "green",
            bg= "black",
            font = "Roman 20",
                    )
            lab_AP_Wert.place(x=850, y=105)
            lab_Menschenkenntnis_Wert = Label (TA, 
            text = Wert_Menschenkenntnis,
            fg= "purple",
            bg = "black",
            font = "Roman 20",
            )
            lab_Menschenkenntnis.place(x=10, y=700)
            lab_Menschenkenntnis_Wert.place(x=330, y=700)

    def RechneminusMenschenkenntnis():
        global Wert_AP
        global Wert_Menschenkenntnis
        global lab_gplatz
        global gplatz
        global Wert_gesamt
        global platz
        global lab_platz
        if (Wert_Menschenkenntnis>Wert_Rechne):
            Wert_AP += (plus_minus)
            Wert_Menschenkenntnis -= plus_minus
            Wert_gesamt -= plus_minus
            lab_gplatz =Label (TA, 
            text = gplatz,
            fg= "purple",
            bg = "black",
            font = "Roman 20",
                    )
            lab_gplatz.place(x=850, y=105)
            lab_platz =Label (TA, 
            text = platz,
            fg= "purple",
            bg = "black",
            font = "Roman 20",
                    )
            lab_platz.place(x=330, y=700)
            lab_AP_Wert =Label (TA, 
            text = Wert_AP,
            fg= "green",
            bg = "black",
            font = "Roman 20",
                    )
            lab_AP_Wert.place(x=850, y=105)
            lab_Menschenkenntnis_Wert = Label (TA, 
            text = Wert_Menschenkenntnis,
            fg= "purple",
            bg= "black",
            font = "Roman 20",
            )
            lab_Menschenkenntnis.place(x=10, y=700)
            lab_Menschenkenntnis_Wert.place(x=330, y=700)
    #------------------------------------------------------------------------------------------------------------#

    def RechneplusTaschendiebstahl():
        global Wert_AP
        global Wert_Taschendiebstahl
        global lab_gplatz
        global gplatz
        global Wert_gesamt
        global platz
        global lab_platz
        if (Wert_AP>Wert_Rechne):
            Wert_Taschendiebstahl += plus_minus
            Wert_AP -= (plus_minus)
            Wert_gesamt += plus_minus
            lab_gplatz =Label (TA, 
            text = gplatz,
            fg= "purple",
            bg = "black",
            font = "Roman 20",
                    )
            lab_gplatz.place(x=850, y=105)
            lab_platz =Label (TA, 
            text = platz,
            fg= "purple",
            bg = "black",
            font = "Roman 20",
                    )
            lab_platz.place(x=330, y=800)
            lab_AP_Wert =Label (TA, 
            text = Wert_AP,
            fg= "green",
            bg= "black",
            font = "Roman 20",
                    )
            lab_AP_Wert.place(x=850, y=105)
            lab_Taschendiebstahl_Wert = Label (TA, 
            text = Wert_Taschendiebstahl,
            fg= "purple",
            bg = "black",
            font = "Roman 20",
            )
            lab_Taschendiebstahl.place(x=10, y=800)
            lab_Taschendiebstahl_Wert.place(x=330, y=800)

    def RechneminusTaschendiebstahl():
        global Wert_AP
        global Wert_Taschendiebstahl
        global lab_gplatz
        global gplatz
        global Wert_gesamt
        global platz
        global lab_platz
        if (Wert_Taschendiebstahl>Wert_Rechne):
            Wert_AP += (plus_minus)
            Wert_Taschendiebstahl -= plus_minus
            Wert_gesamt -= plus_minus
            lab_gplatz =Label (TA, 
            text = gplatz,
            fg= "purple",
            bg = "black",
            font = "Roman 20",
                    )
            lab_gplatz.place(x=850, y=105)
            lab_platz =Label (TA, 
            text = platz,
            fg= "purple",
            bg = "black",
            font = "Roman 20",
                    )
            lab_platz.place(x=330, y=800)
            lab_AP_Wert =Label (TA, 
            text = Wert_AP,
            fg= "green",
            bg = "black",
            font = "Roman 20",
                    )
            lab_AP_Wert.place(x=850, y=105)
            lab_Taschendiebstahl_Wert = Label (TA, 
            text = Wert_Taschendiebstahl,
            fg= "purple",
            bg= "black",
            font = "Roman 20",
            )
            lab_Taschendiebstahl.place(x=10, y=800)
            lab_Taschendiebstahl_Wert.place(x=330, y=800)

    #------------------------------------------------------------------------------------------------------------#

    def RechneplusPflanzenkunde():
        global Wert_AP
        global Wert_Pflanzenkunde
        global lab_gplatz
        global gplatz
        global Wert_gesamt
        global platz
        global lab_platz
        if (Wert_AP>Wert_Rechne):
            Wert_Pflanzenkunde += plus_minus
            Wert_AP -= (plus_minus)
            Wert_gesamt += plus_minus
            lab_gplatz =Label (TA, 
            text = gplatz,
            fg= "purple",
            bg = "black",
            font = "Roman 20",
                    )
            lab_gplatz.place(x=850, y=105)
            lab_platz =Label (TA, 
            text = platz,
            fg= "purple",
            bg = "black",
            font = "Roman 20",
                    )
            lab_platz.place(x=330, y=900)
            lab_AP_Wert =Label (TA, 
            text = Wert_AP,
            fg= "green",
            bg= "black",
            font = "Roman 20",
                    )
            lab_AP_Wert.place(x=850, y=105)
            lab_Pflanzenkunde_Wert = Label (TA, 
            text = Wert_Pflanzenkunde,
            fg= "purple",
            bg = "black",
            font = "Roman 20",
            )
            lab_Pflanzenkunde.place(x=10, y=900)
            lab_Pflanzenkunde_Wert.place(x=330, y=900)

    def RechneminusPflanzenkunde():
        global Wert_AP
        global Wert_Pflanzenkunde
        global lab_gplatz
        global gplatz
        global Wert_gesamt
        global platz
        global lab_platz
        if (Wert_Pflanzenkunde>Wert_Rechne):
            Wert_AP += (plus_minus)
            Wert_Pflanzenkunde -= plus_minus
            Wert_gesamt -= plus_minus
            lab_gplatz =Label (TA, 
            text = gplatz,
            fg= "purple",
            bg = "black",
            font = "Roman 20",
                    )
            lab_gplatz.place(x=850, y=105)
            lab_platz =Label (TA, 
            text = platz,
            fg= "purple",
            bg = "black",
            font = "Roman 20",
                    )
            lab_platz.place(x=330, y=900)
            lab_AP_Wert =Label (TA, 
            text = Wert_AP,
            fg= "green",
            bg = "black",
            font = "Roman 20",
                    )
            lab_AP_Wert.place(x=850, y=105)
            lab_Pflanzenkunde_Wert = Label (TA, 
            text = Wert_Pflanzenkunde,
            fg= "purple",
            bg= "black",
            font = "Roman 20",
            )
            lab_Pflanzenkunde.place(x=10, y=900)
            lab_Pflanzenkunde_Wert.place(x=330, y=900)

    #------------------------------------------------------------------------------------------------------------#

    def RechneplusEinschuechtern():
        global Wert_AP
        global Wert_Einschuechtern
        global lab_gplatz
        global gplatz
        global Wert_gesamt
        global platz
        global lab_platz
        if (Wert_AP>Wert_Rechne):
            Wert_Einschuechtern += plus_minus
            Wert_AP -= (plus_minus)
            Wert_gesamt += plus_minus
            lab_gplatz =Label (TA, 
            text = gplatz,
            fg= "purple",
            bg = "black",
            font = "Roman 20",
                    )
            lab_gplatz.place(x=850, y=105)
            lab_platz =Label (TA, 
            text = platz,
            fg= "purple",
            bg = "black",
            font = "Roman 20",
                    )
            lab_platz.place(x=700, y=200)
            lab_AP_Wert =Label (TA, 
            text = Wert_AP,
            fg= "green",
            bg= "black",
            font = "Roman 20",
                    )
            lab_AP_Wert.place(x=850, y=105)
            lab_Einschuechtern_Wert = Label (TA, 
            text = Wert_Einschuechtern,
            fg= "purple",
            bg = "black",
            font = "Roman 20",
            )
            lab_Einschuechtern.place(x=480, y=200)
            lab_Einschuechtern_Wert.place(x=700, y=200)

    def RechneminusEinschuechtern():
        global Wert_AP
        global Wert_Einschuechtern
        global lab_gplatz
        global gplatz
        global Wert_gesamt
        global platz
        global lab_platz
        if (Wert_Einschuechtern>Wert_Rechne):
            Wert_AP += (plus_minus)
            Wert_Einschuechtern -= plus_minus
            Wert_gesamt -= plus_minus
            lab_gplatz =Label (TA, 
            text = gplatz,
            fg= "purple",
            bg = "black",
            font = "Roman 20",
                    )
            lab_gplatz.place(x=850, y=105)
            lab_platz =Label (TA, 
            text = platz,
            fg= "purple",
            bg = "black",
            font = "Roman 20",
                    )
            lab_platz.place(x=700, y=200)
            lab_AP_Wert =Label (TA, 
            text = Wert_AP,
            fg= "green",
            bg = "black",
            font = "Roman 20",
                    )
            lab_AP_Wert.place(x=850, y=105)
            lab_Einschuechtern_Wert = Label (TA, 
            text = Wert_Einschuechtern,
            fg= "purple",
            bg= "black",
            font = "Roman 20",
            )
            lab_Einschuechtern.place(x=480, y=200)
            lab_Einschuechtern_Wert.place(x=700, y=200)

    #------------------------------------------------------------------------------------------------------------#

    def RechneplusWildniskunde():
        global Wert_AP
        global Wert_Wildniskunde
        global lab_gplatz
        global gplatz
        global Wert_gesamt
        global platz
        global lab_platz
        if (Wert_AP>Wert_Rechne):
            Wert_Wildniskunde += plus_minus
            Wert_AP -= (plus_minus)
            Wert_gesamt += plus_minus
            lab_gplatz =Label (TA, 
            text = gplatz,
            fg= "purple",
            bg = "black",
            font = "Roman 20",
                    )
            lab_gplatz.place(x=850, y=105)
            lab_platz =Label (TA, 
            text = platz,
            fg= "purple",
            bg = "black",
            font = "Roman 20",
                    )
            lab_platz.place(x=700, y=300)
            lab_AP_Wert =Label (TA, 
            text = Wert_AP,
            fg= "green",
            bg= "black",
            font = "Roman 20",
                    )
            lab_AP_Wert.place(x=850, y=105)
            lab_Wildniskunde_Wert = Label (TA, 
            text = Wert_Wildniskunde,
            fg= "purple",
            bg = "black",
            font = "Roman 20",
            )
            lab_Wildniskunde.place(x=480, y=300)
            lab_Wildniskunde_Wert.place(x=700, y=300)

    def RechneminusWildniskunde():
        global Wert_AP
        global Wert_Wildniskunde
        global lab_gplatz
        global gplatz
        global Wert_gesamt
        global platz
        global lab_platz
        if (Wert_Wildniskunde>Wert_Rechne):
            Wert_AP += (plus_minus)
            Wert_Wildniskunde -= plus_minus
            Wert_gesamt -= plus_minus
            lab_gplatz =Label (TA, 
            text = gplatz,
            fg= "purple",
            bg = "black",
            font = "Roman 20",
                    )
            lab_gplatz.place(x=850, y=105)
            lab_platz =Label (TA, 
            text = platz,
            fg= "purple",
            bg = "black",
            font = "Roman 20",
                    )
            lab_platz.place(x=700, y=300)
            lab_AP_Wert =Label (TA, 
            text = Wert_AP,
            fg= "green",
            bg = "black",
            font = "Roman 20",
                    )
            lab_AP_Wert.place(x=850, y=105)
            lab_Wildniskunde_Wert = Label (TA, 
            text = Wert_Wildniskunde,
            fg= "purple",
            bg= "black",
            font = "Roman 20",
            )
            lab_Wildniskunde.place(x=480, y=300)
            lab_Wildniskunde_Wert.place(x=700, y=300)

    #------------------------------------------------------------------------------------------------------------#

    def RechneplusGeistesblitz():
        global Wert_AP
        global Wert_Geistesblitz
        global lab_gplatz
        global gplatz
        global Wert_gesamt
        global platz
        global lab_platz
        if (Wert_AP>Wert_Rechne):
            Wert_Geistesblitz += plus_minus
            Wert_AP -= (plus_minus)
            Wert_gesamt += plus_minus
            lab_gplatz =Label (TA, 
            text = gplatz,
            fg= "purple",
            bg = "black",
            font = "Roman 20",
                    )
            lab_gplatz.place(x=850, y=105)
            lab_platz =Label (TA, 
            text = platz,
            fg= "purple",
            bg = "black",
            font = "Roman 20",
                    )
            lab_platz.place(x=700, y=400)
            lab_AP_Wert =Label (TA, 
            text = Wert_AP,
            fg= "green",
            bg= "black",
            font = "Roman 20",
                    )
            lab_AP_Wert.place(x=850, y=105)
            lab_Geistesblitz_Wert = Label (TA, 
            text = Wert_Geistesblitz,
            fg= "purple",
            bg = "black",
            font = "Roman 20",
            )
            lab_Geistesblitz.place(x=480, y=400)
            lab_Geistesblitz_Wert.place(x=700, y=400)

    def RechneminusGeistesblitz():
        global Wert_AP
        global Wert_Geistesblitz
        global lab_gplatz
        global gplatz
        global Wert_gesamt
        global platz
        global lab_platz
        if (Wert_Geistesblitz>Wert_Rechne):
            Wert_AP += (plus_minus)
            Wert_Geistesblitz -= plus_minus
            Wert_gesamt -= plus_minus
            lab_gplatz =Label (TA, 
            text = gplatz,
            fg= "purple",
            bg = "black",
            font = "Roman 20",
                    )
            lab_gplatz.place(x=850, y=105)
            lab_platz =Label (TA, 
            text = platz,
            fg= "purple",
            bg = "black",
            font = "Roman 20",
                    )
            lab_platz.place(x=700, y=400)
            lab_AP_Wert =Label (TA, 
            text = Wert_AP,
            fg= "green",
            bg = "black",
            font = "Roman 20",
                    )
            lab_AP_Wert.place(x=850, y=105)
            lab_Geistesblitz_Wert = Label (TA, 
            text = Wert_Geistesblitz,
            fg= "purple",
            bg= "black",
            font = "Roman 20",
            )
            lab_Geistesblitz.place(x=480, y=400)
            lab_Geistesblitz_Wert.place(x=700, y=400)
 
     #------------------------------------------------------------------------------------------------------------#

    def RechneplusGassenwissen():
        global Wert_AP
        global Wert_Gassenwissen
        global lab_gplatz
        global gplatz
        global Wert_gesamt
        global platz
        global lab_platz
        if (Wert_AP>Wert_Rechne):
            Wert_Gassenwissen += plus_minus
            Wert_AP -= (plus_minus)
            Wert_gesamt += plus_minus
            lab_gplatz =Label (TA, 
            text = gplatz,
            fg= "purple",
            bg = "black",
            font = "Roman 20",
                    )
            lab_gplatz.place(x=850, y=105)
            lab_platz =Label (TA, 
            text = platz,
            fg= "purple",
            bg = "black",
            font = "Roman 20",
                    )
            lab_platz.place(x=700, y=500)
            lab_AP_Wert =Label (TA, 
            text = Wert_AP,
            fg= "green",
            bg= "black",
            font = "Roman 20",
                    )
            lab_AP_Wert.place(x=850, y=105)
            lab_Gassenwissen_Wert = Label (TA, 
            text = Wert_Gassenwissen,
            fg= "purple",
            bg = "black",
            font = "Roman 20",
            )
            lab_Gassenwissen.place(x=480, y=500)
            lab_Gassenwissen_Wert.place(x=700, y=500)

    def RechneminusGassenwissen():
        global Wert_AP
        global Wert_Gassenwissen
        global lab_gplatz
        global gplatz
        global Wert_gesamt
        global platz
        global lab_platz
        if (Wert_Gassenwissen>Wert_Rechne):
            Wert_AP += (plus_minus)
            Wert_Gassenwissen -= plus_minus
            Wert_gesamt -= plus_minus
            lab_gplatz =Label (TA, 
            text = gplatz,
            fg= "purple",
            bg = "black",
            font = "Roman 20",
                    )
            lab_gplatz.place(x=850, y=105)
            lab_platz =Label (TA, 
            text = platz,
            fg= "purple",
            bg = "black",
            font = "Roman 20",
                    )
            lab_platz.place(x=700, y=500)
            lab_AP_Wert =Label (TA, 
            text = Wert_AP,
            fg= "green",
            bg = "black",
            font = "Roman 20",
                    )
            lab_AP_Wert.place(x=850, y=105)
            lab_Gassenwissen_Wert = Label (TA, 
            text = Wert_Gassenwissen,
            fg= "purple",
            bg= "black",
            font = "Roman 20",
            )
            lab_Gassenwissen.place(x=480, y=500)
            lab_Gassenwissen_Wert.place(x=700, y=500)

     #------------------------------------------------------------------------------------------------------------#

    def RechneplusOrientierung():
        global Wert_AP
        global Wert_Orientierung
        global lab_gplatz
        global gplatz
        global Wert_gesamt
        global platz
        global lab_platz
        if (Wert_AP>Wert_Rechne):
            Wert_Orientierung += plus_minus
            Wert_AP -= (plus_minus)
            Wert_gesamt += plus_minus
            lab_gplatz =Label (TA, 
            text = gplatz,
            fg= "purple",
            bg = "black",
            font = "Roman 20",
                    )
            lab_gplatz.place(x=850, y=105)
            lab_platz =Label (TA, 
            text = platz,
            fg= "purple",
            bg = "black",
            font = "Roman 20",
                    )
            lab_platz.place(x=700, y=600)
            lab_AP_Wert =Label (TA, 
            text = Wert_AP,
            fg= "green",
            bg= "black",
            font = "Roman 20",
                    )
            lab_AP_Wert.place(x=850, y=105)
            lab_Orientierung_Wert = Label (TA, 
            text = Wert_Orientierung,
            fg= "purple",
            bg = "black",
            font = "Roman 20",
            )
            lab_Orientierung.place(x=480, y=600)
            lab_Orientierung_Wert.place(x=700, y=600)

    def RechneminusOrientierung():
        global Wert_AP
        global Wert_Orientierung
        global lab_gplatz
        global gplatz
        global Wert_gesamt
        global platz
        global lab_platz
        if (Wert_Orientierung>Wert_Rechne):
            Wert_AP += (plus_minus)
            Wert_Orientierung -= plus_minus
            Wert_gesamt -= plus_minus
            lab_gplatz =Label (TA, 
            text = gplatz,
            fg= "purple",
            bg = "black",
            font = "Roman 20",
                    )
            lab_gplatz.place(x=850, y=105)
            lab_platz =Label (TA, 
            text = platz,
            fg= "purple",
            bg = "black",
            font = "Roman 20",
                    )
            lab_platz.place(x=700, y=600)
            lab_AP_Wert =Label (TA, 
            text = Wert_AP,
            fg= "green",
            bg = "black",
            font = "Roman 20",
                    )
            lab_AP_Wert.place(x=850, y=105)
            lab_Orientierung_Wert = Label (TA, 
            text = Wert_Orientierung,
            fg= "purple",
            bg= "black",
            font = "Roman 20",
            )
            lab_Orientierung.place(x=480, y=600)
            lab_Orientierung_Wert.place(x=700, y=600)
        
             #------------------------------------------------------------------------------------------------------------#

    def RechneplusKriegskunst():
        global Wert_AP
        global Wert_Kriegskunst
        global lab_gplatz
        global gplatz
        global Wert_gesamt
        global platz
        global lab_platz
        if (Wert_AP>Wert_Rechne):
            Wert_Kriegskunst += plus_minus
            Wert_AP -= (plus_minus)
            Wert_gesamt += plus_minus
            lab_gplatz =Label (TA, 
            text = gplatz,
            fg= "purple",
            bg = "black",
            font = "Roman 20",
                    )
            lab_gplatz.place(x=850, y=105)
            lab_platz =Label (TA, 
            text = platz,
            fg= "purple",
            bg = "black",
            font = "Roman 20",
                    )
            lab_platz.place(x=700, y=700)
            lab_AP_Wert =Label (TA, 
            text = Wert_AP,
            fg= "green",
            bg= "black",
            font = "Roman 20",
                    )
            lab_AP_Wert.place(x=850, y=105)
            lab_Kriegskunst_Wert = Label (TA, 
            text = Wert_Kriegskunst,
            fg= "purple",
            bg = "black",
            font = "Roman 20",
            )
            lab_Kriegskunst.place(x=480, y=700)
            lab_Kriegskunst_Wert.place(x=700, y=700)

    def RechneminusKriegskunst():
        global Wert_AP
        global Wert_Kriegskunst
        global lab_gplatz
        global gplatz
        global Wert_gesamt
        global platz
        global lab_platz
        if (Wert_Kriegskunst>Wert_Rechne):
            Wert_AP += (plus_minus)
            Wert_Kriegskunst -= plus_minus
            Wert_gesamt -= plus_minus
            lab_gplatz =Label (TA, 
            text = gplatz,
            fg= "purple",
            bg = "black",
            font = "Roman 20",
                    )
            lab_gplatz.place(x=850, y=105)
            lab_platz =Label (TA, 
            text = platz,
            fg= "purple",
            bg = "black",
            font = "Roman 20",
                    )
            lab_platz.place(x=700, y=700)
            lab_AP_Wert =Label (TA, 
            text = Wert_AP,
            fg= "green",
            bg = "black",
            font = "Roman 20",
                    )
            lab_AP_Wert.place(x=850, y=105)
            lab_Kriegskunst_Wert = Label (TA, 
            text = Wert_Kriegskunst,
            fg= "purple",
            bg= "black",
            font = "Roman 20",
            )
            lab_Kriegskunst.place(x=480, y=700)
            lab_Kriegskunst_Wert.place(x=700, y=700)

             #------------------------------------------------------------------------------------------------------------#

    def RechneplusWahrnehmung():
        global Wert_AP
        global Wert_Wahrnehmung
        global lab_gplatz
        global gplatz
        global Wert_gesamt
        global platz
        global lab_platz
        if (Wert_AP>Wert_Rechne):
            Wert_Wahrnehmung += plus_minus
            Wert_AP -= (plus_minus)
            Wert_gesamt += plus_minus
            lab_gplatz =Label (TA, 
            text = gplatz,
            fg= "purple",
            bg = "black",
            font = "Roman 20",
                    )
            lab_gplatz.place(x=850, y=105)
            lab_platz =Label (TA, 
            text = platz,
            fg= "purple",
            bg = "black",
            font = "Roman 20",
                    )
            lab_platz.place(x=700, y=800)
            lab_AP_Wert =Label (TA, 
            text = Wert_AP,
            fg= "green",
            bg= "black",
            font = "Roman 20",
                    )
            lab_AP_Wert.place(x=850, y=105)
            lab_Wahrnehmung_Wert = Label (TA, 
            text = Wert_Wahrnehmung,
            fg= "purple",
            bg = "black",
            font = "Roman 20",
            )
            lab_Wahrnehmung.place(x=480, y=800)
            lab_Wahrnehmung_Wert.place(x=700, y=800)

    def RechneminusWahrnehmung():
        global Wert_AP
        global Wert_Wahrnehmung
        global lab_gplatz
        global gplatz
        global Wert_gesamt
        global platz
        global lab_platz
        if (Wert_Wahrnehmung>Wert_Rechne):
            Wert_AP += (plus_minus)
            Wert_Wahrnehmung -= plus_minus
            Wert_gesamt -= plus_minus
            lab_gplatz =Label (TA, 
            text = gplatz,
            fg= "purple",
            bg = "black",
            font = "Roman 20",
                    )
            lab_gplatz.place(x=850, y=105)
            lab_platz =Label (TA, 
            text = platz,
            fg= "purple",
            bg = "black",
            font = "Roman 20",
                    )
            lab_platz.place(x=700, y=800)
            lab_AP_Wert =Label (TA, 
            text = Wert_AP,
            fg= "green",
            bg = "black",
            font = "Roman 20",
                    )
            lab_AP_Wert.place(x=850, y=105)
            lab_Wahrnehmung_Wert = Label (TA, 
            text = Wert_Wahrnehmung,
            fg= "purple",
            bg= "black",
            font = "Roman 20",
            )
            lab_Wahrnehmung.place(x=480, y=800)
            lab_Wahrnehmung_Wert.place(x=700, y=800)
             #------------------------------------------------------------------------------------------------------------#

    def RechneplusUeberreden():
        global Wert_AP
        global Wert_Ueberreden
        global lab_gplatz
        global gplatz
        global Wert_gesamt
        global platz
        global lab_platz
        if (Wert_AP>Wert_Rechne):
            Wert_Ueberreden += plus_minus
            Wert_AP -= (plus_minus)
            Wert_gesamt += plus_minus
            lab_gplatz =Label (TA, 
            text = gplatz,
            fg= "purple",
            bg = "black",
            font = "Roman 20",
                    )
            lab_gplatz.place(x=850, y=105)
            lab_platz =Label (TA, 
            text = platz,
            fg= "purple",
            bg = "black",
            font = "Roman 20",
                    )
            lab_platz.place(x=700, y=900)
            lab_AP_Wert =Label (TA, 
            text = Wert_AP,
            fg= "green",
            bg= "black",
            font = "Roman 20",
                    )
            lab_AP_Wert.place(x=850, y=105)
            lab_Ueberreden_Wert = Label (TA, 
            text = Wert_Ueberreden,
            fg= "purple",
            bg = "black",
            font = "Roman 20",
            )
            lab_Ueberreden.place(x=480, y=900)
            lab_Ueberreden_Wert.place(x=700, y=900)

    def RechneminusUeberreden():
        global Wert_AP
        global Wert_Ueberreden
        global lab_gplatz
        global gplatz
        global Wert_gesamt
        global platz
        global lab_platz
        if (Wert_Ueberreden>Wert_Rechne):
            Wert_AP += (plus_minus)
            Wert_Ueberreden -= plus_minus
            Wert_gesamt -= plus_minus
            lab_gplatz =Label (TA, 
            text = gplatz,
            fg= "purple",
            bg = "black",
            font = "Roman 20",
                    )
            lab_gplatz.place(x=850, y=105)
            lab_platz =Label (TA, 
            text = platz,
            fg= "purple",
            bg = "black",
            font = "Roman 20",
                    )
            lab_platz.place(x=700, y=900)
            lab_AP_Wert =Label (TA, 
            text = Wert_AP,
            fg= "green",
            bg = "black",
            font = "Roman 20",
                    )
            lab_AP_Wert.place(x=850, y=105)
            lab_Ueberreden_Wert = Label (TA, 
            text = Wert_Ueberreden,
            fg= "purple",
            bg= "black",
            font = "Roman 20",
            )
            lab_Ueberreden.place(x=480, y=900)
            lab_Ueberreden_Wert.place(x=700, y=900)
    #------------------------------------------------------------------------------------------------------------#

    def RechneplusMagiekunde():
        global Wert_AP
        global Wert_Magiekunde
        global lab_gplatz
        global gplatz
        global Wert_gesamt
        global platz
        global lab_platz
        if (Wert_AP>Wert_Rechne):
            Wert_Magiekunde += plus_minus
            Wert_AP -= (plus_minus)
            Wert_gesamt += plus_minus
            lab_gplatz =Label (TA, 
            text = gplatz,
            fg= "purple",
            bg = "black",
            font = "Roman 20",
                    )
            lab_gplatz.place(x=850, y=105)
            lab_platz =Label (TA, 
            text = platz,
            fg= "purple",
            bg = "black",
            font = "Roman 20",
                    )
            lab_platz.place(x=1020, y=200)
            lab_AP_Wert =Label (TA, 
            text = Wert_AP,
            fg= "green",
            bg= "black",
            font = "Roman 20",
                    )
            lab_AP_Wert.place(x=850, y=105)
            lab_Magiekunde_Wert = Label (TA, 
            text = Wert_Magiekunde,
            fg= "purple",
            bg = "black",
            font = "Roman 20",
            )
            lab_Magiekunde.place(x=850, y=200)
            lab_Magiekunde_Wert.place(x=1020, y=200)

    def RechneminusMagiekunde():
        global Wert_AP
        global Wert_Magiekunde
        global lab_gplatz
        global gplatz
        global Wert_gesamt
        global platz
        global lab_platz
        if (Wert_Magiekunde>Wert_Rechne):
            Wert_Magiekunde -= plus_minus
            Wert_AP += (plus_minus)
            Wert_gesamt += plus_minus
            lab_gplatz =Label (TA, 
            text = gplatz,
            fg= "purple",
            bg = "black",
            font = "Roman 20",
                    )
            lab_gplatz.place(x=850, y=105)
            lab_platz =Label (TA, 
            text = platz,
            fg= "purple",
            bg = "black",
            font = "Roman 20",
                    )
            lab_platz.place(x=1020, y=200)
            lab_AP_Wert =Label (TA, 
            text = Wert_AP,
            fg= "green",
            bg= "black",
            font = "Roman 20",
                    )
            lab_AP_Wert.place(x=850, y=105)
            lab_Magiekunde_Wert = Label (TA, 
            text = Wert_Magiekunde,
            fg= "purple",
            bg = "black",
            font = "Roman 20",
            )
            lab_Magiekunde.place(x=850, y=200)
            lab_Magiekunde_Wert.place(x=1020, y=200)
        
    #------------------------------------------------------------------------------------------------------------#

    def RechneplusAblenkung():
        global Wert_AP
        global Wert_Ablenkung
        global lab_gplatz
        global gplatz
        global Wert_gesamt
        global platz
        global lab_platz
        if (Wert_AP>Wert_Rechne):
            Wert_Ablenkung += plus_minus
            Wert_AP -= (plus_minus)
            Wert_gesamt += plus_minus
            lab_gplatz =Label (TA, 
            text = gplatz,
            fg= "purple",
            bg = "black",
            font = "Roman 20",
                    )
            lab_gplatz.place(x=850, y=105)
            lab_platz =Label (TA, 
            text = platz,
            fg= "purple",
            bg = "black",
            font = "Roman 20",
                    )
            lab_platz.place(x=1020, y=300)
            lab_AP_Wert =Label (TA, 
            text = Wert_AP,
            fg= "green",
            bg= "black",
            font = "Roman 20",
                    )
            lab_AP_Wert.place(x=850, y=105)
            lab_Ablenkung_Wert = Label (TA, 
            text = Wert_Ablenkung,
            fg= "purple",
            bg = "black",
            font = "Roman 20",
            )
            lab_Ablenkung.place(x=850, y=300)
            lab_Ablenkung_Wert.place(x=1020, y=300)

    def RechneminusAblenkung():
        global Wert_AP
        global Wert_Ablenkung
        global lab_gplatz
        global gplatz
        global Wert_gesamt
        global platz
        global lab_platz
        if (Wert_Ablenkung>Wert_Rechne):
            Wert_Ablenkung -= plus_minus
            Wert_AP += (plus_minus)
            Wert_gesamt += plus_minus
            lab_gplatz =Label (TA, 
            text = gplatz,
            fg= "purple",
            bg = "black",
            font = "Roman 20",
                    )
            lab_gplatz.place(x=850, y=105)
            lab_platz =Label (TA, 
            text = platz,
            fg= "purple",
            bg = "black",
            font = "Roman 20",
                    )
            lab_platz.place(x=1020, y=300)
            lab_AP_Wert =Label (TA, 
            text = Wert_AP,
            fg= "green",
            bg= "black",
            font = "Roman 20",
                    )
            lab_AP_Wert.place(x=850, y=105)
            lab_Ablenkung_Wert = Label (TA, 
            text = Wert_Ablenkung,
            fg= "purple",
            bg = "black",
            font = "Roman 20",
            )
            lab_Ablenkung.place(x=850, y=300)
            lab_Ablenkung_Wert.place(x=1020, y=300)
        
    #------------------------------------------------------------------------------------------------------------#

    def RechneplusVerbergen():
        global Wert_AP
        global Wert_Verbergen
        global lab_gplatz
        global gplatz
        global Wert_gesamt
        global platz
        global lab_platz
        if (Wert_AP>Wert_Rechne):
            Wert_Verbergen += plus_minus
            Wert_AP -= (plus_minus)
            Wert_gesamt += plus_minus
            lab_gplatz =Label (TA, 
            text = gplatz,
            fg= "purple",
            bg = "black",
            font = "Roman 20",
                    )
            lab_gplatz.place(x=850, y=105)
            lab_platz =Label (TA, 
            text = platz,
            fg= "purple",
            bg = "black",
            font = "Roman 20",
                    )
            lab_platz.place(x=1020, y=400)
            lab_AP_Wert =Label (TA, 
            text = Wert_AP,
            fg= "green",
            bg= "black",
            font = "Roman 20",
                    )
            lab_AP_Wert.place(x=850, y=105)
            lab_Verbergen_Wert = Label (TA, 
            text = Wert_Verbergen,
            fg= "purple",
            bg = "black",
            font = "Roman 20",
            )
            lab_Verbergen.place(x=850, y=400)
            lab_Verbergen_Wert.place(x=1020, y=400)

    def RechneminusVerbergen():
        global Wert_AP
        global Wert_Verbergen
        global lab_gplatz
        global gplatz
        global Wert_gesamt
        global platz
        global lab_platz
        if (Wert_Verbergen>Wert_Rechne):
            Wert_Verbergen -= plus_minus
            Wert_AP += (plus_minus)
            Wert_gesamt += plus_minus
            lab_gplatz =Label (TA, 
            text = gplatz,
            fg= "purple",
            bg = "black",
            font = "Roman 20",
                    )
            lab_gplatz.place(x=850, y=105)
            lab_platz =Label (TA, 
            text = platz,
            fg= "purple",
            bg = "black",
            font = "Roman 20",
                    )
            lab_platz.place(x=1020, y=400)
            lab_AP_Wert =Label (TA, 
            text = Wert_AP,
            fg= "green",
            bg= "black",
            font = "Roman 20",
                    )
            lab_AP_Wert.place(x=850, y=105)
            lab_Verbergen_Wert = Label (TA, 
            text = Wert_Verbergen,
            fg= "purple",
            bg = "black",
            font = "Roman 20",
            )
            lab_Verbergen.place(x=850, y=400)
            lab_Verbergen_Wert.place(x=1020, y=400)
        
            #------------------------------------------------------------------------------------------------------------#

    def RechneplusSchwimmen():
        global Wert_AP
        global Wert_Schwimmen
        global lab_gplatz
        global gplatz
        global Wert_gesamt
        global platz
        global lab_platz
        if (Wert_AP>Wert_Rechne):
            Wert_Schwimmen += plus_minus
            Wert_AP -= (plus_minus)
            Wert_gesamt += plus_minus
            lab_gplatz =Label (TA, 
            text = gplatz,
            fg= "purple",
            bg = "black",
            font = "Roman 20",
                    )
            lab_gplatz.place(x=850, y=105)
            lab_platz =Label (TA, 
            text = platz,
            fg= "purple",
            bg = "black",
            font = "Roman 20",
                    )
            lab_platz.place(x=1020, y=500)
            lab_AP_Wert =Label (TA, 
            text = Wert_AP,
            fg= "green",
            bg= "black",
            font = "Roman 20",
                    )
            lab_AP_Wert.place(x=850, y=105)
            lab_Schwimmen_Wert = Label (TA, 
            text = Wert_Schwimmen,
            fg= "purple",
            bg = "black",
            font = "Roman 20",
            )
            lab_Schwimmen.place(x=850, y=500)
            lab_Schwimmen_Wert.place(x=1020, y=500)

    def RechneminusSchwimmen():
        global Wert_AP
        global Wert_Schwimmen
        global lab_gplatz
        global gplatz
        global Wert_gesamt
        global platz
        global lab_platz
        if (Wert_Schwimmen>Wert_Rechne):
            Wert_Schwimmen -= plus_minus
            Wert_AP += (plus_minus)
            Wert_gesamt += plus_minus
            lab_gplatz =Label (TA, 
            text = gplatz,
            fg= "purple",
            bg = "black",
            font = "Roman 20",
                    )
            lab_gplatz.place(x=850, y=105)
            lab_platz =Label (TA, 
            text = platz,
            fg= "purple",
            bg = "black",
            font = "Roman 20",
                    )
            lab_platz.place(x=1020, y=500)
            lab_AP_Wert =Label (TA, 
            text = Wert_AP,
            fg= "green",
            bg= "black",
            font = "Roman 20",
                    )
            lab_AP_Wert.place(x=850, y=105)
            lab_Schwimmen_Wert = Label (TA, 
            text = Wert_Schwimmen,
            fg= "purple",
            bg = "black",
            font = "Roman 20",
            )
            lab_Schwimmen.place(x=850, y=500)
            lab_Schwimmen_Wert.place(x=1020, y=500)
        
            #------------------------------------------------------------------------------------------------------------#

    def RechneplusHeilkunde():
        global Wert_AP
        global Wert_Heilkunde
        global lab_gplatz
        global gplatz
        global Wert_gesamt
        global platz
        global lab_platz
        if (Wert_AP>Wert_Rechne):
            Wert_Heilkunde += plus_minus
            Wert_AP -= (plus_minus)
            Wert_gesamt += plus_minus
            lab_gplatz =Label (TA, 
            text = gplatz,
            fg= "purple",
            bg = "black",
            font = "Roman 20",
                    )
            lab_gplatz.place(x=850, y=105)
            lab_platz =Label (TA, 
            text = platz,
            fg= "purple",
            bg = "black",
            font = "Roman 20",
                    )
            lab_platz.place(x=1020, y=600)
            lab_AP_Wert =Label (TA, 
            text = Wert_AP,
            fg= "green",
            bg= "black",
            font = "Roman 20",
                    )
            lab_AP_Wert.place(x=850, y=105)
            lab_Heilkunde_Wert = Label (TA, 
            text = Wert_Heilkunde,
            fg= "purple",
            bg = "black",
            font = "Roman 20",
            )
            lab_Heilkunde.place(x=850, y=600)
            lab_Heilkunde_Wert.place(x=1020, y=600)

    def RechneminusHeilkunde():
        global Wert_AP
        global Wert_Heilkunde
        global lab_gplatz
        global gplatz
        global Wert_gesamt
        global platz
        global lab_platz
        if (Wert_Heilkunde>Wert_Rechne):
            Wert_Heilkunde -= plus_minus
            Wert_AP += (plus_minus)
            Wert_gesamt += plus_minus
            lab_gplatz =Label (TA, 
            text = gplatz,
            fg= "purple",
            bg = "black",
            font = "Roman 20",
                    )
            lab_gplatz.place(x=850, y=105)
            lab_platz =Label (TA, 
            text = platz,
            fg= "purple",
            bg = "black",
            font = "Roman 20",
                    )
            lab_platz.place(x=1020, y=600)
            lab_AP_Wert =Label (TA, 
            text = Wert_AP,
            fg= "green",
            bg= "black",
            font = "Roman 20",
                    )
            lab_AP_Wert.place(x=850, y=105)
            lab_Heilkunde_Wert = Label (TA, 
            text = Wert_Heilkunde,
            fg= "purple",
            bg = "black",
            font = "Roman 20",
            )
            lab_Heilkunde.place(x=850, y=600)
            lab_Heilkunde_Wert.place(x=1020, y=600)
        
    #------------------------------------------------------------------------------------------------------------#

    def RechneplusTierkunde():
        global Wert_AP
        global Wert_Tierkunde
        global lab_gplatz
        global gplatz
        global Wert_gesamt
        global platz
        global lab_platz
        if (Wert_AP>Wert_Rechne):
            Wert_Tierkunde += plus_minus
            Wert_AP -= (plus_minus)
            Wert_gesamt += plus_minus
            lab_gplatz =Label (TA, 
            text = gplatz,
            fg= "purple",
            bg = "black",
            font = "Roman 20",
                    )
            lab_gplatz.place(x=850, y=105)
            lab_platz =Label (TA, 
            text = platz,
            fg= "purple",
            bg = "black",
            font = "Roman 20",
                    )
            lab_platz.place(x=1020, y=700)
            lab_AP_Wert =Label (TA, 
            text = Wert_AP,
            fg= "green",
            bg= "black",
            font = "Roman 20",
                    )
            lab_AP_Wert.place(x=850, y=105)
            lab_Tierkunde_Wert = Label (TA, 
            text = Wert_Tierkunde,
            fg= "purple",
            bg = "black",
            font = "Roman 20",
            )
            lab_Tierkunde.place(x=850, y=700)
            lab_Tierkunde_Wert.place(x=1020, y=700)

    def RechneminusTierkunde():
        global Wert_AP
        global Wert_Tierkunde
        global lab_gplatz
        global gplatz
        global Wert_gesamt
        global platz
        global lab_platz
        if (Wert_Tierkunde>Wert_Rechne):
            Wert_Tierkunde -= plus_minus
            Wert_AP += (plus_minus)
            Wert_gesamt += plus_minus
            lab_gplatz =Label (TA, 
            text = gplatz,
            fg= "purple",
            bg = "black",
            font = "Roman 20",
                    )
            lab_gplatz.place(x=850, y=105)
            lab_platz =Label (TA, 
            text = platz,
            fg= "purple",
            bg = "black",
            font = "Roman 20",
                    )
            lab_platz.place(x=1020, y=700)
            lab_AP_Wert =Label (TA, 
            text = Wert_AP,
            fg= "green",
            bg= "black",
            font = "Roman 20",
                    )
            lab_AP_Wert.place(x=850, y=105)
            lab_Tierkunde_Wert = Label (TA, 
            text = Wert_Tierkunde,
            fg= "purple",
            bg = "black",
            font = "Roman 20",
            )
            lab_Tierkunde.place(x=850, y=700)
            lab_Tierkunde_Wert.place(x=1020, y=700)
        
    #------------------------------------------------------------------------------------------------------------#

    def RechneplusBetoeren():
        global Wert_AP
        global Wert_Betoeren
        global lab_gplatz
        global gplatz
        global Wert_gesamt
        global platz
        global lab_platz
        if (Wert_AP>Wert_Rechne):
            Wert_Betoeren += plus_minus
            Wert_AP -= (plus_minus)
            Wert_gesamt += plus_minus
            lab_gplatz =Label (TA, 
            text = gplatz,
            fg= "purple",
            bg = "black",
            font = "Roman 20",
                    )
            lab_gplatz.place(x=850, y=105)
            lab_platz =Label (TA, 
            text = platz,
            fg= "purple",
            bg = "black",
            font = "Roman 20",
                    )
            lab_platz.place(x=1020, y=800)
            lab_AP_Wert =Label (TA, 
            text = Wert_AP,
            fg= "green",
            bg= "black",
            font = "Roman 20",
                    )
            lab_AP_Wert.place(x=850, y=105)
            lab_Betoeren_Wert = Label (TA, 
            text = Wert_Betoeren,
            fg= "purple",
            bg = "black",
            font = "Roman 20",
            )
            lab_Betoeren.place(x=850, y=800)
            lab_Betoeren_Wert.place(x=1020, y=800)

    def RechneminusBetoeren():
        global Wert_AP
        global Wert_Betoeren
        global lab_gplatz
        global gplatz
        global Wert_gesamt
        global platz
        global lab_platz
        if (Wert_Betoeren>Wert_Rechne):
            Wert_Betoeren -= plus_minus
            Wert_AP += (plus_minus)
            Wert_gesamt += plus_minus
            lab_gplatz =Label (TA, 
            text = gplatz,
            fg= "purple",
            bg = "black",
            font = "Roman 20",
                    )
            lab_gplatz.place(x=850, y=105)
            lab_platz =Label (TA, 
            text = platz,
            fg= "purple",
            bg = "black",
            font = "Roman 20",
                    )
            lab_platz.place(x=1020, y=800)
            lab_AP_Wert =Label (TA, 
            text = Wert_AP,
            fg= "green",
            bg= "black",
            font = "Roman 20",
                    )
            lab_AP_Wert.place(x=850, y=105)
            lab_Betoeren_Wert = Label (TA, 
            text = Wert_Betoeren,
            fg= "purple",
            bg = "black",
            font = "Roman 20",
            )
            lab_Betoeren.place(x=850, y=800)
            lab_Betoeren_Wert.place(x=1020, y=800)
        
    #------------------------------------------------------------------------------------------------------------#

    def RechneplusKlettern():
        global Wert_AP
        global Wert_Klettern
        global lab_gplatz
        global gplatz
        global Wert_gesamt
        global platz
        global lab_platz
        if (Wert_AP>Wert_Rechne):
            Wert_Klettern += plus_minus
            Wert_AP -= (plus_minus)
            Wert_gesamt += plus_minus
            lab_gplatz =Label (TA, 
            text = gplatz,
            fg= "purple",
            bg = "black",
            font = "Roman 20",
                    )
            lab_gplatz.place(x=850, y=105)
            lab_platz =Label (TA, 
            text = platz,
            fg= "purple",
            bg = "black",
            font = "Roman 20",
                    )
            lab_platz.place(x=1020, y=900)
            lab_AP_Wert =Label (TA, 
            text = Wert_AP,
            fg= "green",
            bg= "black",
            font = "Roman 20",
                    )
            lab_AP_Wert.place(x=850, y=105)
            lab_Klettern_Wert = Label (TA, 
            text = Wert_Klettern,
            fg= "purple",
            bg = "black",
            font = "Roman 20",
            )
            lab_Klettern.place(x=850, y=900)
            lab_Klettern_Wert.place(x=1020, y=900)

    def RechneminusKlettern():
        global Wert_AP
        global Wert_Klettern
        global lab_gplatz
        global gplatz
        global Wert_gesamt
        global platz
        global lab_platz
        if (Wert_Klettern>Wert_Rechne):
            Wert_Klettern -= plus_minus
            Wert_AP += (plus_minus)
            Wert_gesamt += plus_minus
            lab_gplatz =Label (TA, 
            text = gplatz,
            fg= "purple",
            bg = "black",
            font = "Roman 20",
                    )
            lab_gplatz.place(x=850, y=105)
            lab_platz =Label (TA, 
            text = platz,
            fg= "purple",
            bg = "black",
            font = "Roman 20",
                    )
            lab_platz.place(x=1020, y=900)
            lab_AP_Wert =Label (TA, 
            text = Wert_AP,
            fg= "green",
            bg= "black",
            font = "Roman 20",
                    )
            lab_AP_Wert.place(x=850, y=105)
            lab_Klettern_Wert = Label (TA, 
            text = Wert_Klettern,
            fg= "purple",
            bg = "black",
            font = "Roman 20",
            )
            lab_Klettern.place(x=850, y=900)
            lab_Klettern_Wert.place(x=1020, y=900)

    #------------------------------------------------------------------------------------------------------------#

    def RechneplusHandwerk():
        global Wert_AP
        global Wert_Handwerk
        global lab_gplatz
        global gplatz
        global Wert_gesamt
        global platz
        global lab_platz
        if (Wert_AP>Wert_Rechne):
            Wert_Handwerk += plus_minus
            Wert_AP -= (plus_minus)
            Wert_gesamt += plus_minus
            lab_gplatz =Label (TA, 
            text = gplatz,
            fg= "purple",
            bg = "black",
            font = "Roman 20",
                    )
            lab_gplatz.place(x=850, y=105)
            lab_platz =Label (TA, 
            text = platz,
            fg= "purple",
            bg = "black",
            font = "Roman 20",
                    )
            lab_platz.place(x=1340, y=200)
            lab_AP_Wert =Label (TA, 
            text = Wert_AP,
            fg= "green",
            bg= "black",
            font = "Roman 20",
                    )
            lab_AP_Wert.place(x=850, y=105)
            lab_Handwerk_Wert = Label (TA, 
            text = Wert_Handwerk,
            fg= "purple",
            bg = "black",
            font = "Roman 20",
            )
            lab_Handwerk.place(x=1170, y=200)
            lab_Handwerk_Wert.place(x=1340, y=200)

    def RechneminusHandwerk():
        global Wert_AP
        global Wert_Handwerk
        global lab_gplatz
        global gplatz
        global Wert_gesamt
        global platz
        global lab_platz
        if (Wert_Handwerk>Wert_Rechne):
            Wert_Handwerk -= plus_minus
            Wert_AP += (plus_minus)
            Wert_gesamt -= plus_minus
            lab_gplatz =Label (TA, 
            text = gplatz,
            fg= "purple",
            bg = "black",
            font = "Roman 20",
                    )
            lab_gplatz.place(x=850, y=105)
            lab_platz =Label (TA, 
            text = platz,
            fg= "purple",
            bg = "black",
            font = "Roman 20",
                    )
            lab_platz.place(x=1340, y=200)
            lab_AP_Wert =Label (TA, 
            text = Wert_AP,
            fg= "green",
            bg= "black",
            font = "Roman 20",
                    )
            lab_AP_Wert.place(x=850, y=105)
            lab_Handwerk_Wert = Label (TA, 
            text = Wert_Handwerk,
            fg= "purple",
            bg = "black",
            font = "Roman 20",
            )
            lab_Handwerk.place(x=1170, y=200)
            lab_Handwerk_Wert.place(x=1340, y=200)

    #------------------------------------------------------------------------------------------------------------#

    def RechneplusAlchemie():
        global Wert_AP
        global Wert_Alchemie
        global lab_gplatz
        global gplatz
        global Wert_gesamt
        global platz
        global lab_platz
        if (Wert_AP>Wert_Rechne):
            Wert_Alchemie += plus_minus
            Wert_AP -= (plus_minus)
            Wert_gesamt += plus_minus
            lab_gplatz =Label (TA, 
            text = gplatz,
            fg= "purple",
            bg = "black",
            font = "Roman 20",
                    )
            lab_gplatz.place(x=850, y=105)
            lab_platz =Label (TA, 
            text = platz,
            fg= "purple",
            bg = "black",
            font = "Roman 20",
                    )
            lab_platz.place(x=1340, y=300)
            lab_AP_Wert =Label (TA, 
            text = Wert_AP,
            fg= "green",
            bg= "black",
            font = "Roman 20",
                    )
            lab_AP_Wert.place(x=850, y=105)
            lab_Alchemie_Wert = Label (TA, 
            text = Wert_Alchemie,
            fg= "purple",
            bg = "black",
            font = "Roman 20",
            )
            lab_Alchemie.place(x=1170, y=300)
            lab_Alchemie_Wert.place(x=1340, y=300)

    def RechneminusAlchemie():
        global Wert_AP
        global Wert_Alchemie
        global lab_gplatz
        global gplatz
        global Wert_gesamt
        global platz
        global lab_platz
        if (Wert_Alchemie>Wert_Rechne):
            Wert_Alchemie -= plus_minus
            Wert_AP += (plus_minus)
            Wert_gesamt -= plus_minus
            lab_gplatz =Label (TA, 
            text = gplatz,
            fg= "purple",
            bg = "black",
            font = "Roman 20",
                    )
            lab_gplatz.place(x=850, y=105)
            lab_platz =Label (TA, 
            text = platz,
            fg= "purple",
            bg = "black",
            font = "Roman 20",
                    )
            lab_platz.place(x=1340, y=300)
            lab_AP_Wert =Label (TA, 
            text = Wert_AP,
            fg= "green",
            bg= "black",
            font = "Roman 20",
                    )
            lab_AP_Wert.place(x=850, y=105)
            lab_Alchemie_Wert = Label (TA, 
            text = Wert_Alchemie,
            fg= "purple",
            bg = "black",
            font = "Roman 20",
            )
            lab_Alchemie.place(x=1170, y=300)
            lab_Alchemie_Wert.place(x=1340, y=300)

    #------------------------------------------------------------------------------------------------------------#

    def RechneplusKraftakt():
        global Wert_AP
        global Wert_Kraftakt
        global lab_gplatz
        global gplatz
        global Wert_gesamt
        global platz
        global lab_platz
        if (Wert_AP>Wert_Rechne):
            Wert_Kraftakt += plus_minus
            Wert_AP -= (plus_minus)
            Wert_gesamt += plus_minus
            lab_gplatz =Label (TA, 
            text = gplatz,
            fg= "purple",
            bg = "black",
            font = "Roman 20",
                    )
            lab_gplatz.place(x=850, y=105)
            lab_platz =Label (TA, 
            text = platz,
            fg= "purple",
            bg = "black",
            font = "Roman 20",
                    )
            lab_platz.place(x=1340, y=400)
            lab_AP_Wert =Label (TA, 
            text = Wert_AP,
            fg= "green",
            bg= "black",
            font = "Roman 20",
                    )
            lab_AP_Wert.place(x=850, y=105)
            lab_Kraftakt_Wert = Label (TA, 
            text = Wert_Kraftakt,
            fg= "purple",
            bg = "black",
            font = "Roman 20",
            )
            lab_Kraftakt.place(x=1170, y=400)
            lab_Kraftakt_Wert.place(x=1340, y=400)

    def RechneminusKraftakt():
        global Wert_AP
        global Wert_Kraftakt
        global lab_gplatz
        global gplatz
        global Wert_gesamt
        global platz
        global lab_platz
        if (Wert_Kraftakt>Wert_Rechne):
            Wert_Kraftakt -= plus_minus
            Wert_AP += (plus_minus)
            Wert_gesamt -= plus_minus
            lab_gplatz =Label (TA, 
            text = gplatz,
            fg= "purple",
            bg = "black",
            font = "Roman 20",
                    )
            lab_gplatz.place(x=850, y=105)
            lab_platz =Label (TA, 
            text = platz,
            fg= "purple",
            bg = "black",
            font = "Roman 20",
                    )
            lab_platz.place(x=1340, y=400)
            lab_AP_Wert =Label (TA, 
            text = Wert_AP,
            fg= "green",
            bg= "black",
            font = "Roman 20",
                    )
            lab_AP_Wert.place(x=850, y=105)
            lab_Kraftakt_Wert = Label (TA, 
            text = Wert_Kraftakt,
            fg= "purple",
            bg = "black",
            font = "Roman 20",
            )
            lab_Kraftakt.place(x=1170, y=400)
            lab_Kraftakt_Wert.place(x=1340, y=400)
        
    #------------------------------------------------------------------------------------------------------------#

    def RechneplusSammeln():
        global Wert_AP
        global Wert_Sammeln
        global lab_gplatz
        global gplatz
        global Wert_gesamt
        global platz
        global lab_platz
        if (Wert_AP>Wert_Rechne):
            Wert_Sammeln += plus_minus
            Wert_AP -= (plus_minus)
            Wert_gesamt += plus_minus
            lab_gplatz =Label (TA, 
            text = gplatz,
            fg= "purple",
            bg = "black",
            font = "Roman 20",
                    )
            lab_gplatz.place(x=850, y=105)
            lab_platz =Label (TA, 
            text = platz,
            fg= "purple",
            bg = "black",
            font = "Roman 20",
                    )
            lab_platz.place(x=1340, y=500)
            lab_AP_Wert =Label (TA, 
            text = Wert_AP,
            fg= "green",
            bg= "black",
            font = "Roman 20",
                    )
            lab_AP_Wert.place(x=850, y=105)
            lab_Sammeln_Wert = Label (TA, 
            text = Wert_Sammeln,
            fg= "purple",
            bg = "black",
            font = "Roman 20",
            )
            lab_Sammeln.place(x=1170, y=500)
            lab_Sammeln_Wert.place(x=1340, y=500)

    def RechneminusSammeln():
        global Wert_AP
        global Wert_Sammeln
        global lab_gplatz
        global gplatz
        global Wert_gesamt
        global platz
        global lab_platz
        if (Wert_Sammeln>Wert_Rechne):
            Wert_Sammeln -= plus_minus
            Wert_AP += (plus_minus)
            Wert_gesamt -= plus_minus
            lab_gplatz =Label (TA, 
            text = gplatz,
            fg= "purple",
            bg = "black",
            font = "Roman 20",
                    )
            lab_gplatz.place(x=850, y=105)
            lab_platz =Label (TA, 
            text = platz,
            fg= "purple",
            bg = "black",
            font = "Roman 20",
                    )
            lab_platz.place(x=1340, y=500)
            lab_AP_Wert =Label (TA, 
            text = Wert_AP,
            fg= "green",
            bg= "black",
            font = "Roman 20",
                    )
            lab_AP_Wert.place(x=850, y=105)
            lab_Sammeln_Wert = Label (TA, 
            text = Wert_Sammeln,
            fg= "purple",
            bg = "black",
            font = "Roman 20",
            )
            lab_Sammeln.place(x=1170, y=500)
            lab_Sammeln_Wert.place(x=1340, y=500)
        
    #------------------------------------------------------------------------------------------------------------#

    def RechneplusHandeln():
        global Wert_AP
        global Wert_Handeln
        global lab_gplatz
        global gplatz
        global Wert_gesamt
        global platz
        global lab_platz
        if (Wert_AP>Wert_Rechne):
            Wert_Handeln += plus_minus
            Wert_AP -= (plus_minus)
            Wert_gesamt += plus_minus
            lab_gplatz =Label (TA, 
            text = gplatz,
            fg= "purple",
            bg = "black",
            font = "Roman 20",
                    )
            lab_gplatz.place(x=850, y=105)
            lab_platz =Label (TA, 
            text = platz,
            fg= "purple",
            bg = "black",
            font = "Roman 20",
                    )
            lab_platz.place(x=1340, y=600)
            lab_AP_Wert =Label (TA, 
            text = Wert_AP,
            fg= "green",
            bg= "black",
            font = "Roman 20",
                    )
            lab_AP_Wert.place(x=850, y=105)
            lab_Handeln_Wert = Label (TA, 
            text = Wert_Handeln,
            fg= "purple",
            bg = "black",
            font = "Roman 20",
            )
            lab_Handeln.place(x=1170, y=600)
            lab_Handeln_Wert.place(x=1340, y=600)

    def RechneminusHandeln():
        global Wert_AP
        global Wert_Handeln
        global lab_gplatz
        global gplatz
        global Wert_gesamt
        global platz
        global lab_platz
        if (Wert_Handeln>Wert_Rechne):
            Wert_Handeln -= plus_minus
            Wert_AP += (plus_minus)
            Wert_gesamt -= plus_minus
            lab_gplatz =Label (TA, 
            text = gplatz,
            fg= "purple",
            bg = "black",
            font = "Roman 20",
                    )
            lab_gplatz.place(x=850, y=105)
            lab_platz =Label (TA, 
            text = platz,
            fg= "purple",
            bg = "black",
            font = "Roman 20",
                    )
            lab_platz.place(x=1340, y=600)
            lab_AP_Wert =Label (TA, 
            text = Wert_AP,
            fg= "green",
            bg= "black",
            font = "Roman 20",
                    )
            lab_AP_Wert.place(x=850, y=105)
            lab_Handeln_Wert = Label (TA, 
            text = Wert_Handeln,
            fg= "purple",
            bg = "black",
            font = "Roman 20",
            )
            lab_Handeln.place(x=1170, y=600)
            lab_Handeln_Wert.place(x=1340, y=600)
        
    #------------------------------------------------------------------------------------------------------------#

    def RechneplusFesseln():
        global Wert_AP
        global Wert_Fesseln
        global lab_gplatz
        global gplatz
        global Wert_gesamt
        global platz
        global lab_platz
        if (Wert_AP>Wert_Rechne):
            Wert_Fesseln += plus_minus
            Wert_AP -= (plus_minus)
            Wert_gesamt += plus_minus
            lab_gplatz =Label (TA, 
            text = gplatz,
            fg= "purple",
            bg = "black",
            font = "Roman 20",
                    )
            lab_gplatz.place(x=850, y=105)
            lab_platz =Label (TA, 
            text = platz,
            fg= "purple",
            bg = "black",
            font = "Roman 20",
                    )
            lab_platz.place(x=1340, y=700)
            lab_AP_Wert =Label (TA, 
            text = Wert_AP,
            fg= "green",
            bg= "black",
            font = "Roman 20",
                    )
            lab_AP_Wert.place(x=850, y=105)
            lab_Fesseln_Wert = Label (TA, 
            text = Wert_Fesseln,
            fg= "purple",
            bg = "black",
            font = "Roman 20",
            )
            lab_Fesseln.place(x=1170, y=700)
            lab_Fesseln_Wert.place(x=1340, y=700)

    def RechneminusFesseln():
        global Wert_AP
        global Wert_Fesseln
        global lab_gplatz
        global gplatz
        global Wert_gesamt
        global platz
        global lab_platz
        if (Wert_Fesseln>Wert_Rechne):
            Wert_Fesseln -= plus_minus
            Wert_AP += (plus_minus)
            Wert_gesamt -= plus_minus
            lab_gplatz =Label (TA, 
            text = gplatz,
            fg= "purple",
            bg = "black",
            font = "Roman 20",
                    )
            lab_gplatz.place(x=850, y=105)
            lab_platz =Label (TA, 
            text = platz,
            fg= "purple",
            bg = "black",
            font = "Roman 20",
                    )
            lab_platz.place(x=1340, y=700)
            lab_AP_Wert =Label (TA, 
            text = Wert_AP,
            fg= "green",
            bg= "black",
            font = "Roman 20",
                    )
            lab_AP_Wert.place(x=850, y=105)
            lab_Fesseln_Wert = Label (TA, 
            text = Wert_Fesseln,
            fg= "purple",
            bg = "black",
            font = "Roman 20",
            )
            lab_Fesseln.place(x=1170, y=700)
            lab_Fesseln_Wert.place(x=1340, y=700)
        
    #------------------------------------------------------------------------------------------------------------#

    def RechneplusZechen():
        global Wert_AP
        global Wert_Zechen
        global lab_gplatz
        global gplatz
        global Wert_gesamt
        global platz
        global lab_platz
        if (Wert_AP>Wert_Rechne):
            Wert_Zechen += plus_minus
            Wert_AP -= (plus_minus)
            Wert_gesamt += plus_minus
            lab_gplatz =Label (TA, 
            text = gplatz,
            fg= "purple",
            bg = "black",
            font = "Roman 20",
                    )
            lab_gplatz.place(x=850, y=105)
            lab_platz =Label (TA, 
            text = platz,
            fg= "purple",
            bg = "black",
            font = "Roman 20",
                    )
            lab_platz.place(x=1340, y=800)
            lab_AP_Wert =Label (TA, 
            text = Wert_AP,
            fg= "green",
            bg= "black",
            font = "Roman 20",
                    )
            lab_AP_Wert.place(x=850, y=105)
            lab_Zechen_Wert = Label (TA, 
            text = Wert_Zechen,
            fg= "purple",
            bg = "black",
            font = "Roman 20",
            )
            lab_Zechen.place(x=1170, y=800)
            lab_Zechen_Wert.place(x=1340, y=800)

    def RechneminusZechen():
        global Wert_AP
        global Wert_Zechen
        global lab_gplatz
        global gplatz
        global Wert_gesamt
        global platz
        global lab_platz
        if (Wert_Zechen>Wert_Rechne):
            Wert_Zechen -= plus_minus
            Wert_AP += (plus_minus)
            Wert_gesamt -= plus_minus
            lab_gplatz =Label (TA, 
            text = gplatz,
            fg= "purple",
            bg = "black",
            font = "Roman 20",
                    )
            lab_gplatz.place(x=850, y=105)
            lab_platz =Label (TA, 
            text = platz,
            fg= "purple",
            bg = "black",
            font = "Roman 20",
                    )
            lab_platz.place(x=1340, y=800)
            lab_AP_Wert =Label (TA, 
            text = Wert_AP,
            fg= "green",
            bg= "black",
            font = "Roman 20",
                    )
            lab_AP_Wert.place(x=850, y=105)
            lab_Zechen_Wert = Label (TA, 
            text = Wert_Zechen,
            fg= "purple",
            bg = "black",
            font = "Roman 20",
            )
            lab_Zechen.place(x=1170, y=800)
            lab_Zechen_Wert.place(x=1340, y=800)
        
    #------------------------------------------------------------------------------------------------------------#

    def RechneplusJagen():
        global Wert_AP
        global Wert_Jagen
        global lab_gplatz
        global gplatz
        global Wert_gesamt
        global platz
        global lab_platz
        if (Wert_AP>Wert_Rechne):
            Wert_Jagen += plus_minus
            Wert_AP -= (plus_minus)
            Wert_gesamt += plus_minus
            lab_gplatz =Label (TA, 
            text = gplatz,
            fg= "purple",
            bg = "black",
            font = "Roman 20",
                    )
            lab_gplatz.place(x=850, y=105)
            lab_platz =Label (TA, 
            text = platz,
            fg= "purple",
            bg = "black",
            font = "Roman 20",
                    )
            lab_platz.place(x=1340, y=900)
            lab_AP_Wert =Label (TA, 
            text = Wert_AP,
            fg= "green",
            bg= "black",
            font = "Roman 20",
                    )
            lab_AP_Wert.place(x=850, y=105)
            lab_Jagen_Wert = Label (TA, 
            text = Wert_Jagen,
            fg= "purple",
            bg = "black",
            font = "Roman 20",
            )
            lab_Jagen.place(x=1170, y=900)
            lab_Jagen_Wert.place(x=1340, y=900)

    def RechneminusJagen():
        global Wert_AP
        global Wert_Jagen
        global lab_gplatz
        global gplatz
        global Wert_gesamt
        global platz
        global lab_platz
        if (Wert_Jagen>Wert_Rechne):
            Wert_Jagen -= plus_minus
            Wert_AP += (plus_minus)
            Wert_gesamt -= plus_minus
            lab_gplatz =Label (TA, 
            text = gplatz,
            fg= "purple",
            bg = "black",
            font = "Roman 20",
                    )
            lab_gplatz.place(x=850, y=105)
            lab_platz =Label (TA, 
            text = platz,
            fg= "purple",
            bg = "black",
            font = "Roman 20",
                    )
            lab_platz.place(x=1340, y=900)
            lab_AP_Wert =Label (TA, 
            text = Wert_AP,
            fg= "green",
            bg= "black",
            font = "Roman 20",
                    )
            lab_AP_Wert.place(x=850, y=105)
            lab_Jagen_Wert = Label (TA, 
            text = Wert_Jagen,
            fg= "purple",
            bg = "black",
            font = "Roman 20",
            )
            lab_Jagen.place(x=1170, y=900)
            lab_Jagen_Wert.place(x=1340, y=900)
    #############################################################################################################
    #############################################################################################################
    #but_nextPage =Button(TA,text="Seite vor",fg="purple",bg="black",font = "Arial 20", command= nextPage )
    #but_prevPage =Button(TA,text="Seite zurueck",fg="purple",bg="black",font = "Arial 20", command= prevPage )



    #------------------------------------------------------------------------------------------------------------#

    but_AP_pluseins =Button(TA,text="+ 1",fg="green",bg="black",font = "Roman 10", command= RechnepluseinsAP )
    but_AP_minuseins=Button(TA,text="- 1",fg="green",bg="black",font = "Roman 10", command=RechneminuseinsAP)

    but_AP_pluszehn =Button(TA,text="+ 10",fg="green",bg="black",font = "Roman 10", command= RechnepluszehnAP )
    but_AP_minuszehn=Button(TA,text="- 10",fg="green",bg="black",font = "Roman 10", command=RechneminuszehnAP)

    but_AP_plushundert =Button(TA,text="+ 100",fg="green",bg="black",font = "Roman 10", command= RechneplushundertAP )
    but_AP_minushundert=Button(TA,text="- 100",fg="green",bg="black",font = "Roman 10", command=RechneminushundertAP)

    #------------------------------------------------------------------------------------------------------------#
    but_Rechne1 = Button (TA,text="Um Eins steigern",fg="purple",bg="black",font = "Arial 20", command= Rechne1 )
    but_Rechne10 = Button (TA,text="Um Zehn steigern",fg="purple",bg="black",font = "Arial 20", command= Rechne10 )
    #------------------------------------------------------------------------------------------------------------#
    but_Intelligenz_plus =Button(TA,text="+",fg="green",bg="black",font = "Roman 10", command=lambda: [RechneplusIntelligenz()])
    but_Intelligenz_minus=Button(TA,text="-",fg="green",bg="black",font = "Roman 10", command=lambda: [RechneminusIntelligenz()])

    but_Kraft_plus =Button(TA,text="+",fg="green",bg="black",font = "Roman 10", command=lambda: [RechneplusKraft()])
    but_Kraft_minus=Button(TA,text="-", fg="green",bg="black",font = "Roman 10",command=lambda: [RechneminusKraft()])

    but_Ausdauer_plus =Button(TA,text="+",fg="green",bg="black",font = "Roman 10", command=lambda: [RechneplusAusdauer()]) 
    but_Ausdauer_minus=Button(TA,text="-",fg="green",bg="black",font = "Roman 10", command=lambda: [RechneminusAusdauer()])

    but_Charisma_plus =Button(TA,text="+",fg="green",bg="black",font = "Roman 10", command=lambda: [RechneplusCharisma()]) 
    but_Charisma_minus=Button(TA,text="-",fg="green",bg="black",font = "Roman 10", command=lambda: [RechneminusCharisma()])

    but_Intuition_plus =Button(TA,text="+",fg="green",bg="black",font = "Roman 10", command=lambda: [RechneplusIntuition()])
    but_Intuition_minus=Button(TA,text="-",fg="green",bg="black",font = "Roman 10", command=lambda: [RechneminusIntuition()])

    but_Fingerfertigkeit_plus =Button(TA,text="+",fg="green",bg="black",font = "Roman 10", command=lambda: [RechneplusFingerfertigkeit()])
    but_Fingerfertigkeit_minus=Button(TA,text="-",fg="green",bg="black",font = "Roman 10", command=lambda: [RechneminusFingerfertigkeit()])

    #------------------------------------------------------------------------------------------------------------#

    but_Lebensmittelbearbeitung_plus =Button(TA,text="+",fg="purple",bg="black",font = "Roman 10", command=lambda: [RechneplusLebensmittelbearbeitung()])
    but_Lebensmittelbearbeitung_minus=Button(TA,text="-",fg="purple",bg="black",font = "Roman 10", command=lambda: [RechneminusLebensmittelbearbeitung()])

    but_Koerperbeherrschung_plus =Button(TA,text="+",fg="purple",bg="black",font = "Roman 10", command=lambda: [RechneplusKoerperbeherrschung()])
    but_Koerperbeherrschung_minus=Button(TA,text="-",fg="purple",bg="black",font = "Roman 10", command=lambda: [RechneminusKoerperbeherrschung()])

    but_SagenundLegenden_plus =Button(TA,text="+",fg="purple",bg="black",font = "Roman 10", command=lambda: [RechneplusSagenundLegenden()])
    but_SagenundLegenden_minus=Button(TA,text="-",fg="purple",bg="black",font = "Roman 10", command=lambda: [RechneminusSagenundLegenden()])

    but_Selbstbeherrschung_plus =Button(TA,text="+",fg="purple",bg="black",font = "Roman 10", command=lambda: [RechneplusSelbstbeherrschung()])
    but_Selbstbeherrschung_minus=Button(TA,text="-",fg="purple",bg="black",font = "Roman 10", command=lambda: [RechneminusSelbstbeherrschung()])

    but_Schloesserknacken_plus =Button(TA,text="+",fg="purple",bg="black",font = "Roman 10", command=lambda: [RechneplusSchloesserknacken()])
    but_Schloesserknacken_minus=Button(TA,text="-",fg="purple",bg="black",font = "Roman 10", command=lambda: [RechneminusSchloesserknacken()])

    but_Menschenkenntnis_plus =Button(TA,text="+",fg="purple",bg="black",font = "Roman 10", command=lambda: [RechneplusMenschenkenntnis()])
    but_Menschenkenntnis_minus=Button(TA,text="-",fg="purple",bg="black",font = "Roman 10", command=lambda: [RechneminusMenschenkenntnis()])

    but_Taschendiebstahl_plus =Button(TA,text="+",fg="purple",bg="black",font = "Roman 10", command=lambda: [RechneplusTaschendiebstahl()])
    but_Taschendiebstahl_minus=Button(TA,text="-",fg="purple",bg="black",font = "Roman 10", command=lambda: [RechneminusTaschendiebstahl()])

    but_Pflanzenkunde_plus =Button(TA,text="+",fg="purple",bg="black",font = "Roman 10", command=lambda: [RechneplusPflanzenkunde()])
    but_Pflanzenkunde_minus=Button(TA,text="-",fg="purple",bg="black",font = "Roman 10", command=lambda: [RechneminusPflanzenkunde()])

    but_Einschuechtern_plus =Button(TA,text="+",fg="purple",bg="black",font = "Roman 10", command=lambda: [RechneplusEinschuechtern()])
    but_Einschuechtern_minus=Button(TA,text="-",fg="purple",bg="black",font = "Roman 10", command=lambda: [RechneminusEinschuechtern()])

    but_Wildniskunde_plus =Button(TA,text="+",fg="purple",bg="black",font = "Roman 10", command=lambda: [RechneplusWildniskunde()])
    but_Wildniskunde_minus=Button(TA,text="-",fg="purple",bg="black",font = "Roman 10", command=lambda: [RechneminusWildniskunde()])

    but_Geistesblitz_plus =Button(TA,text="+",fg="purple",bg="black",font = "Roman 10", command=lambda: [RechneplusGeistesblitz()])
    but_Geistesblitz_minus=Button(TA,text="-",fg="purple",bg="black",font = "Roman 10", command=lambda: [RechneminusGeistesblitz()])

    but_Gassenwissen_plus =Button(TA,text="+",fg="purple",bg="black",font = "Roman 10", command=lambda: [RechneplusGassenwissen()])
    but_Gassenwissen_minus=Button(TA,text="-",fg="purple",bg="black",font = "Roman 10", command=lambda: [RechneminusGassenwissen()])

    but_Orientierung_plus =Button(TA,text="+",fg="purple",bg="black",font = "Roman 10", command=lambda: [RechneplusOrientierung()])
    but_Orientierung_minus=Button(TA,text="-",fg="purple",bg="black",font = "Roman 10", command=lambda: [RechneminusOrientierung()])

    but_Kriegskunst_plus =Button(TA,text="+",fg="purple",bg="black",font = "Roman 10", command=lambda: [RechneplusKriegskunst()])
    but_Kriegskunst_minus=Button(TA,text="-",fg="purple",bg="black",font = "Roman 10", command=lambda: [RechneminusKriegskunst()])

    but_Wahrnehmung_plus =Button(TA,text="+",fg="purple",bg="black",font = "Roman 10", command=lambda: [RechneplusWahrnehmung()])
    but_Wahrnehmung_minus=Button(TA,text="-",fg="purple",bg="black",font = "Roman 10", command=lambda: [RechneminusWahrnehmung()])

    but_Ueberreden_plus =Button(TA,text="+",fg="purple",bg="black",font = "Roman 10", command=lambda: [RechneplusUeberreden()])
    but_Ueberreden_minus=Button(TA,text="-",fg="purple",bg="black",font = "Roman 10", command=lambda: [RechneminusUeberreden()])

    but_Magiekunde_plus =Button(TA,text="+",fg="purple",bg="black",font = "Roman 10", command=lambda: [RechneplusMagiekunde()])
    but_Magiekunde_minus=Button(TA,text="-",fg="purple",bg="black",font = "Roman 10", command=lambda: [RechneminusMagiekunde()])

    but_Ablenkung_plus =Button(TA,text="+",fg="purple",bg="black",font = "Roman 10", command=lambda: [RechneplusAblenkung()])
    but_Ablenkung_minus=Button(TA,text="-",fg="purple",bg="black",font = "Roman 10", command=lambda: [RechneminusAblenkung()])

    but_Verbergen_plus =Button(TA,text="+",fg="purple",bg="black",font = "Roman 10", command=lambda: [RechneplusVerbergen()])
    but_Verbergen_minus=Button(TA,text="-",fg="purple",bg="black",font = "Roman 10", command=lambda: [RechneminusVerbergen()])

    but_Schwimmen_plus =Button(TA,text="+",fg="purple",bg="black",font = "Roman 10", command=lambda: [RechneplusSchwimmen()])
    but_Schwimmen_minus=Button(TA,text="-",fg="purple",bg="black",font = "Roman 10", command=lambda: [RechneminusSchwimmen()])

    but_Heilkunde_plus =Button(TA,text="+",fg="purple",bg="black",font = "Roman 10", command=lambda: [RechneplusHeilkunde()])
    but_Heilkunde_minus=Button(TA,text="-",fg="purple",bg="black",font = "Roman 10", command=lambda: [RechneminusHeilkunde()])

    but_Tierkunde_plus =Button(TA,text="+",fg="purple",bg="black",font = "Roman 10", command=lambda: [RechneplusTierkunde()])
    but_Tierkunde_minus=Button(TA,text="-",fg="purple",bg="black",font = "Roman 10", command=lambda: [RechneminusTierkunde()])

    but_Betoeren_plus =Button(TA,text="+",fg="purple",bg="black",font = "Roman 10", command=lambda: [RechneplusBetoeren()])
    but_Betoeren_minus=Button(TA,text="-",fg="purple",bg="black",font = "Roman 10", command=lambda: [RechneminusBetoeren()])

    but_Klettern_plus =Button(TA,text="+",fg="purple",bg="black",font = "Roman 10", command=lambda: [RechneplusKlettern()])
    but_Klettern_minus=Button(TA,text="-",fg="purple",bg="black",font = "Roman 10", command=lambda: [RechneminusKlettern()])

    but_Handwerk_plus =Button(TA,text="+",fg="purple",bg="black",font = "Roman 10", command=lambda: [RechneplusHandwerk()])
    but_Handwerk_minus=Button(TA,text="-",fg="purple",bg="black",font = "Roman 10", command=lambda: [RechneminusHandwerk()])

    but_Alchemie_plus =Button(TA,text="+",fg="purple",bg="black",font = "Roman 10", command=lambda: [RechneplusAlchemie()])
    but_Alchemie_minus=Button(TA,text="-",fg="purple",bg="black",font = "Roman 10", command=lambda: [RechneminusAlchemie()])

    but_Kraftakt_plus =Button(TA,text="+",fg="purple",bg="black",font = "Roman 10", command=lambda: [RechneplusKraftakt()])
    but_Kraftakt_minus=Button(TA,text="-",fg="purple",bg="black",font = "Roman 10", command=lambda: [RechneminusKraftakt()])

    but_Sammeln_plus =Button(TA,text="+",fg="purple",bg="black",font = "Roman 10", command=lambda: [RechneplusSammeln()])
    but_Sammeln_minus=Button(TA,text="-",fg="purple",bg="black",font = "Roman 10", command=lambda: [RechneminusSammeln()])

    but_Handeln_plus =Button(TA,text="+",fg="purple",bg="black",font = "Roman 10", command=lambda: [RechneplusHandeln()])
    but_Handeln_minus=Button(TA,text="-",fg="purple",bg="black",font = "Roman 10", command=lambda: [RechneminusHandeln()])

    but_Fesseln_plus =Button(TA,text="+",fg="purple",bg="black",font = "Roman 10", command=lambda: [RechneplusFesseln()])
    but_Fesseln_minus=Button(TA,text="-",fg="purple",bg="black",font = "Roman 10", command=lambda: [RechneminusFesseln()])

    but_Zechen_plus =Button(TA,text="+",fg="purple",bg="black",font = "Roman 10", command=lambda: [RechneplusZechen()])
    but_Zechen_minus=Button(TA,text="-",fg="purple",bg="black",font = "Roman 10", command=lambda: [RechneminusZechen()])

    but_Jagen_plus =Button(TA,text="+",fg="purple",bg="black",font = "Roman 10", command=lambda: [RechneplusJagen()])
    but_Jagen_minus=Button(TA,text="-",fg="purple",bg="black",font = "Roman 10", command=lambda: [RechneminusJagen()])
    #############################################################################################################
    ##################################Es folgt die Grafische Umsetzung der Werte#################################
    #############################################################################################################

    but_Rechne1.place(x= 1600, y=250)
    but_Rechne10.place(x =1600 ,y= 350)
    #------------------------------------------------------------------------------------------------------------#
    #but_prevPage.place(x= 1600, y=450)
    #but_nextPage.place(x= 1600, y=550)
    #------------------------------------------------------------------------------------------------------------#

    lab_AP = Label (TA, 
                 text = "AP",
                 fg= "green",
                 bg = "black",
                 font = "Roman 20",
                 )
    lab_AP_Wert = Label (TA, 
                 text = Wert_AP,
                 fg= "green",
                 bg = "black",
                 font = "Roman 20",
                 )
    lab_AP.place(x=750, y=105)
    lab_AP_Wert.place(x=850, y=105)
    but_AP_pluseins.place(x= 1340, y=105)
    but_AP_minuseins.place(x= 310, y=105)
    but_AP_pluszehn.place(x= 1440, y=105)
    but_AP_minuszehn.place(x= 410, y=105) 
    but_AP_plushundert.place(x= 1540, y=105)
    but_AP_minushundert.place(x= 510, y=105) 

    lab_Intelligenz = Label (TA, 
                 text = "Intelligenz",
                 fg= "green",
                 bg = "black",
                 font = "Roman 20",
                 )
    lab_Intelligenz_Wert = Label (TA, 
                 text = Wert_Intelligenz,
                 fg= "green",
                 bg = "black",
                 font = "Roman 20",
                 )
    lab_Intelligenz.place(x=10, y=10)
    lab_Intelligenz_Wert.place(x=160, y=10)
    but_Intelligenz_plus.place(x= 140, y=10)
    but_Intelligenz_minus.place(x= 210, y=10) 
    #------------------------------------------------------------------------------------------------------------#
    lab_Kraft = Label (TA, 
                 text = "Kraft",
                 fg= "green",
                 bg = "black",
                 font = "Roman 20",
                 )
    lab_Kraft_Wert = Label (TA, 
                 text = Wert_Kraft,
                 fg= "green",
                 bg = "black",
                 font = "Roman 20",
                 )
    lab_Kraft.place(x=310, y=10)
    lab_Kraft_Wert.place(x=410, y=10)
    but_Kraft_plus.place(x= 390, y=10)
    but_Kraft_minus.place(x= 460, y=10) 
    #------------------------------------------------------------------------------------------------------------#
    lab_Ausdauer = Label (TA, 
                 text = "Ausdauer",
                 fg= "green",
                 bg = "black",
                 font = "Roman 20",
                 )
    lab_Ausdauer_Wert = Label (TA, 
                 text = Wert_Ausdauer,
                 fg= "green",
                 bg = "black",
                 font = "Roman 20",
                 )
    lab_Ausdauer.place(x=560, y=10)
    lab_Ausdauer_Wert.place(x=690, y=10)
    but_Ausdauer_plus.place(x= 670, y=10)
    but_Ausdauer_minus.place(x= 740, y=10)
    #------------------------------------------------------------------------------------------------------------#             
    lab_Charisma = Label (TA, 
                 text = "Charisma",
                 fg= "green",
                 bg = "black",
                 font = "Roman 20",
                 )
    lab_Charisma_Wert = Label (TA, 
                 text = Wert_Ausdauer,
                 fg= "green",
                 bg = "black",
                 font = "Roman 20",
                 )
    lab_Charisma.place(x=840, y=10)       
    lab_Charisma_Wert.place(x=980, y=10)
    but_Charisma_plus.place(x= 960, y=10)
    but_Charisma_minus.place(x= 1030, y=10)
    #------------------------------------------------------------------------------------------------------------#
    lab_Intuition = Label (TA, 
                 text = "Intuition",
                 fg= "green",
                 bg = "black",
                 font = "Roman 20",
                 )
    lab_Intuition_Wert = Label (TA, 
                 text = Wert_Intuition,
                 fg= "green",
                 bg = "black",
                 font = "Roman 20",
                 )
    lab_Intuition.place(x=1130, y=10)
    lab_Intuition_Wert.place(x=1270, y=10)
    but_Intuition_plus.place(x= 1250, y=10)
    but_Intuition_minus.place(x= 1320, y=10)
    #------------------------------------------------------------------------------------------------------------#
    lab_Fingerfertigkeit  = Label (TA, 
                 text = "Fingerfertigkeit ",
                 fg= "green",
                 bg = "black",
                 font = "Roman 20",
                 )
    lab_Fingerfertigkeit_Wert = Label (TA, 
                 text = Wert_Fingerfertigkeit,
                 fg= "green",
                 bg = "black",
                 font = "Roman 20",
                 )
    lab_Fingerfertigkeit.place(x=1420, y=10)
    lab_Fingerfertigkeit_Wert.place(x=1630, y=10)
    but_Fingerfertigkeit_plus.place(x= 1610, y=10)
    but_Fingerfertigkeit_minus.place(x= 1680, y=10)
    ##############################################################################################################
    lab_Lebensmittelbearbeitung = Label (TA, 
                 text = "Lebensmittelbearbeitung",
                 fg= "purple",
                 bg = "black",
                 font = "Roman 20",
                 )
    lab_Lebensmittelbearbeitung_Wert = Label (TA, 
                 text = Wert_Lebensmittelbearbeitung,
                 fg= "purple",
                 bg = "black",
                 font = "Roman 20",
                 )
    lab_Lebensmittelbearbeitung.place(x=10, y=200)
    lab_Lebensmittelbearbeitung_Wert.place(x=330, y=200)
    but_Lebensmittelbearbeitung_plus.place(x= 310, y=200)
    but_Lebensmittelbearbeitung_minus.place(x= 380, y=200) 
    #------------------------------------------------------------------------------------------------------------#
    lab_Koerperbeherrschung = Label (TA, 
                 text = "Koerperbeherrschung",
                 fg= "purple",
                 bg = "black",
                 font = "Roman 20",
                 )
    lab_Koerperbeherrschung_Wert = Label (TA, 
                 text = Wert_Koerperbeherrschung,
                 fg= "purple",
                 bg = "black",
                 font = "Roman 20",
                 )
    lab_Koerperbeherrschung.place(x=10, y=300)
    lab_Koerperbeherrschung_Wert.place(x=330, y=300)
    but_Koerperbeherrschung_plus.place(x= 310, y=300)
    but_Koerperbeherrschung_minus.place(x= 380, y=300)
    #------------------------------------------------------------------------------------------------------------#
    lab_SagenundLegenden = Label (TA, 
                 text = "Sagen und Legenden",
                 fg= "purple",
                 bg = "black",
                 font = "Roman 20",
                 )
    lab_SagenundLegenden_Wert = Label (TA, 
                 text = Wert_SagenundLegenden,
                 fg= "purple",
                 bg = "black",
                 font = "Roman 20",
                 )
    lab_SagenundLegenden.place(x=10, y=400)
    lab_SagenundLegenden_Wert.place(x=330, y=400)
    but_SagenundLegenden_plus.place(x= 310, y=400)
    but_SagenundLegenden_minus.place(x= 380, y=400)
    #------------------------------------------------------------------------------------------------------------#
    lab_Selbstbeherrschung = Label (TA, 
                 text = "Selbstbeherrschung",
                 fg= "purple",
                 bg = "black",
                 font = "Roman 20",
                 )
    lab_Selbstbeherrschung_Wert = Label (TA, 
                 text = Wert_Selbstbeherrschung,
                 fg= "purple",
                 bg = "black",
                 font = "Roman 20",
                 )
    lab_Selbstbeherrschung.place(x=10, y=500)
    lab_Selbstbeherrschung_Wert.place(x=330, y=500)
    but_Selbstbeherrschung_plus.place(x= 310, y=500)
    but_Selbstbeherrschung_minus.place(x= 380, y=500)
    #------------------------------------------------------------------------------------------------------------#
    lab_Schloesserknacken = Label (TA, 
                 text = "Schloesserknacken",
                 fg= "purple",
                 bg = "black",
                 font = "Roman 20",
                 )
    lab_Schloesserknacken_Wert = Label (TA, 
                 text = Wert_Schloesserknacken,
                 fg= "purple",
                 bg = "black",
                 font = "Roman 20",
                 )
    lab_Schloesserknacken.place(x=10, y=600)
    lab_Schloesserknacken_Wert.place(x=330, y=600)
    but_Schloesserknacken_plus.place(x= 310, y=600)
    but_Schloesserknacken_minus.place(x= 380, y=600)
    #------------------------------------------------------------------------------------------------------------#
    lab_Menschenkenntnis = Label (TA, 
                 text = "Menschenkenntnis",
                 fg= "purple",
                 bg = "black",
                 font = "Roman 20",
                 )
    lab_Menschenkenntnis_Wert = Label (TA, 
                 text = Wert_Menschenkenntnis,
                 fg= "purple",
                 bg = "black",
                 font = "Roman 20",
                 )
    lab_Menschenkenntnis.place(x=10, y=700)
    lab_Menschenkenntnis_Wert.place(x=330, y=700)
    but_Menschenkenntnis_plus.place(x= 310, y=700)
    but_Menschenkenntnis_minus.place(x= 380, y=700)
    #------------------------------------------------------------------------------------------------------------#
    lab_Taschendiebstahl = Label (TA, 
                 text = "Taschendiebstahl",
                 fg= "purple",
                 bg = "black",
                 font = "Roman 20",
                 )
    lab_Taschendiebstahl_Wert = Label (TA, 
                 text = Wert_Taschendiebstahl,
                 fg= "purple",
                 bg = "black",
                 font = "Roman 20",
                 )
    lab_Taschendiebstahl.place(x=10, y=800)
    lab_Taschendiebstahl_Wert.place(x=330, y=800)
    but_Taschendiebstahl_plus.place(x= 310, y=800)
    but_Taschendiebstahl_minus.place(x= 380, y=800)
    #------------------------------------------------------------------------------------------------------------#
    lab_Pflanzenkunde = Label (TA, 
                 text = "Pflanzenkunde",
                 fg= "purple",
                 bg = "black",
                 font = "Roman 20",
                 )
    lab_Pflanzenkunde_Wert = Label (TA, 
                 text = Wert_Pflanzenkunde,
                 fg= "purple",
                 bg = "black",
                 font = "Roman 20",
                 )
    lab_Pflanzenkunde.place(x=10, y=900)
    lab_Pflanzenkunde_Wert.place(x=330, y=900)
    but_Pflanzenkunde_plus.place(x= 310, y=900)
    but_Pflanzenkunde_minus.place(x= 380, y=900)
    #------------------------------------------------------------------------------------------------------------#
    lab_Einschuechtern = Label (TA, 
                 text = "Einschuechtern",
                 fg= "purple",
                 bg = "black",
                 font = "Roman 20",
                 )
    lab_Einschuechtern_Wert = Label (TA, 
                 text = Wert_Einschuechtern,
                 fg= "purple",
                 bg = "black",
                 font = "Roman 20",
                 )
    lab_Einschuechtern.place(x=480, y=200)
    lab_Einschuechtern_Wert.place(x=700, y=200)
    but_Einschuechtern_plus.place(x= 680, y=200)
    but_Einschuechtern_minus.place(x= 750, y=200)
    #------------------------------------------------------------------------------------------------------------#
    lab_Wildniskunde = Label (TA, 
                 text = "Wildniskunde",
                 fg= "purple",
                 bg = "black",
                 font = "Roman 20",
                 )
    lab_Wildniskunde_Wert = Label (TA, 
                 text = Wert_Wildniskunde,
                 fg= "purple",
                 bg = "black",
                 font = "Roman 20",
                 )
    lab_Wildniskunde.place(x=480, y=300)
    lab_Wildniskunde_Wert.place(x=700, y=300)
    but_Wildniskunde_plus.place(x= 680, y=300)
    but_Wildniskunde_minus.place(x= 750, y=300)
    #------------------------------------------------------------------------------------------------------------#
    lab_Geistesblitz = Label (TA, 
                 text = "Geistesblitz",
                 fg= "purple",
                 bg = "black",
                 font = "Roman 20",
                 )
    lab_Geistesblitz_Wert = Label (TA, 
                 text = Wert_Geistesblitz,
                 fg= "purple",
                 bg = "black",
                 font = "Roman 20",
                 )
    lab_Geistesblitz.place(x=480, y=400)
    lab_Geistesblitz_Wert.place(x=700, y=400)
    but_Geistesblitz_plus.place(x= 680, y=400)
    but_Geistesblitz_minus.place(x= 750, y=400)
    #------------------------------------------------------------------------------------------------------------#
    lab_Gassenwissen = Label (TA, 
                 text = "Gassenwissen",
                 fg= "purple",
                 bg = "black",
                 font = "Roman 20",
                 )
    lab_Gassenwissen_Wert = Label (TA, 
                 text = Wert_Gassenwissen,
                 fg= "purple",
                 bg = "black",
                 font = "Roman 20",
                 )
    lab_Gassenwissen.place(x=480, y=500)
    lab_Gassenwissen_Wert.place(x=700, y=500)
    but_Gassenwissen_plus.place(x= 680, y=500)
    but_Gassenwissen_minus.place(x= 750, y=500)
    #------------------------------------------------------------------------------------------------------------#
    lab_Orientierung = Label (TA, 
                 text = "Orientierung",
                 fg= "purple",
                 bg = "black",
                 font = "Roman 20",
                 )
    lab_Orientierung_Wert = Label (TA, 
                 text = Wert_Orientierung,
                 fg= "purple",
                 bg = "black",
                 font = "Roman 20",
                 )
    lab_Orientierung.place(x=480, y=600)
    lab_Orientierung_Wert.place(x=700, y=600)
    but_Orientierung_plus.place(x= 680, y=600)
    but_Orientierung_minus.place(x= 750, y=600)
    #------------------------------------------------------------------------------------------------------------#
    lab_Kriegskunst = Label (TA, 
                 text = "Kriegskunst",
                 fg= "purple",
                 bg = "black",
                 font = "Roman 20",
                 )
    lab_Kriegskunst_Wert = Label (TA, 
                 text = Wert_Kriegskunst,
                 fg= "purple",
                 bg = "black",
                 font = "Roman 20",
                 )
    lab_Kriegskunst.place(x=480, y=700)
    lab_Kriegskunst_Wert.place(x=700, y=700)
    but_Kriegskunst_plus.place(x= 680, y=700)
    but_Kriegskunst_minus.place(x= 750, y=700)
    #------------------------------------------------------------------------------------------------------------#
    lab_Wahrnehmung = Label (TA, 
                 text = "Wahrnehmung",
                 fg= "purple",
                 bg = "black",
                 font = "Roman 20",
                 )
    lab_Wahrnehmung_Wert = Label (TA, 
                 text = Wert_Wahrnehmung,
                 fg= "purple",
                 bg = "black",
                 font = "Roman 20",
                 )
    lab_Wahrnehmung.place(x=480, y=800)
    lab_Wahrnehmung_Wert.place(x=700, y=800)
    but_Wahrnehmung_plus.place(x= 680, y=800)
    but_Wahrnehmung_minus.place(x= 750, y=800)
    #------------------------------------------------------------------------------------------------------------#
    lab_Ueberreden = Label (TA, 
                 text = "Ueberreden",
                 fg= "purple",
                 bg = "black",
                 font = "Roman 20",
                 )
    lab_Ueberreden_Wert = Label (TA, 
                 text = Wert_Ueberreden,
                 fg= "purple",
                 bg = "black",
                 font = "Roman 20",
                 )
    lab_Ueberreden.place(x=480, y=900)
    lab_Ueberreden_Wert.place(x=700, y=900)
    but_Ueberreden_plus.place(x= 680, y=900)
    but_Ueberreden_minus.place(x= 750, y=900)
    #------------------------------------------------------------------------------------------------------------#
    lab_Magiekunde = Label (TA, 
                 text = "Magiekunde",
                 fg= "purple",
                 bg = "black",
                 font = "Roman 20",
                 )
    lab_Magiekunde_Wert = Label (TA, 
                 text = Wert_Magiekunde,
                 fg= "purple",
                 bg = "black",
                 font = "Roman 20",
                 )
    lab_Magiekunde.place(x=850, y=200)
    lab_Magiekunde_Wert.place(x=1020, y=200)
    but_Magiekunde_plus.place(x= 1000, y=200)
    but_Magiekunde_minus.place(x= 1070, y=200)
    #------------------------------------------------------------------------------------------------------------#
    lab_Ablenkung = Label (TA, 
                 text = "Ablenkung",
                 fg= "purple",
                 bg = "black",
                 font = "Roman 20",
                 )
    lab_Ablenkung_Wert = Label (TA, 
                 text = Wert_Ablenkung,
                 fg= "purple",
                 bg = "black",
                 font = "Roman 20",
                 )
    lab_Ablenkung.place(x=850, y=300)
    lab_Ablenkung_Wert.place(x=1020, y=300)
    but_Ablenkung_plus.place(x= 1000, y=300)
    but_Ablenkung_minus.place(x= 1070, y=300)
    #------------------------------------------------------------------------------------------------------------#
    lab_Verbergen = Label (TA, 
                 text = "Verbergen",
                 fg= "purple",
                 bg = "black",
                 font = "Roman 20",
                 )
    lab_Verbergen_Wert = Label (TA, 
                 text = Wert_Verbergen,
                 fg= "purple",
                 bg = "black",
                 font = "Roman 20",
                 )
    lab_Verbergen.place(x=850, y=400)
    lab_Verbergen_Wert.place(x=1020, y=400)
    but_Verbergen_plus.place(x= 1000, y=400)
    but_Verbergen_minus.place(x= 1070, y=400)
    #------------------------------------------------------------------------------------------------------------#
    lab_Schwimmen = Label (TA, 
                 text = "Schwimmen",
                 fg= "purple",
                 bg = "black",
                 font = "Roman 20",
                 )
    lab_Schwimmen_Wert = Label (TA, 
                 text = Wert_Schwimmen,
                 fg= "purple",
                 bg = "black",
                 font = "Roman 20",
                 )
    lab_Schwimmen.place(x=850, y=500)
    lab_Schwimmen_Wert.place(x=1020, y=500)
    but_Schwimmen_plus.place(x= 1000, y=500)
    but_Schwimmen_minus.place(x= 1070, y=500)
    #------------------------------------------------------------------------------------------------------------#
    lab_Heilkunde = Label (TA, 
                 text = "Heilkunde",
                 fg= "purple",
                 bg = "black",
                 font = "Roman 20",
                 )
    lab_Heilkunde_Wert = Label (TA, 
                 text = Wert_Heilkunde,
                 fg= "purple",
                 bg = "black",
                 font = "Roman 20",
                 )
    lab_Heilkunde.place(x=850, y=600)
    lab_Heilkunde_Wert.place(x=1020, y=600)
    but_Heilkunde_plus.place(x= 1000, y=600)
    but_Heilkunde_minus.place(x= 1070, y=600)
    #------------------------------------------------------------------------------------------------------------#
    lab_Tierkunde = Label (TA, 
                 text = "Tierkunde",
                 fg= "purple",
                 bg = "black",
                 font = "Roman 20",
                 )
    lab_Tierkunde_Wert = Label (TA, 
                 text = Wert_Tierkunde,
                 fg= "purple",
                 bg = "black",
                 font = "Roman 20",
                 )
    lab_Tierkunde.place(x=850, y=700)
    lab_Tierkunde_Wert.place(x=1020, y=700)
    but_Tierkunde_plus.place(x= 1000, y=700)
    but_Tierkunde_minus.place(x= 1070, y=700)
    #------------------------------------------------------------------------------------------------------------#
    lab_Betoeren = Label (TA, 
                 text = "Betoeren",
                 fg= "purple",
                 bg = "black",
                 font = "Roman 20",
                 )
    lab_Betoeren_Wert = Label (TA, 
                 text = Wert_Betoeren,
                 fg= "purple",
                 bg = "black",
                 font = "Roman 20",
                 )
    lab_Betoeren.place(x=850, y=800)
    lab_Betoeren_Wert.place(x=1020, y=800)
    but_Betoeren_plus.place(x= 1000, y=800)
    but_Betoeren_minus.place(x= 1070, y=800)
    #------------------------------------------------------------------------------------------------------------#
    lab_Klettern = Label (TA, 
                 text = "Klettern",
                 fg= "purple",
                 bg = "black",
                 font = "Roman 20",
                 )
    lab_Klettern_Wert = Label (TA, 
                 text = Wert_Klettern,
                 fg= "purple",
                 bg = "black",
                 font = "Roman 20",
                 )
    lab_Klettern.place(x=850, y=900)
    lab_Klettern_Wert.place(x=1020, y=900)
    but_Klettern_plus.place(x= 1000, y=900)
    but_Klettern_minus.place(x= 1070, y=900)
    #------------------------------------------------------------------------------------------------------------#
    lab_Klettern = Label (TA, 
                 text = "Klettern",
                 fg= "purple",
                 bg = "black",
                 font = "Roman 20",
                 )
    lab_Klettern_Wert = Label (TA, 
                 text = Wert_Klettern,
                 fg= "purple",
                 bg = "black",
                 font = "Roman 20",
                 )
    lab_Klettern.place(x=850, y=900)
    lab_Klettern_Wert.place(x=1020, y=900)
    but_Klettern_plus.place(x= 1000, y=900)
    but_Klettern_minus.place(x= 1070, y=900)
    #------------------------------------------------------------------------------------------------------------#
    lab_Handwerk = Label (TA, 
                 text = "Handwerk",
                 fg= "purple",
                 bg = "black",
                 font = "Roman 20",
                 )
    lab_Handwerk_Wert = Label (TA, 
                 text = Wert_Handwerk,
                 fg= "purple",
                 bg = "black",
                 font = "Roman 20",
                 )
    lab_Handwerk.place(x=1170, y=200)
    lab_Handwerk_Wert.place(x=1340, y=200)
    but_Handwerk_plus.place(x= 1320, y=200)
    but_Handwerk_minus.place(x= 1390, y=200)
    #------------------------------------------------------------------------------------------------------------#
    lab_Alchemie = Label (TA, 
                 text = "Alchemie",
                 fg= "purple",
                 bg = "black",
                 font = "Roman 20",
                 )
    lab_Alchemie_Wert = Label (TA, 
                 text = Wert_Alchemie,
                 fg= "purple",
                 bg = "black",
                 font = "Roman 20",
                 )
    lab_Alchemie.place(x=1170, y=300)
    lab_Alchemie_Wert.place(x=1340, y=300)
    but_Alchemie_plus.place(x= 1320, y=300)
    but_Alchemie_minus.place(x= 1390, y=300)
    #------------------------------------------------------------------------------------------------------------#
    lab_Kraftakt = Label (TA, 
                 text = "Kraftakt",
                 fg= "purple",
                 bg = "black",
                 font = "Roman 20",
                 )
    lab_Kraftakt_Wert = Label (TA, 
                 text = Wert_Kraftakt,
                 fg= "purple",
                 bg = "black",
                 font = "Roman 20",
                 )
    lab_Kraftakt.place(x=1170, y=400)
    lab_Kraftakt_Wert.place(x=1340, y=400)
    but_Kraftakt_plus.place(x= 1320, y=400)
    but_Kraftakt_minus.place(x= 1390, y=400)
    #------------------------------------------------------------------------------------------------------------#
    lab_Sammeln = Label (TA, 
                 text = "Sammeln",
                 fg= "purple",
                 bg = "black",
                 font = "Roman 20",
                 )
    lab_Sammeln_Wert = Label (TA, 
                 text = Wert_Sammeln,
                 fg= "purple",
                 bg = "black",
                 font = "Roman 20",
                 )
    lab_Sammeln.place(x=1170, y=500)
    lab_Sammeln_Wert.place(x=1340, y=500)
    but_Sammeln_plus.place(x= 1320, y=500)
    but_Sammeln_minus.place(x= 1390, y=500)
    #------------------------------------------------------------------------------------------------------------#
    lab_Handeln = Label (TA, 
                 text = "Handeln",
                 fg= "purple",
                 bg = "black",
                 font = "Roman 20",
                 )
    lab_Handeln_Wert = Label (TA, 
                 text = Wert_Handeln,
                 fg= "purple",
                 bg = "black",
                 font = "Roman 20",
                 )
    lab_Handeln.place(x=1170, y=600)
    lab_Handeln_Wert.place(x=1340, y=600)
    but_Handeln_plus.place(x= 1320, y=600)
    but_Handeln_minus.place(x= 1390, y=600)
    #------------------------------------------------------------------------------------------------------------#
    lab_Fesseln = Label (TA, 
                 text = "Fesseln",
                 fg= "purple",
                 bg = "black",
                 font = "Roman 20",
                 )
    lab_Fesseln_Wert = Label (TA, 
                 text = Wert_Fesseln,
                 fg= "purple",
                 bg = "black",
                 font = "Roman 20",
                 )
    lab_Fesseln.place(x=1170, y=700)
    lab_Fesseln_Wert.place(x=1340, y=700)
    but_Fesseln_plus.place(x= 1320, y=700)
    but_Fesseln_minus.place(x= 1390, y=700)
    #------------------------------------------------------------------------------------------------------------#
    lab_Zechen = Label (TA, 
                 text = "Zechen",
                 fg= "purple",
                 bg = "black",
                 font = "Roman 20",
                 )
    lab_Zechen_Wert = Label (TA, 
                 text = Wert_Zechen,
                 fg= "purple",
                 bg = "black",
                 font = "Roman 20",
                 )
    lab_Zechen.place(x=1170, y=800)
    lab_Zechen_Wert.place(x=1340, y=800)
    but_Zechen_plus.place(x= 1320, y=800)
    but_Zechen_minus.place(x= 1390, y=800)
    #------------------------------------------------------------------------------------------------------------#
    lab_Jagen = Label (TA, 
                 text = "Jagen",
                 fg= "purple",
                 bg = "black",
                 font = "Roman 20",
                 )
    lab_Jagen_Wert = Label (TA, 
                 text = Wert_Jagen,
                 fg= "purple",
                 bg = "black",
                 font = "Roman 20",
                 )
    lab_Jagen.place(x=1170, y=900)
    lab_Jagen_Wert.place(x=1340, y=900)
    but_Jagen_plus.place(x= 1320, y=900)
    but_Jagen_minus.place(x= 1390, y=900)
    #------------------------------------------------------------------------------------------------------------#

    TA.mainloop()